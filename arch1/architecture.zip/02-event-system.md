# Event System

## Обзор

Система событий — это центральный механизм коммуникации в OpenHands. Она реализует паттерн Pub/Sub и обеспечивает:
- Асинхронную обработку событий
- Персистентность истории
- Изоляцию компонентов

## Детальная архитектура Event System

```mermaid
flowchart TB
    subgraph EventSystemLayer["📨 EVENT SYSTEM LAYER"]
        direction TB
        
        subgraph EventCore["Event Core Components"]
            subgraph EventStreamClass["EventStream (stream.py)"]
                ESAttributes["Attributes:<br/>- sid: str<br/>- file_store: FileStore<br/>- secrets: dict<br/>- _subscribers: dict<br/>- _queue: Queue<br/>- _lock: threading.Lock<br/>- cur_id: int"]
                
                subgraph ESMethods["Methods"]
                    Subscribe["subscribe(subscriber_id, callback, callback_id)"]
                    Unsubscribe["unsubscribe(subscriber_id, callback_id)"]
                    AddEvent["add_event(event, source)"]
                    SearchEvents["search_events(start_id, end_id, filter_fn)"]
                    SetSecrets["set_secrets(secrets)"]
                    UpdateSecrets["update_secrets(secrets)"]
                    Close["close()"]
                end
                
                subgraph ESInternal["Internal"]
                    ReplaceSecrets["_replace_secrets(data)"]
                    ProcessQueue["_process_queue()"]
                    RunQueueLoop["_run_queue_loop()"]
                    StoreCachePage["_store_cache_page()"]
                end
            end
            
            subgraph EventStoreClass["EventStore (event_store.py)"]
                StoreAttributes["Attributes:<br/>- sid: str<br/>- file_store: FileStore<br/>- user_id: str | None<br/>- cur_id: int<br/>- cache_size: int = 100"]
                
                subgraph StoreMethods["Methods"]
                    GetEvents["get_events(start_id, end_id)"]
                    GetLatestId["get_latest_event_id()"]
                    GetFilename["_get_filename_for_id(id)"]
                    GetCacheFilename["_get_filename_for_cache(start, end)"]
                end
            end
            
            subgraph OtherStores["Other Event Stores"]
                EventStoreABC["EventStoreABC<br/>(Abstract Base)"]
                NestedEventStore["NestedEventStore<br/>(For delegates)"]
                AsyncWrapper["AsyncEventStoreWrapper<br/>(Async operations)"]
            end
        end
        
        subgraph EventTypes["Event Type Hierarchy"]
            subgraph EventBase["Event Base (event.py)"]
                EventClass["Event"]
                EventId["id: int"]
                EventTimestamp["timestamp: str"]
                EventSource["source: EventSource"]
                EventCause["cause: int"]
                EventMessage["message: str"]
            end
            
            subgraph EventSourceEnum["EventSource Enum"]
                UserSource["USER"]
                AgentSource["AGENT"]
                EnvironmentSource["ENVIRONMENT"]
            end
        end
        
        subgraph Subscribers["Event Subscribers"]
            subgraph SubscriberEnum["EventStreamSubscriber Enum"]
                AgentControllerSub["AGENT_CONTROLLER"]
                ResolverSub["RESOLVER"]
                ServerSub["SERVER"]
                RuntimeSub["RUNTIME"]
                MemorySub["MEMORY"]
                MainSub["MAIN"]
                TestSub["TEST"]
            end
            
            subgraph SubscriberFlow["Subscriber Flow"]
                SubscribeCall["subscribe(id, callback, callback_id)"]
                ThreadPool["ThreadPoolExecutor per subscriber"]
                EventLoop["asyncio event loop per thread"]
                CallbackExec["callback(event) execution"]
            end
        end
        
        subgraph Serialization["Serialization Module"]
            EventSerialization["event.py"]
            ActionSerialization["action.py"]
            ObservationSerialization["observation.py"]
            SerializationUtils["utils.py"]
            
            subgraph SerializationFunctions["Functions"]
                EventToDict["event_to_dict(event)"]
                EventFromDict["event_from_dict(data)"]
                TruncateContent["truncate_content(content, max_chars)"]
            end
        end
    end
    
    EventStreamClass --> EventStoreClass
    EventStreamClass --> Subscribers
    EventBase --> EventSourceEnum
    EventCore --> Serialization
```

## Полная иерархия Actions

```mermaid
flowchart TB
    subgraph ActionsHierarchy["Actions Hierarchy (/events/action)"]
        direction TB
        
        subgraph ActionBase["Action Base (action.py)"]
            ActionClass["Action"]
            ActionTimeout["timeout: int | None"]
            ActionToolMeta["tool_call_metadata: ToolCallMetadata | None"]
            ActionSecurityRisk["security_risk: ActionSecurityRisk"]
            ActionConfirmation["is_confirmed: ActionConfirmationStatus"]
            
            subgraph ActionMethods["Methods"]
                SetHardTimeout["set_hard_timeout(timeout, blocking)"]
                Runnable["runnable: bool (property)"]
            end
        end
        
        subgraph MessageActions["Message Actions (message.py)"]
            MessageAction["MessageAction<br/>- content: str<br/>- image_urls: list[str]<br/>- wait_for_response: bool"]
            SystemMessageAction["SystemMessageAction<br/>- content: str"]
        end
        
        subgraph CommandActions["Command Actions (commands.py)"]
            CmdRunAction["CmdRunAction<br/>- command: str<br/>- thought: str<br/>- blocking: bool<br/>- keep_prompt: bool<br/>- is_input: bool"]
            IPythonRunCellAction["IPythonRunCellAction<br/>- code: str<br/>- thought: str<br/>- include_extra: bool"]
        end
        
        subgraph FileActions["File Actions (files.py)"]
            FileReadAction["FileReadAction<br/>- path: str<br/>- start_line: int<br/>- end_line: int<br/>- thought: str"]
            FileWriteAction["FileWriteAction<br/>- path: str<br/>- content: str<br/>- thought: str"]
            FileEditAction["FileEditAction<br/>- path: str<br/>- command: str<br/>- old_str: str<br/>- new_str: str<br/>- insert_line: int<br/>- file_text: str<br/>- view_range: list[int]<br/>- thought: str"]
        end
        
        subgraph BrowseActions["Browse Actions (browse.py)"]
            BrowseURLAction["BrowseURLAction<br/>- url: str<br/>- thought: str"]
            BrowseInteractiveAction["BrowseInteractiveAction<br/>- browser_actions: str<br/>- thought: str<br/>- browsergym_send_msg_to_user: str"]
        end
        
        subgraph AgentActions["Agent Actions (agent.py)"]
            AgentFinishAction["AgentFinishAction<br/>- thought: str<br/>- outputs: dict"]
            AgentRejectAction["AgentRejectAction<br/>- thought: str<br/>- outputs: dict"]
            AgentDelegateAction["AgentDelegateAction<br/>- agent: str<br/>- inputs: dict<br/>- thought: str"]
            AgentThinkAction["AgentThinkAction<br/>- thought: str"]
            CondensationAction["CondensationAction<br/>- forgotten_events_start_id: int<br/>- forgotten_events_end_id: int<br/>- summary: str"]
            CondensationRequestAction["CondensationRequestAction"]
            RecallAction["RecallAction<br/>- recall_type: RecallType<br/>- query: str"]
            ChangeAgentStateAction["ChangeAgentStateAction<br/>- agent_state: AgentState"]
            LoopRecoveryAction["LoopRecoveryAction<br/>- thought: str"]
        end
        
        subgraph MCPActions["MCP Actions (mcp.py)"]
            MCPAction["MCPAction<br/>- name: str<br/>- arguments: dict<br/>- thought: str"]
            TaskTrackingAction["TaskTrackingAction<br/>- command: str<br/>- task_list: list[Task]<br/>- thought: str"]
        end
        
        subgraph EmptyActions["Empty Actions (empty.py)"]
            NullAction["NullAction"]
        end
    end
    
    ActionBase --> MessageActions
    ActionBase --> CommandActions
    ActionBase --> FileActions
    ActionBase --> BrowseActions
    ActionBase --> AgentActions
    ActionBase --> MCPActions
    ActionBase --> EmptyActions
```

## Полная иерархия Observations

```mermaid
flowchart TB
    subgraph ObservationsHierarchy["Observations Hierarchy (/events/observation)"]
        direction TB
        
        subgraph ObservationBase["Observation Base (observation.py)"]
            ObservationClass["Observation"]
            ObsContent["content: str"]
        end
        
        subgraph CommandObservations["Command Observations (commands.py)"]
            CmdOutputObservation["CmdOutputObservation<br/>- content: str<br/>- command: str<br/>- exit_code: int<br/>- command_id: int<br/>- interpreter_details: str"]
            IPythonRunCellObservation["IPythonRunCellObservation<br/>- content: str<br/>- code: str"]
        end
        
        subgraph FileObservations["File Observations (files.py)"]
            FileReadObservation["FileReadObservation<br/>- content: str<br/>- path: str"]
            FileEditObservation["FileEditObservation<br/>- content: str<br/>- path: str<br/>- old_content: str<br/>- new_content: str<br/>- prev_exist: bool<br/>- impl_source: str"]
            FileWriteObservation["FileWriteObservation<br/>- content: str<br/>- path: str"]
        end
        
        subgraph BrowseObservations["Browse Observations (browse.py)"]
            BrowserOutputObservation["BrowserOutputObservation<br/>- content: str<br/>- url: str<br/>- screenshot: str<br/>- open_pages_urls: list<br/>- active_page_index: int<br/>- last_browser_action: str<br/>- last_browser_action_error: str<br/>- focused_element_bid: str<br/>- error: bool"]
        end
        
        subgraph AgentObservations["Agent Observations (agent.py)"]
            AgentStateChangedObservation["AgentStateChangedObservation<br/>- agent_state: AgentState"]
            AgentCondensationObservation["AgentCondensationObservation<br/>- content: str"]
            AgentThinkObservation["AgentThinkObservation<br/>- content: str"]
            RecallObservation["RecallObservation<br/>- memories: list[str]<br/>- microagent_knowledge: list[MicroagentKnowledge]<br/>- repo_instructions: str"]
            MicroagentKnowledge["MicroagentKnowledge<br/>- name: str<br/>- trigger: str<br/>- content: str"]
        end
        
        subgraph DelegateObservations["Delegate Observations (delegate.py)"]
            AgentDelegateObservation["AgentDelegateObservation<br/>- content: str<br/>- outputs: dict"]
        end
        
        subgraph ErrorObservations["Error Observations (error.py)"]
            ErrorObservation["ErrorObservation<br/>- content: str"]
        end
        
        subgraph MCPObservations["MCP Observations (mcp.py)"]
            MCPObservation["MCPObservation<br/>- content: str"]
            TaskTrackingObservation["TaskTrackingObservation<br/>- content: str"]
        end
        
        subgraph OtherObservations["Other Observations"]
            NullObservation["NullObservation<br/>(empty.py)"]
            UserRejectObservation["UserRejectObservation<br/>(reject.py)"]
            SuccessObservation["SuccessObservation<br/>(success.py)"]
            LoopDetectionObservation["LoopDetectionObservation<br/>(loop_recovery.py)"]
            FileDownloadObservation["FileDownloadObservation<br/>(file_download.py)"]
        end
    end
    
    ObservationBase --> CommandObservations
    ObservationBase --> FileObservations
    ObservationBase --> BrowseObservations
    ObservationBase --> AgentObservations
    ObservationBase --> DelegateObservations
    ObservationBase --> ErrorObservations
    ObservationBase --> MCPObservations
    ObservationBase --> OtherObservations
```

## Иерархия событий

```mermaid
classDiagram
    class Event {
        <<abstract>>
        +id: int
        +timestamp: str
        +source: EventSource
        +cause: int
    }
    
    class Action {
        <<abstract>>
        +timeout: int
        +tool_call_metadata: ToolCallMetadata
        +security_risk: ActionSecurityRisk
    }
    
    class Observation {
        <<abstract>>
        +content: str
    }
    
    Event <|-- Action
    Event <|-- Observation
    
    %% Actions
    Action <|-- MessageAction
    Action <|-- CmdRunAction
    Action <|-- IPythonRunCellAction
    Action <|-- FileEditAction
    Action <|-- FileReadAction
    Action <|-- BrowseInteractiveAction
    Action <|-- AgentFinishAction
    Action <|-- AgentThinkAction
    Action <|-- AgentDelegateAction
    Action <|-- MCPAction
    Action <|-- TaskTrackingAction
    
    %% Observations
    Observation <|-- CmdOutputObservation
    Observation <|-- IPythonRunCellObservation
    Observation <|-- FileReadObservation
    Observation <|-- FileEditObservation
    Observation <|-- BrowserOutputObservation
    Observation <|-- ErrorObservation
    Observation <|-- AgentDelegateObservation
    Observation <|-- MCPObservation
```

## EventStream

```mermaid
classDiagram
    class EventStream {
        +sid: str
        +file_store: FileStore
        +secrets: dict
        -_subscribers: dict
        -_queue: Queue
        +subscribe(subscriber_id, callback, callback_id)
        +unsubscribe(subscriber_id, callback_id)
        +add_event(event, source)
        +search_events(start_id, end_id, filter_fn)
        +close()
    }
    
    class EventStore {
        +sid: str
        +file_store: FileStore
        +cur_id: int
        +cache_size: int
        +get_events(start_id, end_id)
        +get_latest_event_id()
    }
    
    class EventStreamSubscriber {
        <<enumeration>>
        AGENT_CONTROLLER
        RESOLVER
        SERVER
        RUNTIME
        MEMORY
        MAIN
        TEST
    }
    
    EventStream --|> EventStore
    EventStream --> EventStreamSubscriber
```

## Поток событий

```mermaid
sequenceDiagram
    participant Producer as Источник события
    participant EventStream as EventStream
    participant Queue as Event Queue
    participant FileStore as FileStore
    participant Subscriber1 as AgentController
    participant Subscriber2 as Runtime

    Producer->>EventStream: add_event(action, source)
    EventStream->>EventStream: Присвоить ID и timestamp
    EventStream->>EventStream: Заменить секреты
    EventStream->>FileStore: Сохранить событие
    EventStream->>Queue: Добавить в очередь
    
    loop Обработка очереди
        Queue->>EventStream: Получить событие
        par Параллельная доставка
            EventStream->>Subscriber1: callback(event)
            EventStream->>Subscriber2: callback(event)
        end
    end
```

## Actions (Действия)

### Основные типы действий

| Action | Описание | Source |
|--------|----------|--------|
| `MessageAction` | Текстовое сообщение | user/agent |
| `SystemMessageAction` | Системное сообщение | agent |
| `CmdRunAction` | Bash команда | agent |
| `IPythonRunCellAction` | Python код | agent |
| `FileEditAction` | Редактирование файла | agent |
| `FileReadAction` | Чтение файла | agent |
| `BrowseInteractiveAction` | Браузер действие | agent |
| `AgentFinishAction` | Завершение | agent/user |
| `AgentThinkAction` | Мысль агента | agent |
| `AgentDelegateAction` | Делегирование | agent |
| `MCPAction` | MCP инструмент | agent |
| `TaskTrackingAction` | Управление задачами | agent |

### Структура CmdRunAction

```mermaid
classDiagram
    class CmdRunAction {
        +command: str
        +thought: str
        +blocking: bool
        +keep_prompt: bool
        +is_confirmed: ActionConfirmationStatus
        +security_risk: ActionSecurityRisk
        +timeout: int
    }
```

## Observations (Наблюдения)

### Основные типы наблюдений

| Observation | Описание | Cause |
|-------------|----------|-------|
| `CmdOutputObservation` | Вывод команды | CmdRunAction |
| `IPythonRunCellObservation` | Вывод Python | IPythonRunCellAction |
| `FileReadObservation` | Содержимое файла | FileReadAction |
| `FileEditObservation` | Результат редактирования | FileEditAction |
| `BrowserOutputObservation` | Состояние браузера | BrowseInteractiveAction |
| `ErrorObservation` | Ошибка | Any Action |
| `AgentStateChangedObservation` | Смена состояния | Controller |

### Структура CmdOutputObservation

```mermaid
classDiagram
    class CmdOutputObservation {
        +content: str
        +command: str
        +exit_code: int
        +command_id: int
        +interpreter_details: str
    }
```

## Сериализация событий

```mermaid
flowchart LR
    subgraph Serialization["Сериализация"]
        Event["Event Object"]
        Dict["Python Dict"]
        JSON["JSON String"]
        File["File Storage"]
    end
    
    Event -->|event_to_dict| Dict
    Dict -->|json.dumps| JSON
    JSON -->|file_store.write| File
    
    File -->|file_store.read| JSON
    JSON -->|json.loads| Dict
    Dict -->|event_from_dict| Event
```

## Пример события в JSON

```json
{
  "id": 42,
  "timestamp": "2024-01-15T10:30:00.000000",
  "source": "agent",
  "action": "run",
  "args": {
    "command": "ls -la",
    "thought": "Проверяю содержимое директории",
    "blocking": true,
    "keep_prompt": true
  },
  "message": "Running command: ls -la"
}
```

## Фильтрация событий

```mermaid
flowchart TB
    subgraph EventFilter["Event Filter"]
        AllEvents["Все события"]
        FilterFn["filter_fn(event)"]
        FilteredEvents["Отфильтрованные"]
    end
    
    AllEvents --> FilterFn
    FilterFn -->|True| FilteredEvents
    FilterFn -->|False| Discard["Отброшено"]
    
    subgraph Examples["Примеры фильтров"]
        ByType["По типу события"]
        BySource["По источнику"]
        ByTimeRange["По времени"]
    end
```

## Секреты и безопасность

```mermaid
flowchart TB
    subgraph SecretHandling["Обработка секретов"]
        Event["Событие с секретом"]
        ReplaceSecrets["_replace_secrets()"]
        SafeEvent["Безопасное событие"]
    end
    
    Event -->|"API_KEY=sk-xxx"| ReplaceSecrets
    ReplaceSecrets -->|"API_KEY=<secret_hidden>"| SafeEvent
    
    subgraph ProtectedFields["Защищённые поля"]
        Timestamp["timestamp"]
        ID["id"]
        Source["source"]
    end
```
