# Integrations Layer

## Обзор

Integrations Layer обеспечивает интеграцию с внешними сервисами: Git-провайдерами, MCP серверами и другими инструментами.

## Детальная архитектура Integrations Layer

```mermaid
flowchart TB
    subgraph IntegrationsLayer["🔗 INTEGRATIONS LAYER"]
        direction TB
        
        subgraph GitProviders["Git Providers (/openhands/integrations)"]
            subgraph ProviderCore["Provider Core"]
                ProviderHandler["ProviderHandler (provider.py)"]
                ProviderType["ProviderType Enum:<br/>GITHUB, GITLAB, BITBUCKET,<br/>AZURE_DEVOPS, FORGEJO"]
                ServiceTypes["service_types.py<br/>AuthenticationError, etc."]
                IntegrationUtils["utils.py<br/>Helper functions"]
            end
            
            subgraph GitHubModule["GitHub (/integrations/github)"]
                GitHubService["GitHubService"]
                
                subgraph GitHubServiceDir["service/"]
                    GHRepoService["Repository service"]
                    GHBranchService["Branch service"]
                    GHPRService["Pull request service"]
                    GHIssueService["Issue service"]
                end
                
                GitHubQueries["queries.py<br/>GraphQL queries"]
            end
            
            subgraph GitLabModule["GitLab (/integrations/gitlab)"]
                GitLabService["GitLabService"]
                
                subgraph GitLabServiceDir["service/"]
                    GLProjectService["Project service"]
                    GLBranchService["Branch service"]
                    GLMRService["Merge request service"]
                end
            end
            
            subgraph BitbucketModule["Bitbucket (/integrations/bitbucket)"]
                BitbucketService["BitbucketService"]
                
                subgraph BitbucketServiceDir["service/"]
                    BBRepoService["Repository service"]
                    BBBranchService["Branch service"]
                    BBPRService["Pull request service"]
                end
            end
            
            subgraph AzureDevOpsModule["Azure DevOps (/integrations/azure_devops)"]
                AzureDevOpsService["AzureDevOpsService"]
                
                subgraph AzureServiceDir["service/"]
                    AzureRepoService["Repository service"]
                    AzureBranchService["Branch service"]
                    AzurePRService["Pull request service"]
                end
            end
            
            subgraph ForgejoModule["Forgejo (/integrations/forgejo)"]
                ForgejoService["ForgejoService"]
                
                subgraph ForgejoServiceDir["service/"]
                    FJRepoService["Repository service"]
                    FJBranchService["Branch service"]
                    FJPRService["Pull request service"]
                end
            end
            
            subgraph Protocols["Protocols (/integrations/protocols)"]
                HTTPClient["http_client.py<br/>HTTP client protocol"]
            end
            
            subgraph Templates["Templates (/integrations/templates)"]
                ResolverTemplates["resolver/<br/>Issue resolver templates"]
                SuggestedTaskTemplates["suggested_task/<br/>Task suggestion templates"]
            end
        end
        
        subgraph MCPModule["MCP Protocol (/openhands/mcp)"]
            subgraph MCPCore["MCP Core"]
                MCPClient["MCPClient (client.py)"]
                MCPTool["MCPTool (tool.py)"]
                MCPUtils["MCPUtils (utils.py)"]
                MCPErrorCollector["ErrorCollector (error_collector.py)"]
            end
            
            subgraph MCPClientClass["MCPClient Class"]
                MCPConnect["connect()"]
                MCPDisconnect["disconnect()"]
                MCPCallTool["call_tool(name, arguments)"]
                MCPListTools["list_tools()"]
                MCPGetTools["get_tools()"]
            end
            
            subgraph MCPConfig["MCP Configuration"]
                MCPConfigClass["MCPConfig"]
                SSEServerConfig["SSEServerConfig:<br/>- name: str<br/>- url: str<br/>- api_key: str"]
                StdioServerConfig["StdioServerConfig:<br/>- name: str<br/>- command: str<br/>- args: list<br/>- env: dict"]
            end
            
            subgraph MCPServers["MCP Server Types"]
                SSEServer["SSE Server<br/>(HTTP-based)"]
                StdioServer["Stdio Server<br/>(Process-based)"]
            end
        end
        
        subgraph ResolverModule["Issue Resolver (/openhands/resolver)"]
            subgraph ResolverCore["Resolver Core"]
                IssueResolver["IssueResolver (issue_resolver.py)"]
                ResolveIssue["resolve_issue.py"]
                SendPullRequest["send_pull_request.py"]
                IOUtils["io_utils.py"]
                ResolverUtils["utils.py"]
                ResolverOutput["resolver_output.py"]
                VisualizeOutput["visualize_resolver_output.py"]
            end
            
            subgraph IssueHandlers["Issue Handlers (/resolver/interfaces)"]
                IssueHandlerFactory["IssueHandlerFactory"]
                GitHubIssueHandler["GitHub Issue Handler"]
                GitLabIssueHandler["GitLab Issue Handler"]
            end
            
            subgraph Patching["Patching (/resolver/patching)"]
                PatchApply["Patch application"]
                PatchGeneration["Patch generation"]
            end
            
            subgraph ResolverPrompts["Prompts (/resolver/prompts)"]
                IssuePrompt["Issue resolution prompts"]
                PRPrompt["PR creation prompts"]
            end
        end
        
        subgraph SecurityModule["Security (/openhands/security)"]
            subgraph SecurityCore["Security Core"]
                SecurityAnalyzer["SecurityAnalyzer (analyzer.py)"]
                SecurityOptions["options.py"]
            end
            
            subgraph Analyzers["Security Analyzers"]
                InvariantAnalyzer["InvariantAnalyzer<br/>(/security/invariant)"]
                GrayswanAnalyzer["GrayswanAnalyzer<br/>(/security/grayswan)"]
                LLMAnalyzer["LLMAnalyzer<br/>(/security/llm)"]
            end
            
            subgraph SecurityRisk["Security Risk Levels"]
                RiskLow["LOW"]
                RiskMedium["MEDIUM"]
                RiskHigh["HIGH"]
                RiskUnknown["UNKNOWN"]
            end
        end
        
        subgraph MicroagentModule["Microagents (/openhands/microagent)"]
            MicroagentClass["BaseMicroagent (microagent.py)"]
            MicroagentTypes["types.py"]
            
            subgraph MicroagentPrompts["prompts/"]
                MicroagentPromptTemplates["Microagent prompt templates"]
            end
            
            subgraph MicroagentLoading["Loading"]
                LoadFromDir["load_microagents_from_dir()"]
                RepoMicroagents["Repository microagents"]
                SkillMicroagents["Skill microagents"]
            end
        end
    end
    
    ProviderCore --> GitHubModule
    ProviderCore --> GitLabModule
    ProviderCore --> BitbucketModule
    ProviderCore --> AzureDevOpsModule
    ProviderCore --> ForgejoModule
    
    ResolverModule --> GitProviders
    SecurityModule --> MCPModule
```

## Детальная архитектура Git Provider

```mermaid
flowchart TB
    subgraph GitProviderDetail["Git Provider Architecture"]
        direction TB
        
        subgraph ProviderHandlerClass["ProviderHandler"]
            PHAttributes["Attributes:<br/>- provider_tokens: dict<br/>- external_auth_id: str<br/>- external_token_manager: bool<br/>- session_api_key: str<br/>- sid: str"]
            
            subgraph PHMethods["Methods"]
                GetEnvVars["get_env_vars(providers, expose_secrets, get_latest)"]
                ExposeEnvVars["expose_env_vars(env_vars)"]
                SetEventStreamSecrets["set_event_stream_secrets(event_stream, env_vars)"]
                CheckCmdAction["check_cmd_action_for_provider_token_ref(event)"]
            end
        end
        
        subgraph ServiceInterface["Service Interface"]
            subgraph CommonMethods["Common Methods"]
                GetRepositories["get_repositories()"]
                GetBranches["get_branches(repo)"]
                CloneRepository["clone_repository(url)"]
                CreatePullRequest["create_pull_request()"]
                GetIssues["get_issues()"]
                GetPullRequests["get_pull_requests()"]
            end
            
            subgraph AuthMethods["Authentication"]
                ValidateToken["validate_token()"]
                RefreshToken["refresh_token()"]
                GetUserInfo["get_user_info()"]
            end
        end
        
        subgraph TokenTypes["Token Types"]
            PAT["Personal Access Token"]
            OAuthToken["OAuth Token"]
            AppInstallToken["App Installation Token"]
        end
        
        subgraph EnvVarMapping["Environment Variable Mapping"]
            GitHubToken["GITHUB_TOKEN"]
            GitLabToken["GITLAB_TOKEN"]
            BitbucketToken["BITBUCKET_TOKEN"]
            AzureToken["AZURE_DEVOPS_TOKEN"]
        end
    end
    
    ProviderHandlerClass --> ServiceInterface
    ServiceInterface --> TokenTypes
    TokenTypes --> EnvVarMapping
```

## Детальная архитектура MCP

```mermaid
flowchart TB
    subgraph MCPDetail["MCP Architecture"]
        direction TB
        
        subgraph MCPClientDetail["MCPClient"]
            MCPClientAttrs["Attributes:<br/>- tools: dict[str, MCPTool]<br/>- clients: dict[str, Client]<br/>- error_collector: ErrorCollector"]
            
            subgraph MCPClientMethods["Methods"]
                MCPInit["__init__(config, runtime)"]
                MCPCreateClients["create_clients()"]
                MCPConnectAll["connect_all()"]
                MCPDisconnectAll["disconnect_all()"]
                MCPCallToolMethod["call_tool(name, arguments) → result"]
                MCPListToolsMethod["list_tools() → list[MCPTool]"]
            end
        end
        
        subgraph MCPToolClass["MCPTool"]
            MCPToolAttrs["Attributes:<br/>- name: str<br/>- description: str<br/>- input_schema: dict<br/>- server_name: str"]
            
            subgraph MCPToolMethods["Methods"]
                ToOpenAITool["to_openai_tool() → dict"]
                FromMCPTool["from_mcp_tool(tool, server_name)"]
            end
        end
        
        subgraph MCPFlow["MCP Flow"]
            AgentStep["Agent step()"]
            CheckMCPTool["Check if tool is MCP"]
            CreateMCPAction["Create MCPAction"]
            RuntimeCallMCP["Runtime.call_tool_mcp()"]
            MCPClientCall["MCPClient.call_tool()"]
            ServerExecute["MCP Server executes"]
            ReturnResult["Return MCPObservation"]
        end
        
        subgraph MCPServerTypes["Server Types"]
            subgraph SSEServerType["SSE Server"]
                SSEConnect["HTTP SSE connection"]
                SSEMessages["Server-sent events"]
            end
            
            subgraph StdioServerType["Stdio Server"]
                StdioProcess["Subprocess"]
                StdioStdin["stdin/stdout"]
                StdioJSON["JSON-RPC messages"]
            end
        end
    end
    
    MCPClientDetail --> MCPToolClass
    MCPClientDetail --> MCPFlow
    MCPFlow --> MCPServerTypes
```

## Детальная архитектура Issue Resolver

```mermaid
flowchart TB
    subgraph ResolverDetail["Issue Resolver Architecture"]
        direction TB
        
        subgraph ResolverFlow["Resolver Flow"]
            Input["Input: Issue URL / Issue Number"]
            
            subgraph FetchIssue["Fetch Issue"]
                DetectProvider["Detect Git provider"]
                CreateHandler["Create IssueHandler"]
                GetIssueDetails["Get issue details"]
            end
            
            subgraph PrepareRepo["Prepare Repository"]
                CloneRepo["Clone repository"]
                CheckoutBranch["Checkout branch"]
                SetupEnv["Setup environment"]
            end
            
            subgraph RunAgent["Run Agent"]
                CreatePrompt["Create issue prompt"]
                StartAgent["Start CodeActAgent"]
                AgentLoop["Agent loop"]
                CollectChanges["Collect changes"]
            end
            
            subgraph CreatePR["Create Pull Request"]
                GenerateDiff["Generate diff"]
                CreateBranch["Create branch"]
                CommitChanges["Commit changes"]
                PushBranch["Push branch"]
                OpenPR["Open PR/MR"]
            end
            
            Output["Output: PR URL"]
        end
        
        subgraph IssueHandlerInterface["IssueHandler Interface"]
            GetIssue["get_issue(issue_number)"]
            GetComments["get_comments(issue_number)"]
            GetPRDiff["get_pr_diff(pr_number)"]
            CreatePRMethod["create_pull_request()"]
            AddComment["add_comment(issue_number, comment)"]
        end
        
        subgraph ResolverConfig["Resolver Configuration"]
            RepoURL["repo_url: str"]
            IssueNumber["issue_number: int"]
            BaseBranch["base_branch: str"]
            MaxIterations["max_iterations: int"]
            OutputDir["output_dir: str"]
        end
    end
    
    Input --> FetchIssue
    FetchIssue --> PrepareRepo
    PrepareRepo --> RunAgent
    RunAgent --> CreatePR
    CreatePR --> Output
    
    FetchIssue --> IssueHandlerInterface
    CreatePR --> IssueHandlerInterface
```

## Git Provider Architecture

```mermaid
classDiagram
    class ProviderHandler {
        +provider_tokens: dict
        +external_auth_id: str
        +get_env_vars() dict
        +check_cmd_action_for_provider_token_ref()
    }
    
    class ProviderType {
        <<enumeration>>
        GITHUB
        GITLAB
        BITBUCKET
        AZURE_DEVOPS
        FORGEJO
    }
    
    class GitHubService {
        +token: str
        +get_repositories() list
        +get_branches(repo) list
        +create_pull_request()
        +get_issues()
    }
    
    class GitLabService {
        +token: str
        +get_projects() list
        +get_branches(project) list
        +create_merge_request()
    }
    
    class BitbucketService {
        +token: str
        +get_repositories() list
        +get_branches(repo) list
        +create_pull_request()
    }
    
    ProviderHandler --> ProviderType
    ProviderHandler --> GitHubService
    ProviderHandler --> GitLabService
    ProviderHandler --> BitbucketService
```

## GitHub Integration

```mermaid
flowchart TB
    subgraph GitHubIntegration["GitHub Integration"]
        Service["GitHubService"]
        
        subgraph Operations["Operations"]
            ListRepos["List Repositories"]
            ListBranches["List Branches"]
            CloneRepo["Clone Repository"]
            CreatePR["Create Pull Request"]
            GetIssues["Get Issues"]
        end
        
        subgraph Auth["Authentication"]
            Token["Personal Access Token"]
            OAuth["OAuth App"]
            GitHubApp["GitHub App"]
        end
    end
    
    Service --> Operations
    Auth --> Service
```

### GitHub Service API

| Метод | Описание |
|-------|----------|
| `get_repositories()` | Список репозиториев пользователя |
| `get_branches(repo)` | Список веток репозитория |
| `clone_repository(url)` | Клонирование репозитория |
| `create_pull_request()` | Создание Pull Request |
| `get_issues()` | Получение Issues |
| `get_pull_requests()` | Получение Pull Requests |

## MCP (Model Context Protocol)

```mermaid
flowchart TB
    subgraph MCPLayer["MCP Layer"]
        MCPClient["MCPClient<br/>/openhands/mcp/client.py"]
        
        subgraph Tools["MCP Tools"]
            ToolRegistry["Tool Registry"]
            ToolExecution["Tool Execution"]
        end
        
        subgraph Servers["MCP Servers"]
            StdioServer["Stdio Server"]
            SSEServer["SSE Server"]
        end
        
        subgraph Config["Configuration"]
            MCPConfig["MCPConfig"]
            StdioConfig["StdioServerConfig"]
            SSEConfig["SSEServerConfig"]
        end
    end
    
    MCPClient --> Tools
    MCPClient --> Servers
    Config --> Servers
```

### MCP Client

```mermaid
classDiagram
    class MCPClient {
        +tools: dict
        +connect()
        +disconnect()
        +call_tool(name, arguments) result
        +list_tools() list
    }
    
    class MCPConfig {
        +sse_servers: list~SSEServerConfig~
        +stdio_servers: list~StdioServerConfig~
    }
    
    class StdioServerConfig {
        +name: str
        +command: str
        +args: list
        +env: dict
    }
    
    class SSEServerConfig {
        +name: str
        +url: str
        +api_key: str
    }
    
    MCPClient --> MCPConfig
    MCPConfig --> StdioServerConfig
    MCPConfig --> SSEServerConfig
```

### MCP Tool Flow

```mermaid
sequenceDiagram
    participant Agent as CodeActAgent
    participant MCP as MCPClient
    participant Server as MCP Server
    participant Tool as External Tool

    Agent->>MCP: call_tool("tool_name", args)
    MCP->>Server: JSON-RPC request
    Server->>Tool: Execute tool
    Tool-->>Server: Result
    Server-->>MCP: JSON-RPC response
    MCP-->>Agent: MCPObservation
```

## Resolver (Issue Resolver)

```mermaid
flowchart TB
    subgraph Resolver["Issue Resolver"]
        IssueResolver["IssueResolver<br/>/openhands/resolver"]
        
        subgraph Handlers["Issue Handlers"]
            GitHubHandler["GitHub Issue Handler"]
            GitLabHandler["GitLab Issue Handler"]
        end
        
        subgraph Operations["Operations"]
            ResolveIssue["resolve_issue()"]
            SendPR["send_pull_request()"]
            Patching["Apply Patches"]
        end
    end
    
    IssueResolver --> Handlers
    Handlers --> Operations
```

### Issue Resolver Flow

```mermaid
sequenceDiagram
    participant User as User
    participant Resolver as IssueResolver
    participant Agent as CodeActAgent
    participant Git as Git Provider
    participant Runtime as Runtime

    User->>Resolver: resolve_issue(issue_url)
    Resolver->>Git: Fetch issue details
    Git-->>Resolver: Issue content
    
    Resolver->>Runtime: Clone repository
    Resolver->>Agent: Start with issue prompt
    
    loop Agent работает
        Agent->>Runtime: Execute actions
        Runtime-->>Agent: Observations
    end
    
    Agent->>Resolver: Finish
    Resolver->>Git: Create Pull Request
    Git-->>User: PR URL
```

## Provider Token Management

```mermaid
flowchart TB
    subgraph TokenManagement["Token Management"]
        ProviderHandler["ProviderHandler"]
        
        subgraph Tokens["Token Types"]
            PAT["Personal Access Token"]
            OAuth["OAuth Token"]
            AppToken["App Installation Token"]
        end
        
        subgraph EnvVars["Environment Variables"]
            GITHUB_TOKEN["GITHUB_TOKEN"]
            GITLAB_TOKEN["GITLAB_TOKEN"]
            BITBUCKET_TOKEN["BITBUCKET_TOKEN"]
        end
    end
    
    Tokens --> ProviderHandler
    ProviderHandler --> EnvVars
```

## Конфигурация интеграций

### Git Provider

```toml
[sandbox]
selected_repo = "owner/repo"
selected_branch = "main"
```

### MCP

```toml
[mcp]
# SSE сервер
[[mcp.sse_servers]]
name = "my-mcp-server"
url = "http://localhost:8080/sse"
api_key = "..."

# Stdio сервер
[[mcp.stdio_servers]]
name = "filesystem"
command = "npx"
args = ["-y", "@modelcontextprotocol/server-filesystem", "/workspace"]
```

## Интеграция с Enterprise

```mermaid
flowchart TB
    subgraph Enterprise["Enterprise Features"]
        subgraph Integrations["Additional Integrations"]
            Jira["Jira"]
            Linear["Linear"]
            Slack["Slack"]
        end
        
        subgraph Features["Features"]
            Solvability["Issue Solvability"]
            Experiments["A/B Experiments"]
            Billing["Billing (Stripe)"]
        end
    end
    
    Integrations --> Features
```

## Безопасность интеграций

```mermaid
flowchart TB
    subgraph Security["Security"]
        TokenStorage["Secure Token Storage"]
        SecretReplacement["Secret Replacement"]
        
        subgraph Validation["Validation"]
            TokenValidation["Token Validation"]
            ScopeCheck["Scope Check"]
            RateLimit["Rate Limiting"]
        end
    end
    
    TokenStorage --> Validation
    SecretReplacement --> Validation
```

| Аспект | Реализация |
|--------|------------|
| Хранение токенов | Encrypted storage, environment variables |
| Замена секретов | `<secret_hidden>` в логах |
| Валидация | Проверка scope и permissions |
| Rate limiting | Соблюдение лимитов API |
