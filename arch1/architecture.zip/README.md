# OpenHands Architecture Documentation

## 📚 Содержание

Эта документация описывает архитектуру OpenHands — AI-агента для разработки программного обеспечения.

### Документы

| # | Документ | Описание |
|---|----------|----------|
| 00 | [Overview](./00-overview.md) | Общий обзор архитектуры, основные компоненты |
| 01 | [Agent & Controller](./01-agent-controller.md) | Слой агентов и контроллера |
| 02 | [Event System](./02-event-system.md) | Система событий (Actions, Observations) |
| 03 | [Runtime Layer](./03-runtime-layer.md) | Среды выполнения (Docker, Local, Remote) |
| 04 | [LLM & Memory](./04-llm-memory.md) | Интеграция с LLM и управление памятью |
| 05 | [Server & Frontend](./05-server-frontend.md) | API сервер и веб-интерфейс |
| 06 | [Getting Started](./06-getting-started.md) | Руководство по запуску |
| 07 | [Integrations](./07-integrations.md) | Интеграции (Git, MCP) |
| 08 | [**Local Ollama Setup**](./08-local-ollama-setup.md) | **Запуск с локальной Ollama** |

## 🏗️ Высокоуровневая архитектура

```mermaid
flowchart TB
    subgraph User["👤 User"]
        WebUI["Web Browser"]
        CLI["CLI"]
    end
    
    subgraph OpenHands["OpenHands"]
        subgraph Presentation["Presentation"]
            Frontend["React Frontend"]
        end
        
        subgraph API["API"]
            Server["FastAPI Server"]
            WebSocket["WebSocket"]
        end
        
        subgraph Core["Core"]
            Controller["Agent Controller"]
            EventStream["Event Stream"]
        end
        
        subgraph Agent["Agent"]
            CodeAct["CodeAct Agent"]
            Memory["Memory"]
        end
        
        subgraph LLM["LLM"]
            LLMModule["LLM Module"]
        end
        
        subgraph Runtime["Runtime"]
            Docker["Docker Runtime"]
        end
        
        subgraph Storage["Storage"]
            FileStore["File Store"]
        end
    end
    
    subgraph External["External"]
        LLMProviders["LLM Providers<br/>(OpenAI, Anthropic, etc.)"]
        GitProviders["Git Providers<br/>(GitHub, GitLab, etc.)"]
    end
    
    WebUI --> Frontend
    CLI --> Server
    Frontend --> Server
    Frontend --> WebSocket
    
    Server --> Controller
    WebSocket --> EventStream
    
    Controller --> CodeAct
    Controller --> EventStream
    CodeAct --> Memory
    CodeAct --> LLMModule
    
    LLMModule --> LLMProviders
    
    Controller --> Docker
    EventStream --> FileStore
    
    Controller --> GitProviders
```

## 🚀 Быстрый старт

### Docker (Рекомендуется)

```bash
docker run -it --rm \
  -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v ~/.openhands:/.openhands \
  -p 3000:3000 \
  --add-host host.docker.internal:host-gateway \
  docker.all-hands.dev/all-hands-ai/openhands:0.30
```

### Development

```bash
git clone https://github.com/All-Hands-AI/OpenHands.git
cd OpenHands
make build
make run
```

Подробнее: [Getting Started](./06-getting-started.md)

## 📁 Структура проекта

```
OpenHands/
├── frontend/                 # React frontend
│   ├── src/
│   │   ├── api/             # API services
│   │   ├── components/      # React components
│   │   ├── hooks/           # Custom hooks
│   │   └── routes/          # Page routes
│   └── package.json
│
├── openhands/               # Python backend
│   ├── agenthub/           # AI agents
│   │   ├── codeact_agent/  # Main agent
│   │   └── browsing_agent/ # Browser agent
│   │
│   ├── app_server/         # V1 application server
│   ├── server/             # V0 server (legacy)
│   │
│   ├── controller/         # Agent controller
│   ├── events/             # Event system
│   ├── memory/             # Conversation memory
│   ├── llm/                # LLM integration
│   ├── runtime/            # Execution runtimes
│   ├── storage/            # Data storage
│   └── integrations/       # External integrations
│
├── enterprise/             # Enterprise features
├── containers/             # Docker configurations
├── tests/                  # Test suites
│
├── config.template.toml    # Configuration template
├── docker-compose.yml      # Docker Compose
├── Makefile               # Build commands
└── pyproject.toml         # Python dependencies
```

## 🔑 Ключевые концепции

### Event-Driven Architecture

OpenHands использует событийную архитектуру:
- **Actions** — действия агента (команды, редактирование файлов)
- **Observations** — результаты действий (вывод команд, ошибки)
- **EventStream** — центральная шина событий

### Agent Loop

```
User Task → Agent → LLM → Action → Runtime → Observation → Agent → ...
```

### Runtime Isolation

Все действия выполняются в изолированной среде (Docker контейнер), что обеспечивает безопасность.

## 🔗 Полезные ссылки

- [GitHub Repository](https://github.com/All-Hands-AI/OpenHands)
- [Official Documentation](https://docs.all-hands.dev)
- [Discord Community](https://discord.gg/ESHStjSjD4)

## ⚠️ Версии

Проект находится в процессе миграции:
- **V0 (Legacy)**: `/openhands/server`, `/openhands/core/main.py` — будет удалён после 01.04.2026
- **V1 (New)**: `/openhands/app_server` — новая архитектура
