# OpenHands Architecture Overview

## Общая архитектура системы

OpenHands — это AI-агент для разработки программного обеспечения. Система состоит из нескольких ключевых слоёв, которые взаимодействуют друг с другом.

> **Важно**: Проект находится в процессе миграции с V0 (Legacy) на V1. V0 код помечен как deprecated и будет удалён после 1 апреля 2026.

## Детальная архитектура по слоям

```mermaid
flowchart TB
    subgraph Presentation["🖥️ PRESENTATION LAYER"]
        direction TB
        subgraph FrontendApp["Frontend Application"]
            ReactApp["React 18 App<br/>TypeScript"]
            ReactRouter["React Router v7"]
            TanStack["TanStack Query<br/>(React Query)"]
            Zustand["Zustand State"]
        end
        
        subgraph UIComponents["UI Components"]
            ChatUI["Chat Interface"]
            Terminal["Terminal View"]
            FileExplorer["File Explorer"]
            BrowserView["Browser Preview"]
            CodeEditor["Code Editor"]
        end
        
        subgraph ClientServices["Client Services"]
            WSClient["WebSocket Client<br/>Socket.IO"]
            HTTPClient["HTTP Client<br/>Axios"]
            I18n["i18n<br/>Internationalization"]
        end
    end

    subgraph API["🌐 API LAYER"]
        direction TB
        subgraph V0Server["V0 Server (Legacy)"]
            FastAPI_V0["FastAPI Application<br/>openhands/server/app.py"]
            Listen["listen.py<br/>Entry Point"]
            SocketIOServer["Socket.IO Server<br/>listen_socket.py"]
            
            subgraph V0Routes["REST API Routes"]
                ConvRoute["/api/conversations"]
                FilesRoute["/api/files"]
                SettingsRoute["/api/settings"]
                SecretsRoute["/api/secrets"]
                GitRoute["/api/git"]
                HealthRoute["/health"]
                MCPRoute["/mcp"]
            end
            
            subgraph V0Middleware["Middleware"]
                CORS["CORS Middleware"]
                RateLimit["Rate Limiter"]
                CacheControl["Cache Control"]
                Auth["Authentication"]
            end
        end
        
        subgraph V1Server["V1 Server (New)"]
            FastAPI_V1["FastAPI Application<br/>openhands/app_server"]
            V1Router["v1_router.py"]
            
            subgraph V1Modules["Modules"]
                AppConv["app_conversation/<br/>Conversation Management"]
                AppEvent["event/<br/>Event Handling"]
                AppSandbox["sandbox/<br/>Sandbox Management"]
                AppUser["user/<br/>User Context"]
                WebClientMod["web_client/<br/>Client Config"]
                EventCallback["event_callback/<br/>Webhooks"]
            end
            
            subgraph V1Services["Services"]
                JWTService["JWT Service"]
                DBSession["DB Session Injector"]
                HTTPXClient["HTTPX Client"]
            end
        end
    end

    subgraph Core["⚙️ CORE LAYER"]
        direction TB
        subgraph ControllerModule["Controller Module"]
            AgentController["AgentController<br/>agent_controller.py"]
            StateTracker["StateTracker<br/>state/state_tracker.py"]
            StuckDetector["StuckDetector<br/>stuck.py"]
            ReplayManager["ReplayManager<br/>replay.py"]
        end
        
        subgraph StateModule["State Management"]
            State["State<br/>state/state.py"]
            AgentState["AgentState Enum"]
            History["Event History"]
            Metrics["Metrics & Stats"]
        end
        
        subgraph ConfigModule["Configuration"]
            OpenHandsConfig["OpenHandsConfig"]
            AgentConfig["AgentConfig"]
            LLMConfig["LLMConfig"]
            SandboxConfig["SandboxConfig"]
            SecurityConfig["SecurityConfig"]
        end
        
        subgraph CoreUtils["Core Utilities"]
            Logger["Logger<br/>logger.py"]
            Exceptions["Exceptions<br/>exceptions.py"]
            Schema["Schema<br/>schema/"]
            Message["Message<br/>message.py"]
        end
    end

    subgraph Agent["🤖 AGENT LAYER"]
        direction TB
        subgraph AgentHub["Agent Hub"]
            AgentBase["Agent Base Class<br/>controller/agent.py"]
            
            subgraph Agents["Available Agents"]
                CodeActAgent["CodeActAgent<br/>Main Agent v2.2"]
                BrowsingAgent["BrowsingAgent"]
                ReadonlyAgent["ReadonlyAgent"]
                VisualBrowsingAgent["VisualBrowsingAgent"]
                LocAgent["LocAgent"]
                DummyAgent["DummyAgent"]
            end
        end
        
        subgraph AgentTools["Agent Tools"]
            CmdRunTool["cmd_run<br/>Bash Commands"]
            IPythonTool["ipython<br/>Python Execution"]
            StrReplaceEditor["str_replace_editor<br/>File Editing"]
            BrowserTool["browser<br/>Web Browsing"]
            ThinkTool["think<br/>Reasoning"]
            FinishTool["finish<br/>Task Completion"]
            TaskTrackerTool["task_tracker<br/>Task Management"]
            LLMEditorTool["llm_based_edit<br/>AI File Edit"]
            CondensationTool["condensation_request"]
        end
        
        subgraph MemoryModule["Memory Module"]
            ConversationMemory["ConversationMemory<br/>conversation_memory.py"]
            PromptManager["PromptManager<br/>utils/prompt.py"]
            
            subgraph Condensers["Condensers"]
                NoOpCondenser["NoOpCondenser"]
                RecentEventsCondenser["RecentEventsCondenser"]
                LLMCondenser["LLMCondenser"]
                AmortizedCondenser["AmortizedCondenser"]
            end
            
            View["View<br/>Filtered Events"]
        end
        
        subgraph Microagents["Microagents"]
            MicroagentLoader["Microagent Loader"]
            RepoMicroagents["Repository Microagents"]
            SkillMicroagents["Skill Microagents"]
        end
    end

    subgraph LLM["🧠 LLM LAYER"]
        direction TB
        subgraph LLMModule["LLM Module"]
            LLMClass["LLM Class<br/>llm/llm.py"]
            AsyncLLM["AsyncLLM"]
            StreamingLLM["StreamingLLM"]
            LLMRegistry["LLMRegistry<br/>llm_registry.py"]
        end
        
        subgraph LLMMixins["Mixins"]
            RetryMixin["RetryMixin<br/>Retry Logic"]
            DebugMixin["DebugMixin<br/>Logging"]
        end
        
        subgraph LLMUtils["Utilities"]
            FnCallConverter["Function Call Converter<br/>fn_call_converter.py"]
            ModelFeatures["Model Features<br/>model_features.py"]
            LLMMetrics["Metrics<br/>metrics.py"]
            ToolNames["Tool Names<br/>tool_names.py"]
        end
        
        subgraph LLMRouter["Router"]
            ModelRouter["Model Router<br/>router/"]
            RoutingConfig["Routing Config"]
        end
        
        subgraph Providers["LLM Providers (via LiteLLM)"]
            OpenAI["OpenAI<br/>GPT-4, GPT-4o, o1, o3"]
            Anthropic["Anthropic<br/>Claude 3.5, Claude 4"]
            Google["Google<br/>Gemini 2.0, 2.5"]
            Azure["Azure OpenAI"]
            Bedrock["AWS Bedrock"]
            Ollama["Ollama<br/>Local Models"]
            LiteLLMProxy["LiteLLM Proxy"]
        end
    end

    subgraph Events["📨 EVENT SYSTEM"]
        direction TB
        subgraph EventCore["Event Core"]
            EventStream["EventStream<br/>stream.py"]
            EventStore["EventStore<br/>event_store.py"]
            EventStoreABC["EventStoreABC<br/>event_store_abc.py"]
            NestedEventStore["NestedEventStore"]
            AsyncWrapper["AsyncEventStoreWrapper"]
        end
        
        subgraph EventTypes["Event Types"]
            EventBase["Event Base<br/>event.py"]
            
            subgraph Actions["Actions"]
                MessageAction["MessageAction"]
                SystemMessageAction["SystemMessageAction"]
                CmdRunAction["CmdRunAction"]
                IPythonRunCellAction["IPythonRunCellAction"]
                FileEditAction["FileEditAction"]
                FileReadAction["FileReadAction"]
                BrowseInteractiveAction["BrowseInteractiveAction"]
                AgentFinishAction["AgentFinishAction"]
                AgentThinkAction["AgentThinkAction"]
                AgentDelegateAction["AgentDelegateAction"]
                MCPAction["MCPAction"]
                TaskTrackingAction["TaskTrackingAction"]
                CondensationAction["CondensationAction"]
            end
            
            subgraph Observations["Observations"]
                CmdOutputObs["CmdOutputObservation"]
                IPythonObs["IPythonRunCellObservation"]
                FileReadObs["FileReadObservation"]
                FileEditObs["FileEditObservation"]
                BrowserObs["BrowserOutputObservation"]
                ErrorObs["ErrorObservation"]
                AgentStateObs["AgentStateChangedObservation"]
                DelegateObs["AgentDelegateObservation"]
                MCPObs["MCPObservation"]
                CondensationObs["AgentCondensationObservation"]
            end
        end
        
        subgraph Serialization["Serialization"]
            EventSerializer["event.py"]
            ActionSerializer["action.py"]
            ObservationSerializer["observation.py"]
        end
        
        subgraph Subscribers["Event Subscribers"]
            ControllerSub["AGENT_CONTROLLER"]
            RuntimeSub["RUNTIME"]
            ServerSub["SERVER"]
            MemorySub["MEMORY"]
            ResolverSub["RESOLVER"]
        end
    end

    subgraph Runtime["🐳 RUNTIME LAYER"]
        direction TB
        subgraph RuntimeCore["Runtime Core"]
            RuntimeBase["Runtime Base<br/>base.py"]
            FileEditMixin["FileEditRuntimeMixin"]
            RuntimeStatus["RuntimeStatus<br/>runtime_status.py"]
        end
        
        subgraph RuntimeImpl["Implementations"]
            DockerRuntime["DockerRuntime<br/>impl/docker/"]
            LocalRuntime["LocalRuntime<br/>impl/local/"]
            RemoteRuntime["RemoteRuntime<br/>impl/remote/"]
            K8sRuntime["KubernetesRuntime<br/>impl/kubernetes/"]
            CLIRuntime["CLIRuntime<br/>impl/cli/"]
        end
        
        subgraph ThirdPartyRuntime["Third Party Runtimes"]
            E2BRuntime["E2B Runtime<br/>third_party/"]
            DaytonaRuntime["Daytona Runtime"]
            ModalRuntime["Modal Runtime"]
            RunloopRuntime["Runloop Runtime"]
        end
        
        subgraph RuntimeComponents["Components"]
            ActionExecServer["Action Execution Server<br/>action_execution_server.py"]
            ActionExecClient["Action Execution Client"]
            FileViewerServer["File Viewer Server"]
            
            subgraph BrowserEnv["Browser Environment"]
                Playwright["Playwright"]
                BrowserContext["Browser Context"]
                SoM["Set-of-Mark"]
            end
            
            subgraph Plugins["Plugins"]
                JupyterPlugin["JupyterRequirement"]
                AgentSkillsPlugin["AgentSkillsRequirement"]
                VSCodePlugin["VSCodeRequirement"]
            end
        end
        
        subgraph RuntimeUtils["Utilities"]
            BashSession["BashSession<br/>utils/bash_session.py"]
            GitHandler["GitHandler<br/>utils/git_handler.py"]
            LogStreamer["LogStreamer"]
            RuntimeBuilder["RuntimeBuilder<br/>builder/"]
        end
    end

    subgraph Storage["💾 STORAGE LAYER"]
        direction TB
        subgraph FileStoreModule["File Store"]
            FileStoreBase["FileStore Base<br/>files.py"]
            LocalFileStore["LocalFileStore<br/>local.py"]
            S3FileStore["S3FileStore<br/>s3.py"]
            GCSFileStore["GoogleCloudFileStore<br/>google_cloud.py"]
            MemoryFileStore["InMemoryFileStore<br/>memory.py"]
        end
        
        subgraph ConversationStore["Conversation Store"]
            ConvStoreBase["ConversationStore<br/>conversation/"]
            FileConvStore["FileConversationStore"]
            ConvValidator["ConversationValidator"]
        end
        
        subgraph SettingsStore["Settings Store"]
            SettingsStoreBase["SettingsStore<br/>settings/"]
            FileSettingsStore["FileSettingsStore"]
        end
        
        subgraph SecretsStore["Secrets Store"]
            SecretsStoreBase["SecretsStore<br/>secrets/"]
            FileSecretsStore["FileSecretsStore"]
        end
        
        subgraph DataModels["Data Models"]
            ConvMetadata["ConversationMetadata"]
            ConvStatus["ConversationStatus"]
            Settings["Settings"]
            Secrets["Secrets"]
        end
        
        subgraph Webhooks["Webhooks"]
            WebHook["WebHook<br/>web_hook.py"]
            BatchedWebHook["BatchedWebHook"]
        end
    end

    subgraph Integrations["🔗 INTEGRATIONS"]
        direction TB
        subgraph GitProviders["Git Providers"]
            ProviderHandler["ProviderHandler<br/>provider.py"]
            
            GitHubService["GitHubService<br/>github/"]
            GitLabService["GitLabService<br/>gitlab/"]
            BitbucketService["BitbucketService<br/>bitbucket/"]
            AzureDevOpsService["AzureDevOpsService<br/>azure_devops/"]
            ForgejoService["ForgejoService<br/>forgejo/"]
        end
        
        subgraph MCPModule["MCP Protocol"]
            MCPClient["MCPClient<br/>mcp/client.py"]
            MCPTool["MCPTool<br/>mcp/tool.py"]
            MCPUtils["MCPUtils<br/>mcp/utils.py"]
            MCPErrorCollector["ErrorCollector"]
        end
        
        subgraph Resolver["Issue Resolver"]
            IssueResolver["IssueResolver<br/>resolver/"]
            IssueHandlerFactory["IssueHandlerFactory"]
            SendPullRequest["send_pull_request.py"]
            Patching["Patching Module"]
        end
        
        subgraph Security["Security"]
            SecurityAnalyzer["SecurityAnalyzer<br/>security/"]
            InvariantAnalyzer["InvariantAnalyzer"]
            GrayswanAnalyzer["GrayswanAnalyzer"]
            LLMAnalyzer["LLMAnalyzer"]
        end
    end

    %% Connections between layers
    FrontendApp --> ClientServices
    UIComponents --> ClientServices
    ClientServices --> V0Server
    ClientServices --> V1Server
    
    V0Server --> ControllerModule
    V1Server --> ControllerModule
    SocketIOServer --> EventCore
    
    ControllerModule --> StateModule
    ControllerModule --> AgentHub
    ControllerModule --> EventCore
    ControllerModule --> RuntimeCore
    
    AgentHub --> AgentTools
    AgentHub --> MemoryModule
    AgentHub --> LLMModule
    AgentHub --> Microagents
    
    LLMModule --> LLMMixins
    LLMModule --> LLMUtils
    LLMModule --> Providers
    
    EventCore --> EventTypes
    EventCore --> Serialization
    EventCore --> Subscribers
    
    RuntimeCore --> RuntimeImpl
    RuntimeCore --> RuntimeComponents
    RuntimeCore --> RuntimeUtils
    
    EventCore --> FileStoreModule
    ControllerModule --> ConversationStore
    
    ControllerModule --> GitProviders
    AgentHub --> MCPModule
    ControllerModule --> Security
```

## Основные компоненты

| Компонент | Путь | Описание |
|-----------|------|----------|
| Frontend | `/frontend` | React/TypeScript веб-интерфейс |
| Server V0 | `/openhands/server` | Legacy FastAPI сервер |
| Server V1 | `/openhands/app_server` | Новый application server |
| Controller | `/openhands/controller` | Управление агентами |
| AgentHub | `/openhands/agenthub` | Коллекция AI-агентов |
| LLM | `/openhands/llm` | Интеграция с языковыми моделями |
| Memory | `/openhands/memory` | Управление памятью разговора |
| Events | `/openhands/events` | Система событий |
| Runtime | `/openhands/runtime` | Среды выполнения |
| Storage | `/openhands/storage` | Хранение данных |
| Integrations | `/openhands/integrations` | Интеграции с внешними сервисами |

## Детальный поток данных

```mermaid
sequenceDiagram
    participant User as 👤 User
    participant Browser as 🌐 Browser
    participant Frontend as 🖥️ React Frontend
    participant WSClient as 📡 WebSocket Client
    participant HTTPClient as 📨 HTTP Client
    participant FastAPI as ⚡ FastAPI Server
    participant SocketIO as 🔌 Socket.IO
    participant ConvManager as 📋 ConversationManager
    participant Controller as ⚙️ AgentController
    participant State as 📊 State
    participant EventStream as 📨 EventStream
    participant Agent as 🤖 CodeActAgent
    participant Memory as 🧠 ConversationMemory
    participant Condenser as 📦 Condenser
    participant LLM as 🤖 LLM
    participant LiteLLM as 🔗 LiteLLM
    participant Provider as ☁️ LLM Provider
    participant Runtime as 🐳 Runtime
    participant ActionServer as 🖥️ Action Server
    participant Bash as 💻 Bash Session
    participant FileStore as 💾 FileStore

    User->>Browser: Открывает приложение
    Browser->>Frontend: Загружает React App
    Frontend->>HTTPClient: Инициализация
    Frontend->>WSClient: Подключение WebSocket
    WSClient->>SocketIO: connect()
    SocketIO-->>WSClient: connected
    
    User->>Frontend: Вводит задачу
    Frontend->>HTTPClient: POST /api/conversations
    HTTPClient->>FastAPI: Create conversation
    FastAPI->>ConvManager: create_conversation()
    ConvManager->>EventStream: new EventStream(sid)
    ConvManager->>Runtime: create_runtime()
    Runtime->>Runtime: Start Docker container
    Runtime->>ActionServer: Initialize
    ConvManager->>Controller: new AgentController()
    Controller->>State: Initialize state
    Controller->>EventStream: subscribe()
    ConvManager-->>FastAPI: conversation_id
    FastAPI-->>HTTPClient: {id, status}
    HTTPClient-->>Frontend: Conversation created
    
    Frontend->>WSClient: subscribe(conversation_id)
    WSClient->>SocketIO: join room
    
    Frontend->>HTTPClient: POST /api/conversations/{id}/start
    HTTPClient->>FastAPI: Start with task
    FastAPI->>EventStream: add_event(MessageAction)
    EventStream->>FileStore: Persist event
    EventStream->>Controller: on_event(MessageAction)
    
    loop Agent Loop
        Controller->>Agent: step(state)
        Agent->>Memory: process_events(history)
        Memory->>Condenser: condensed_history(state)
        
        alt View (events ready)
            Condenser-->>Memory: View(events)
            Memory->>Memory: Convert to Messages
            Memory-->>Agent: list[Message]
        else Condensation needed
            Condenser-->>Agent: Condensation(action)
            Agent-->>Controller: CondensationAction
            Controller->>EventStream: add_event(CondensationAction)
        end
        
        Agent->>LLM: completion(messages, tools)
        LLM->>LiteLLM: litellm.completion()
        LiteLLM->>Provider: API Request
        Provider-->>LiteLLM: Response
        LiteLLM-->>LLM: ModelResponse
        LLM-->>Agent: Response with tool calls
        
        Agent->>Agent: response_to_actions()
        Agent-->>Controller: Action (e.g., CmdRunAction)
        
        Controller->>EventStream: add_event(action)
        EventStream->>FileStore: Persist action
        EventStream->>SocketIO: Broadcast to room
        SocketIO->>WSClient: emit("event", action)
        WSClient->>Frontend: Update UI
        
        EventStream->>Runtime: on_event(action)
        Runtime->>ActionServer: POST /execute
        ActionServer->>Bash: Execute command
        Bash-->>ActionServer: Output
        ActionServer-->>Runtime: Result
        Runtime->>EventStream: add_event(observation)
        EventStream->>FileStore: Persist observation
        EventStream->>SocketIO: Broadcast
        SocketIO->>WSClient: emit("event", observation)
        WSClient->>Frontend: Update UI
        
        EventStream->>Controller: on_event(observation)
        Controller->>State: Update history
    end
    
    Agent->>Controller: AgentFinishAction
    Controller->>State: set_agent_state(FINISHED)
    Controller->>EventStream: add_event(AgentFinishAction)
    EventStream->>SocketIO: Broadcast
    SocketIO->>WSClient: emit("event", finish)
    WSClient->>Frontend: Show completion
    Frontend->>User: Результат выполнения
```

## Структура файлов проекта

```mermaid
flowchart TB
    subgraph Root["OpenHands/"]
        subgraph Frontend["frontend/"]
            FESrc["src/"]
            FEApi["api/"]
            FEComponents["components/"]
            FEHooks["hooks/"]
            FERoutes["routes/"]
            FEContext["context/"]
            FEMocks["mocks/"]
        end
        
        subgraph OpenHandsPkg["openhands/"]
            subgraph AgentHubDir["agenthub/"]
                CodeActDir["codeact_agent/"]
                BrowsingDir["browsing_agent/"]
                ReadonlyDir["readonly_agent/"]
            end
            
            subgraph AppServerDir["app_server/"]
                AppConvDir["app_conversation/"]
                EventDir["event/"]
                SandboxDir["sandbox/"]
                UserDir["user/"]
            end
            
            subgraph ControllerDir["controller/"]
                StateDir["state/"]
            end
            
            subgraph CoreDir["core/"]
                ConfigDir["config/"]
                SchemaDir["schema/"]
            end
            
            subgraph EventsDir["events/"]
                ActionDir["action/"]
                ObservationDir["observation/"]
                SerializationDir["serialization/"]
            end
            
            subgraph LLMDir["llm/"]
                RouterDir["router/"]
            end
            
            subgraph MemoryDir["memory/"]
                CondenserDir["condenser/"]
            end
            
            subgraph RuntimeDir["runtime/"]
                ImplDir["impl/"]
                BuilderDir["builder/"]
                PluginsDir["plugins/"]
                BrowserDir["browser/"]
                UtilsDir["utils/"]
            end
            
            subgraph ServerDir["server/"]
                RoutesDir["routes/"]
                SessionDir["session/"]
                ServicesDir["services/"]
            end
            
            subgraph StorageDir["storage/"]
                ConvStoreDir["conversation/"]
                SettingsDir["settings/"]
                SecretsDir["secrets/"]
            end
            
            subgraph IntegrationsDir["integrations/"]
                GitHubDir["github/"]
                GitLabDir["gitlab/"]
                BitbucketDir["bitbucket/"]
            end
            
            MCPDir["mcp/"]
            SecurityDir["security/"]
            ResolverDir["resolver/"]
            MicroagentDir["microagent/"]
        end
        
        subgraph Enterprise["enterprise/"]
            EntIntegrations["integrations/"]
            EntServer["server/"]
            EntStorage["storage/"]
            Migrations["migrations/"]
        end
        
        subgraph Containers["containers/"]
            AppContainer["app/"]
            DevContainer["dev/"]
            RuntimeContainer["runtime/"]
        end
        
        subgraph ThirdParty["third_party/"]
            TPRuntime["runtime/"]
            TPContainers["containers/"]
        end
        
        ConfigFiles["config.template.toml<br/>docker-compose.yml<br/>Makefile<br/>pyproject.toml"]
    end
```

## Версии системы

### V0 (Legacy) - Текущая стабильная версия
- Путь: `/openhands/server`, `/openhands/core/main.py`
- Статус: Deprecated, будет удалена после 01.04.2026
- Особенности: Монолитная архитектура

### V1 (New) - Новая архитектура
- Путь: `/openhands/app_server`
- Статус: В разработке
- Особенности: 
  - Использует Software Agent SDK
  - Модульная архитектура
  - Улучшенная масштабируемость

## Взаимодействие компонентов

```mermaid
flowchart LR
    subgraph External["External Services"]
        LLMProviders["LLM Providers"]
        GitServices["Git Services"]
        MCPServers["MCP Servers"]
    end
    
    subgraph OpenHands["OpenHands Core"]
        direction TB
        
        subgraph Input["Input"]
            WebUI["Web UI"]
            CLI["CLI"]
            API["REST API"]
        end
        
        subgraph Processing["Processing"]
            Controller["Controller"]
            Agent["Agent"]
            Memory["Memory"]
        end
        
        subgraph Execution["Execution"]
            Runtime["Runtime"]
            Browser["Browser"]
            FileSystem["File System"]
        end
        
        subgraph Persistence["Persistence"]
            EventStore["Event Store"]
            FileStore["File Store"]
            Settings["Settings"]
        end
    end
    
    Input --> Processing
    Processing --> LLMProviders
    Processing --> Execution
    Processing --> GitServices
    Processing --> MCPServers
    Execution --> Persistence
    Processing --> Persistence
```
