# Getting Started - Руководство по запуску

## Обзор способов запуска

OpenHands можно запустить несколькими способами:

```mermaid
flowchart TB
    subgraph Methods["🚀 СПОСОБЫ ЗАПУСКА"]
        direction TB
        
        subgraph DockerMethod["🐳 Docker (Рекомендуется)"]
            DockerRun["docker run<br/>Быстрый старт"]
            DockerCompose["docker compose up<br/>Из исходников"]
            DockerDev["make docker-dev<br/>Разработка в контейнере"]
        end
        
        subgraph DevMethod["💻 Development Mode"]
            MakeRun["make run<br/>Backend + Frontend"]
            MakeBuild["make build<br/>Сборка проекта"]
            ManualStart["Ручной запуск<br/>Раздельно backend/frontend"]
        end
        
        subgraph CLIMethod["⌨️ CLI Mode"]
            PythonMain["python -m openhands.core.main<br/>Командная строка"]
            PipInstall["pip install openhands-ai<br/>Установка пакета"]
        end
        
        subgraph CloudMethod["☁️ Cloud"]
            AllHands["app.all-hands.dev<br/>SaaS версия"]
        end
    end
    
    subgraph Requirements["📋 ТРЕБОВАНИЯ"]
        subgraph System["Системные"]
            RAM["RAM: 8GB+ (рек. 16GB)"]
            CPU["CPU: 4+ cores"]
            Disk["Disk: 20GB+"]
        end
        
        subgraph Software["Программные"]
            Docker["Docker 20.10+"]
            Python["Python 3.12"]
            Node["Node.js 22+"]
            Poetry["Poetry 1.8+"]
        end
        
        subgraph Optional["Опциональные"]
            Tmux["tmux"]
            Git["Git"]
        end
    end
    
    subgraph Config["⚙️ КОНФИГУРАЦИЯ"]
        ConfigToml["config.toml"]
        EnvVars["Environment Variables"]
        LLMKey["LLM API Key"]
    end
    
    Methods --> Requirements
    Requirements --> Config
```

## Детальная схема запуска через Docker

```mermaid
flowchart TB
    subgraph DockerStartup["🐳 Docker Startup Flow"]
        direction TB
        
        subgraph Prerequisites["Prerequisites"]
            CheckDocker["Проверка Docker"]
            CheckSocket["Проверка /var/run/docker.sock"]
            CreateDirs["Создание директорий:<br/>~/.openhands<br/>~/openhands-workspace"]
        end
        
        subgraph DockerRunCmd["docker run команда"]
            Image["Image: docker.all-hands.dev/all-hands-ai/openhands:0.30"]
            
            subgraph EnvVars["Environment Variables"]
                RuntimeImage["SANDBOX_RUNTIME_CONTAINER_IMAGE"]
                LogEvents["LOG_ALL_EVENTS"]
                LLMModel["LLM_MODEL (optional)"]
                LLMKey["LLM_API_KEY (optional)"]
            end
            
            subgraph Volumes["Volumes"]
                DockerSocket["-v /var/run/docker.sock:/var/run/docker.sock"]
                OpenHandsDir["-v ~/.openhands:/.openhands"]
                Workspace["-v ~/workspace:/opt/workspace_base"]
            end
            
            subgraph Ports["Ports"]
                Port3000["-p 3000:3000"]
            end
            
            subgraph Network["Network"]
                HostGateway["--add-host host.docker.internal:host-gateway"]
            end
        end
        
        subgraph ContainerStartup["Container Startup"]
            Entrypoint["entrypoint.sh"]
            ConfigSh["config.sh"]
            StartServer["Start uvicorn server"]
            ServeFrontend["Serve frontend build"]
        end
        
        subgraph RuntimeContainer["Runtime Container (создаётся при запуске задачи)"]
            RuntimeImage2["Runtime Image"]
            ActionServer["Action Execution Server :8000"]
            BashSession["Bash Session"]
            IPythonKernel["IPython Kernel"]
            Browser["Playwright Browser"]
            WorkspaceMount["/workspace"]
        end
        
        Prerequisites --> DockerRunCmd
        DockerRunCmd --> ContainerStartup
        ContainerStartup -->|"При создании conversation"| RuntimeContainer
    end
```

## Детальная схема Development Mode

```mermaid
flowchart TB
    subgraph DevStartup["💻 Development Mode Flow"]
        direction TB
        
        subgraph BuildPhase["make build"]
            CheckDeps["check-dependencies"]
            
            subgraph SystemChecks["System Checks"]
                CheckSystem["check-system (macOS/Linux/WSL)"]
                CheckPython["check-python (3.12)"]
                CheckNpm["check-npm"]
                CheckNodejs["check-nodejs (22+)"]
                CheckDockerDev["check-docker"]
                CheckPoetry["check-poetry (1.8+)"]
                CheckTmux["check-tmux (optional)"]
            end
            
            subgraph InstallDeps["Install Dependencies"]
                InstallPython["install-python-dependencies<br/>poetry install"]
                InstallPlaywright["playwright install chromium"]
                InstallFrontend["install-frontend-dependencies<br/>npm install"]
                InstallPreCommit["install-pre-commit-hooks"]
            end
            
            BuildFrontend["build-frontend<br/>npm run build"]
        end
        
        subgraph RunPhase["make run"]
            SetupRun["_run_setup"]
            
            subgraph StartBackend["start-backend"]
                Uvicorn["uvicorn openhands.server.listen:app"]
                BackendHost["--host 127.0.0.1"]
                BackendPort["--port 3000"]
                BackendReload["--reload"]
            end
            
            WaitBackend["Wait for backend (nc -z localhost 3000)"]
            
            subgraph StartFrontend["start-frontend"]
                ViteDev["npm run dev"]
                FrontendHost["--host 127.0.0.1"]
                FrontendPort["--port 3001"]
                ViteBackend["VITE_BACKEND_HOST=127.0.0.1:3000"]
            end
        end
        
        subgraph Access["Access"]
            Browser["Browser: http://localhost:3001"]
            API["API: http://localhost:3000"]
        end
        
        BuildPhase --> RunPhase
        RunPhase --> Access
    end
```

## Детальная схема CLI Mode

```mermaid
flowchart TB
    subgraph CLIStartup["⌨️ CLI Mode Flow"]
        direction TB
        
        subgraph Installation["Installation"]
            PipInstall["pip install openhands-ai"]
            PoetryInstall["poetry install (from source)"]
        end
        
        subgraph CLICommand["CLI Command"]
            MainModule["python -m openhands.core.main"]
            
            subgraph Arguments["Arguments"]
                TaskArg["-t, --task 'Task description'"]
                FileArg["-f, --file task.txt"]
                ConfigArg["-c, --config config.toml"]
                DirArg["-d, --directory /path/to/workspace"]
                NameArg["--name session_name"]
                NoAutoArg["--no-auto-continue"]
                ReplayArg["--replay-trajectory-path"]
            end
        end
        
        subgraph Execution["Execution Flow"]
            ParseArgs["parse_arguments()"]
            SetupConfig["setup_config_from_args()"]
            ReadTask["read_task()"]
            GenerateSid["generate_sid()"]
            
            subgraph RunController["run_controller()"]
                CreateRegistry["create_registry_and_conversation_stats()"]
                CreateAgent["create_agent()"]
                CreateRuntime["create_runtime()"]
                ConnectRuntime["runtime.connect()"]
                InitRepo["initialize_repository_for_runtime()"]
                CreateMemory["create_memory()"]
                AddMCPTools["add_mcp_tools_to_agent()"]
                CreateController["create_controller()"]
                
                subgraph AgentLoop["Agent Loop"]
                    AddUserEvent["event_stream.add_event(initial_action)"]
                    RunUntilDone["run_agent_until_done()"]
                    HandleSignals["Signal handling (SIGINT)"]
                end
                
                SaveState["Save state to session"]
                SaveTrajectory["Save trajectory (optional)"]
            end
        end
        
        Installation --> CLICommand
        CLICommand --> Execution
    end
```

## Требования

### Системные требования

| Компонент | Минимум | Рекомендуется |
|-----------|---------|---------------|
| RAM | 8 GB | 16 GB |
| CPU | 4 cores | 8 cores |
| Disk | 20 GB | 50 GB |
| Docker | 20.10+ | Latest |

### Программные зависимости

```mermaid
flowchart LR
    subgraph Required["Обязательные"]
        Python["Python 3.12"]
        Docker["Docker"]
        Node["Node.js 22+"]
        Poetry["Poetry 1.8+"]
    end
    
    subgraph Optional["Опциональные"]
        Tmux["tmux"]
        Git["Git"]
    end
```

## Способ 1: Docker (Рекомендуется)

### Быстрый старт

```bash
# 1. Создайте директорию для workspace
mkdir -p ~/openhands-workspace

# 2. Запустите контейнер
docker run -it --rm \
  --pull=always \
  -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik \
  -e LOG_ALL_EVENTS=true \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v ~/.openhands:/.openhands \
  -v ~/openhands-workspace:/opt/workspace_base \
  -p 3000:3000 \
  --add-host host.docker.internal:host-gateway \
  --name openhands-app \
  docker.all-hands.dev/all-hands-ai/openhands:0.30

# 3. Откройте http://localhost:3000
```

### Docker Compose

```bash
# Клонируйте репозиторий
git clone https://github.com/All-Hands-AI/OpenHands.git
cd OpenHands

# Запустите
docker compose up
```

### Переменные окружения для Docker

| Переменная | Описание | Пример |
|------------|----------|--------|
| `SANDBOX_RUNTIME_CONTAINER_IMAGE` | Образ runtime контейнера | `docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik` |
| `WORKSPACE_MOUNT_PATH` | Путь к workspace | `/opt/workspace_base` |
| `LOG_ALL_EVENTS` | Логировать все события | `true` |
| `LLM_MODEL` | Модель по умолчанию | `anthropic/claude-sonnet-4-20250514` |
| `LLM_API_KEY` | API ключ | `sk-...` |

## Способ 2: Development Mode

### Шаг 1: Клонирование и установка

```bash
# Клонируйте репозиторий
git clone https://github.com/All-Hands-AI/OpenHands.git
cd OpenHands

# Установите зависимости (автоматически)
make build
```

### Шаг 2: Конфигурация

```bash
# Создайте config.toml
make setup-config

# Или создайте вручную
cat > config.toml << EOF
[core]
workspace_base = "./workspace"

[llm]
model = "anthropic/claude-sonnet-4-20250514"
api_key = "your-api-key-here"
EOF
```

### Шаг 3: Запуск

```bash
# Запустить backend и frontend
make run

# Или раздельно:
# Terminal 1 - Backend (порт 3000)
make start-backend

# Terminal 2 - Frontend (порт 3001)
make start-frontend
```

### Структура команд make

```mermaid
flowchart TB
    subgraph MakeCommands["Make Commands"]
        Build["make build"]
        Run["make run"]
        StartBackend["make start-backend"]
        StartFrontend["make start-frontend"]
        DockerRun["make docker-run"]
        Test["make test"]
        Lint["make lint"]
    end
    
    Build --> InstallPython["install-python-dependencies"]
    Build --> InstallFrontend["install-frontend-dependencies"]
    Build --> BuildFrontend["build-frontend"]
    
    Run --> StartBackend
    Run --> StartFrontend
```

## Способ 3: CLI Mode

```bash
# Установите пакет
pip install openhands-ai

# Или из исходников
cd OpenHands
poetry install

# Запустите с задачей
python -m openhands.core.main -t "Create a hello world Python script"

# С файлом задачи
python -m openhands.core.main -f task.txt

# С конфигурацией
python -m openhands.core.main -c config.toml -t "Your task"
```

### CLI аргументы

| Аргумент | Описание |
|----------|----------|
| `-t, --task` | Текст задачи |
| `-f, --file` | Файл с задачей |
| `-c, --config` | Путь к config.toml |
| `-d, --directory` | Рабочая директория |
| `--no-auto-continue` | Не продолжать автоматически |

## Конфигурация (config.toml)

### Полный пример

```toml
[core]
workspace_base = "./workspace"
file_store = "local"
file_store_path = "./.openhands"

[llm]
model = "anthropic/claude-sonnet-4-20250514"
api_key = "sk-ant-..."
temperature = 0.0
max_output_tokens = 4096
num_retries = 5
timeout = 120

[llm.condenser]
type = "recent_events"
max_events = 100
keep_first_n = 5

[agent]
name = "CodeActAgent"
enable_cmd = true
enable_browsing = true
enable_jupyter = true
enable_editor = true

[sandbox]
runtime = "docker"
base_container_image = "nikolaik/python-nodejs:python3.12-nodejs22"
timeout = 120
enable_auto_lint = true
use_host_network = false

[security]
confirmation_mode = false
```

### Конфигурация LLM провайдеров

#### OpenAI

```toml
[llm]
model = "gpt-4o"
api_key = "sk-..."
```

#### Anthropic

```toml
[llm]
model = "anthropic/claude-sonnet-4-20250514"
api_key = "sk-ant-..."
```

#### Azure OpenAI

```toml
[llm]
model = "azure/gpt-4"
api_key = "..."
base_url = "https://your-resource.openai.azure.com"
api_version = "2024-02-15-preview"
```

#### Local (Ollama)

```toml
[llm]
model = "ollama/llama3.2"
base_url = "http://localhost:11434"
api_key = "ollama"
```

## Типичные ошибки и решения

### Ошибка: Docker not found

```bash
# Проверьте установку Docker
docker --version

# Убедитесь, что Docker daemon запущен
sudo systemctl start docker

# Добавьте пользователя в группу docker
sudo usermod -aG docker $USER
```

### Ошибка: Port already in use

```bash
# Найдите процесс
lsof -i :3000

# Или используйте другой порт
BACKEND_PORT=3002 make start-backend
```

### Ошибка: API key invalid

```bash
# Проверьте переменную окружения
echo $LLM_API_KEY

# Или укажите в config.toml
[llm]
api_key = "your-valid-key"
```

### Ошибка: Runtime container fails to start

```bash
# Проверьте Docker socket
ls -la /var/run/docker.sock

# Проверьте права
sudo chmod 666 /var/run/docker.sock

# Проверьте образ
docker pull nikolaik/python-nodejs:python3.12-nodejs22
```

## Архитектура запуска

```mermaid
sequenceDiagram
    participant User as 👤 User
    participant Make as make run
    participant Backend as Backend Server
    participant Frontend as Frontend Dev Server
    participant Docker as Docker Daemon
    participant Runtime as Runtime Container

    User->>Make: make run
    Make->>Backend: uvicorn openhands.server.listen:app
    Backend->>Backend: Initialize FastAPI
    Backend->>Backend: Initialize ConversationManager
    
    Make->>Frontend: npm run dev
    Frontend->>Frontend: Vite dev server
    
    User->>Frontend: Open http://localhost:3001
    Frontend->>Backend: API requests
    
    User->>Frontend: Start conversation
    Frontend->>Backend: POST /api/conversations
    Backend->>Docker: Create runtime container
    Docker->>Runtime: Start container
    Runtime-->>Backend: Ready
    Backend-->>Frontend: Conversation created
```

## Проверка работоспособности

```bash
# Health check
curl http://localhost:3000/health

# API check
curl http://localhost:3000/api/options/models

# Frontend
open http://localhost:3001
```
