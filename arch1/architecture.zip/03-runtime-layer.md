# Runtime Layer

## Обзор

Runtime Layer отвечает за выполнение действий агента в изолированной среде. Это "руки" OpenHands — компонент, который фактически выполняет команды, редактирует файлы и взаимодействует с браузером.

## Детальная архитектура Runtime Layer

```mermaid
flowchart TB
    subgraph RuntimeLayer["🐳 RUNTIME LAYER"]
        direction TB
        
        subgraph RuntimeCore["Runtime Core (/openhands/runtime)"]
            subgraph RuntimeBaseClass["Runtime Base Class (base.py)"]
                RuntimeAttributes["Attributes:<br/>- sid: str<br/>- config: OpenHandsConfig<br/>- event_stream: EventStream<br/>- plugins: list[PluginRequirement]<br/>- initial_env_vars: dict<br/>- attach_to_existing: bool<br/>- status_callback: Callable<br/>- runtime_status: RuntimeStatus<br/>- security_analyzer: SecurityAnalyzer<br/>- provider_handler: ProviderHandler<br/>- git_handler: GitHandler<br/>- workspace_root: Path"]
                
                subgraph RuntimeMethods["Core Methods"]
                    Connect["connect() - Connect to runtime"]
                    Close["close() - Cleanup runtime"]
                    Run["run(action) → Observation"]
                    RunAction["run_action(action) → Observation"]
                    AddEnvVars["add_env_vars(env_vars)"]
                    OnEvent["on_event(event)"]
                    HandleAction["_handle_action(event)"]
                end
                
                subgraph RuntimeAbstract["Abstract Methods"]
                    RunBash["run(CmdRunAction) → CmdOutputObservation"]
                    RunIPython["run_ipython(IPythonRunCellAction)"]
                    RunBrowser["run_browser(BrowseInteractiveAction)"]
                    ReadFile["read(FileReadAction)"]
                    WriteFile["write(FileWriteAction)"]
                    Browse["browse(BrowseURLAction)"]
                    CallToolMCP["call_tool_mcp(MCPAction)"]
                end
                
                subgraph RuntimeHelpers["Helper Methods"]
                    CloneOrInitRepo["clone_or_init_repo()"]
                    SetupInitialEnv["setup_initial_env()"]
                    SetupGitConfig["_setup_git_config()"]
                    SetRuntimeStatus["set_runtime_status()"]
                    ExportGitTokens["_export_latest_git_provider_tokens()"]
                end
            end
            
            subgraph FileEditMixin["FileEditRuntimeMixin"]
                EditFile["edit_file(FileEditAction)"]
                LLMEditor["_llm_based_edit()"]
                ACIEditor["_aci_based_edit()"]
            end
            
            subgraph RuntimeStatusEnum["RuntimeStatus Enum"]
                StatusLoading["LOADING"]
                StatusStarting["STARTING_CONTAINER"]
                StatusStarted["STARTED"]
                StatusReady["READY"]
                StatusError["ERROR"]
                StatusDisconnected["ERROR_RUNTIME_DISCONNECTED"]
            end
        end
        
        subgraph RuntimeImplementations["Runtime Implementations (/runtime/impl)"]
            subgraph DockerRuntimeModule["DockerRuntime (impl/docker)"]
                DockerRuntimeClass["DockerRuntime"]
                DockerContainer["container: Container"]
                ActionExecURL["action_execution_server_url: str"]
                
                subgraph DockerMethods["Methods"]
                    DockerConnect["connect()"]
                    DockerClose["close()"]
                    DockerRun["run(action)"]
                    DockerBuildImage["_build_image()"]
                    DockerStartContainer["_start_container()"]
                    DockerWaitForServer["_wait_for_action_server()"]
                end
                
                subgraph DockerContainers["containers.py"]
                    GetContainer["get_container()"]
                    CreateContainer["create_container()"]
                    StopContainer["stop_container()"]
                end
            end
            
            subgraph LocalRuntimeModule["LocalRuntime (impl/local)"]
                LocalRuntimeClass["LocalRuntime"]
                LocalBashSession["bash_session: BashSession"]
                LocalIPythonKernel["ipython_kernel"]
                
                subgraph LocalMethods["Methods"]
                    LocalConnect["connect()"]
                    LocalRun["run(action)"]
                    LocalRunBash["_run_bash()"]
                    LocalRunIPython["_run_ipython()"]
                end
            end
            
            subgraph RemoteRuntimeModule["RemoteRuntime (impl/remote)"]
                RemoteRuntimeClass["RemoteRuntime"]
                RemoteURL["runtime_url: str"]
                RemoteAPIKey["api_key: str"]
                
                subgraph RemoteMethods["Methods"]
                    RemoteConnect["connect()"]
                    RemoteRun["run(action)"]
                    RemoteExecute["_execute_remote()"]
                end
            end
            
            subgraph K8sRuntimeModule["KubernetesRuntime (impl/kubernetes)"]
                K8sRuntimeClass["KubernetesRuntime"]
                K8sPodName["pod_name: str"]
                K8sNamespace["namespace: str"]
                K8sClient["k8s_client"]
                
                subgraph K8sMethods["Methods"]
                    K8sConnect["connect()"]
                    K8sRun["run(action)"]
                    K8sCreatePod["_create_pod()"]
                    K8sDeletePod["_delete_pod()"]
                end
            end
            
            subgraph CLIRuntimeModule["CLIRuntime (impl/cli)"]
                CLIRuntimeClass["CLIRuntime"]
                CLIMethods["Minimal runtime for CLI"]
            end
        end
        
        subgraph ThirdPartyRuntimes["Third Party Runtimes (/third_party/runtime)"]
            subgraph E2BModule["E2B Runtime"]
                E2BRuntimeClass["E2BRuntime"]
                E2BSandbox["E2B Sandbox API"]
                E2BFilestore["E2B Filestore"]
            end
            
            subgraph DaytonaModule["Daytona Runtime"]
                DaytonaRuntimeClass["DaytonaRuntime"]
                DaytonaWorkspace["Daytona Workspace"]
            end
            
            subgraph ModalModule["Modal Runtime"]
                ModalRuntimeClass["ModalRuntime"]
                ModalSandbox["Modal Sandbox"]
            end
            
            subgraph RunloopModule["Runloop Runtime"]
                RunloopRuntimeClass["RunloopRuntime"]
                RunloopDevbox["Runloop Devbox"]
            end
        end
        
        subgraph RuntimeComponents["Runtime Components"]
            subgraph ActionExecServer["Action Execution Server (action_execution_server.py)"]
                AESApp["FastAPI App"]
                AESExecute["/execute endpoint"]
                AESAlive["/alive endpoint"]
                AESUpload["/upload_file endpoint"]
                AESDownload["/download_file endpoint"]
                AESListFiles["/list_files endpoint"]
            end
            
            subgraph ActionExecClient["Action Execution Client"]
                AECExecute["execute(action)"]
                AECUpload["upload_file()"]
                AECDownload["download_file()"]
            end
            
            subgraph BrowserModule["Browser Environment (/runtime/browser)"]
                BrowserEnv["BrowserEnv"]
                Playwright["Playwright"]
                BrowserContext["Browser Context"]
                
                subgraph BrowserActions["Browser Actions"]
                    BrowserGoto["goto(url)"]
                    BrowserClick["click(element_id)"]
                    BrowserFill["fill(element_id, value)"]
                    BrowserScroll["scroll(x, y)"]
                    BrowserScreenshot["screenshot()"]
                    BrowserGoBack["go_back()"]
                    BrowserGoForward["go_forward()"]
                    BrowserPress["press(key)"]
                end
                
                subgraph SoMModule["Set-of-Mark (SoM)"]
                    SoMAnnotate["Annotate elements"]
                    SoMBoundingBoxes["Bounding boxes"]
                    SoMLabels["Element labels"]
                end
            end
            
            subgraph PluginsModule["Plugins (/runtime/plugins)"]
                PluginRequirement["PluginRequirement (base)"]
                
                subgraph AvailablePlugins["Available Plugins"]
                    JupyterPlugin["JupyterRequirement<br/>- IPython kernel<br/>- Code execution"]
                    AgentSkillsPlugin["AgentSkillsRequirement<br/>- Python helper functions<br/>- File operations"]
                    VSCodePlugin["VSCodeRequirement<br/>- VSCode server<br/>- Code editing UI"]
                end
            end
        end
        
        subgraph RuntimeUtils["Runtime Utilities (/runtime/utils)"]
            subgraph BashSessionModule["BashSession (bash_session.py)"]
                BashSessionClass["BashSession"]
                BashExecute["execute(command)"]
                BashParseOutput["parse_output()"]
                BashPS1Metadata["PS1 metadata parsing"]
            end
            
            subgraph GitHandlerModule["GitHandler (git_handler.py)"]
                GitHandlerClass["GitHandler"]
                GitClone["clone_repo()"]
                GitInit["init_repo()"]
                GitCommit["commit_changes()"]
                GitPush["push_changes()"]
                GitCheckout["checkout_branch()"]
            end
            
            subgraph LogStreamerModule["LogStreamer"]
                LogStreamerClass["LogStreamer"]
                StreamLogs["stream_logs()"]
            end
            
            subgraph EditModule["Edit Utils"]
                FileEditUtils["File edit utilities"]
                DiffGeneration["Diff generation"]
            end
        end
        
        subgraph RuntimeBuilder["Runtime Builder (/runtime/builder)"]
            BuilderClass["RuntimeBuilder"]
            BuildImage["build_image()"]
            PushImage["push_image()"]
            GetImageTag["get_image_tag()"]
        end
    end
    
    RuntimeBaseClass --> FileEditMixin
    RuntimeBaseClass --> RuntimeStatusEnum
    RuntimeBaseClass --> RuntimeImplementations
    RuntimeImplementations --> ThirdPartyRuntimes
    RuntimeImplementations --> RuntimeComponents
    RuntimeComponents --> RuntimeUtils
    DockerRuntimeModule --> RuntimeBuilder
```

## Иерархия классов Runtime

```mermaid
classDiagram
    class Runtime {
        <<abstract>>
        +sid: str
        +config: OpenHandsConfig
        +event_stream: EventStream
        +plugins: list~PluginRequirement~
        +workspace_root: Path
        +connect()
        +close()
        +run(action: Action) Observation
        +run_action(action: Action) Observation
        +add_env_vars(env_vars: dict)
        +clone_or_init_repo()
    }
    
    class FileEditRuntimeMixin {
        +edit_file(action: FileEditAction) Observation
    }
    
    class DockerRuntime {
        +container: Container
        +action_execution_server_url: str
        +connect()
        +close()
        +run(action) Observation
    }
    
    class LocalRuntime {
        +bash_session: BashSession
        +run(action) Observation
    }
    
    class RemoteRuntime {
        +runtime_url: str
        +run(action) Observation
    }
    
    class KubernetesRuntime {
        +pod_name: str
        +namespace: str
        +run(action) Observation
    }
    
    Runtime <|-- DockerRuntime
    Runtime <|-- LocalRuntime
    Runtime <|-- RemoteRuntime
    Runtime <|-- KubernetesRuntime
    Runtime <|.. FileEditRuntimeMixin
```

## Типы Runtime

| Runtime | Описание | Использование |
|---------|----------|---------------|
| **DockerRuntime** | Выполнение в Docker контейнере | Production, Development |
| **LocalRuntime** | Локальное выполнение | Development, Testing |
| **RemoteRuntime** | Удалённый сервер выполнения | Cloud deployment |
| **KubernetesRuntime** | Выполнение в K8s pod | Enterprise, Scale |
| **CLIRuntime** | Командная строка | CLI tools |
| **E2BRuntime** | E2B sandbox | Third-party |
| **DaytonaRuntime** | Daytona workspace | Third-party |
| **ModalRuntime** | Modal.com | Third-party |

## DockerRuntime - Основной Runtime

```mermaid
flowchart TB
    subgraph DockerRuntime["Docker Runtime"]
        Container["Docker Container"]
        
        subgraph Inside["Внутри контейнера"]
            ActionServer["Action Execution Server<br/>:8000"]
            BashSession["Bash Session"]
            IPython["IPython Kernel"]
            Browser["Playwright Browser"]
            FileSystem["File System<br/>/workspace"]
        end
        
        subgraph Plugins["Plugins"]
            JupyterPlugin["Jupyter Plugin"]
            AgentSkills["Agent Skills"]
            VSCodePlugin["VSCode Plugin"]
        end
    end
    
    subgraph Host["Host Machine"]
        OpenHands["OpenHands Server"]
        DockerSocket["Docker Socket"]
    end
    
    OpenHands -->|HTTP| ActionServer
    OpenHands -->|Docker API| DockerSocket
    DockerSocket --> Container
    
    ActionServer --> BashSession
    ActionServer --> IPython
    ActionServer --> Browser
    ActionServer --> FileSystem
    
    JupyterPlugin --> IPython
    AgentSkills --> BashSession
```

## Жизненный цикл Runtime

```mermaid
stateDiagram-v2
    [*] --> Created: create_runtime()
    Created --> Connecting: connect()
    Connecting --> Connected: Runtime ready
    Connected --> Running: run(action)
    Running --> Connected: Observation returned
    Connected --> Closing: close()
    Closing --> [*]: Cleanup complete
    
    Connected --> Error: Exception
    Error --> Closing: Handle error
```

## Выполнение действий

```mermaid
sequenceDiagram
    participant Controller as AgentController
    participant Runtime as Runtime
    participant ActionServer as Action Execution Server
    participant Bash as Bash Session
    participant FS as File System

    Controller->>Runtime: run(CmdRunAction)
    Runtime->>ActionServer: POST /execute
    ActionServer->>Bash: Execute command
    Bash-->>ActionServer: Output + exit code
    ActionServer-->>Runtime: CmdOutputObservation
    Runtime-->>Controller: Observation

    Controller->>Runtime: run(FileEditAction)
    Runtime->>ActionServer: POST /execute
    ActionServer->>FS: Edit file
    FS-->>ActionServer: Result
    ActionServer-->>Runtime: FileEditObservation
    Runtime-->>Controller: Observation
```

## Plugins

```mermaid
classDiagram
    class PluginRequirement {
        <<abstract>>
        +name: str
    }
    
    class JupyterRequirement {
        +name: str = "jupyter"
    }
    
    class AgentSkillsRequirement {
        +name: str = "agent_skills"
    }
    
    class VSCodeRequirement {
        +name: str = "vscode"
    }
    
    PluginRequirement <|-- JupyterRequirement
    PluginRequirement <|-- AgentSkillsRequirement
    PluginRequirement <|-- VSCodeRequirement
```

### Описание плагинов

| Plugin | Описание |
|--------|----------|
| **JupyterRequirement** | IPython kernel для выполнения Python кода |
| **AgentSkillsRequirement** | Набор Python функций для агента |
| **VSCodeRequirement** | VSCode server для редактирования (не в headless mode) |

## Browser Environment

```mermaid
flowchart TB
    subgraph BrowserEnv["Browser Environment"]
        Playwright["Playwright"]
        Chromium["Chromium Browser"]
        
        subgraph Actions["Browser Actions"]
            Goto["goto(url)"]
            Click["click(element)"]
            Fill["fill(input, value)"]
            Scroll["scroll(x, y)"]
            Screenshot["screenshot()"]
        end
    end
    
    subgraph SoM["Set-of-Mark (SoM)"]
        Annotate["Annotate elements"]
        BoundingBoxes["Bounding boxes"]
        Labels["Element labels"]
    end
    
    Playwright --> Chromium
    Chromium --> Actions
    Actions --> SoM
```

## Git Handler

```mermaid
flowchart TB
    subgraph GitHandler["Git Handler"]
        Clone["clone_repo()"]
        Init["init_repo()"]
        Commit["commit_changes()"]
        Push["push_changes()"]
        
        subgraph Providers["Git Providers"]
            GitHub["GitHub"]
            GitLab["GitLab"]
            Bitbucket["Bitbucket"]
            AzureDevOps["Azure DevOps"]
        end
    end
    
    Clone --> Providers
    Push --> Providers
```

## Конфигурация Runtime

```mermaid
classDiagram
    class SandboxConfig {
        +runtime: str
        +base_container_image: str
        +timeout: int
        +enable_auto_lint: bool
        +use_host_network: bool
        +selected_repo: str
        +selected_branch: str
        +runtime_startup_env_vars: dict
    }
    
    class OpenHandsConfig {
        +sandbox: SandboxConfig
        +workspace_base: str
        +workspace_mount_path: str
    }
    
    OpenHandsConfig --> SandboxConfig
```

## Пример конфигурации

```toml
[sandbox]
runtime = "docker"
base_container_image = "nikolaik/python-nodejs:python3.12-nodejs22"
timeout = 120
enable_auto_lint = true
use_host_network = false

[core]
workspace_base = "./workspace"
```

## Action Execution Server API

| Endpoint | Method | Описание |
|----------|--------|----------|
| `/execute` | POST | Выполнить действие |
| `/alive` | GET | Health check |
| `/upload_file` | POST | Загрузить файл |
| `/download_file` | GET | Скачать файл |
| `/list_files` | GET | Список файлов |
