# Server & Frontend Layer

## Обзор

Server Layer предоставляет REST API и WebSocket для взаимодействия с Frontend. Frontend — это React приложение для пользовательского интерфейса.

## Детальная архитектура Server Layer

```mermaid
flowchart TB
    subgraph ServerLayer["🌐 SERVER LAYER"]
        direction TB
        
        subgraph V0Server["V0 Server (Legacy) - /openhands/server"]
            subgraph V0Core["Core Components"]
                AppPy["app.py<br/>FastAPI Application"]
                ListenPy["listen.py<br/>Entry Point + Middleware"]
                ListenSocket["listen_socket.py<br/>Socket.IO Server"]
                SharedPy["shared.py<br/>Global instances"]
            end
            
            subgraph V0Routes["Routes (/server/routes)"]
                ConversationRoute["conversation.py<br/>POST /api/conversations<br/>GET /api/conversations<br/>DELETE /api/conversations/{id}"]
                ManageConvRoute["manage_conversations.py<br/>Conversation management"]
                FilesRoute["files.py<br/>GET /api/files<br/>POST /api/files/upload"]
                SettingsRoute["settings.py<br/>GET/POST /api/settings"]
                SecretsRoute["secrets.py<br/>GET/POST/DELETE /api/secrets"]
                GitRoute["git.py<br/>GET /api/git/repos<br/>GET /api/git/branches"]
                HealthRoute["health.py<br/>GET /health<br/>GET /api/health"]
                MCPRoute["mcp.py<br/>MCP server endpoints"]
                SecurityRoute["security.py<br/>Security endpoints"]
                FeedbackRoute["feedback.py<br/>Feedback endpoints"]
                TrajectoryRoute["trajectory.py<br/>Trajectory endpoints"]
                PublicRoute["public.py<br/>Public endpoints"]
            end
            
            subgraph V0Middleware["Middleware"]
                CORSMiddleware["LocalhostCORSMiddleware"]
                CacheMiddleware["CacheControlMiddleware"]
                RateLimitMiddleware["RateLimitMiddleware<br/>InMemoryRateLimiter"]
            end
            
            subgraph V0Session["Session Management (/server/session)"]
                AgentSession["AgentSession"]
                SessionClass["Session"]
                ConvInitData["ConversationInitData"]
            end
            
            subgraph V0Services["Services (/server/services)"]
                ConversationService["ConversationService"]
                ConversationStats["ConversationStats"]
            end
            
            subgraph V0ConvManager["Conversation Manager (/server/conversation_manager)"]
                ConvManagerClass["ConversationManager"]
                StandaloneConvManager["StandaloneConversationManager"]
            end
            
            subgraph V0Config["Configuration"]
                ServerConfig["ServerConfig"]
                FileConfig["FileConfig"]
                AppMode["AppMode Enum"]
            end
            
            subgraph V0Auth["User Auth (/server/user_auth)"]
                UserAuth["User authentication"]
            end
        end
        
        subgraph V1Server["V1 Server (New) - /openhands/app_server"]
            subgraph V1Core["Core Components"]
                V1Router["v1_router.py<br/>Main router"]
                V1Config["config.py<br/>Configuration"]
                V1Errors["errors.py<br/>Error handling"]
            end
            
            subgraph V1AppConversation["app_conversation/"]
                AppConvRouter["app_conversation_router.py"]
                AppConvService["app_conversation_service.py"]
                AppConvServiceBase["app_conversation_service_base.py"]
                AppConvModels["app_conversation_models.py"]
                AppConvInfoService["app_conversation_info_service.py"]
                AppConvStartTask["app_conversation_start_task_service.py"]
                LiveStatusService["live_status_app_conversation_service.py"]
                SkillLoader["skill_loader.py"]
                
                subgraph AppConvGit["git/"]
                    GitIntegration["Git integration"]
                end
                
                subgraph SQLServices["SQL Services"]
                    SQLAppConvInfo["sql_app_conversation_info_service.py"]
                    SQLAppConvStartTask["sql_app_conversation_start_task_service.py"]
                end
            end
            
            subgraph V1Event["event/"]
                EventRouter["event_router.py"]
                EventService["event_service.py"]
                EventServiceBase["event_service_base.py"]
                EventStore["event_store.py"]
                FSEventService["filesystem_event_service.py"]
                GCSEventService["google_cloud_event_service.py"]
            end
            
            subgraph V1Sandbox["sandbox/"]
                SandboxRouter["sandbox_router.py"]
                SandboxService["sandbox_service.py"]
                SandboxModels["sandbox_models.py"]
                DockerSandboxService["docker_sandbox_service.py"]
                ProcessSandboxService["process_sandbox_service.py"]
                RemoteSandboxService["remote_sandbox_service.py"]
                
                subgraph SandboxSpec["Sandbox Spec"]
                    SandboxSpecRouter["sandbox_spec_router.py"]
                    SandboxSpecService["sandbox_spec_service.py"]
                    SandboxSpecModels["sandbox_spec_models.py"]
                    PresetSandboxSpec["preset_sandbox_spec_service.py"]
                end
            end
            
            subgraph V1User["user/"]
                UserRouter["user_router.py"]
                UserModels["user_models.py"]
                UserContext["user_context.py"]
                AuthUserContext["auth_user_context.py"]
                SpecifyUserContext["specify_user_context.py"]
            end
            
            subgraph V1WebClient["web_client/"]
                WebClientRouter["web_client_router.py"]
                WebClientModels["web_client_models.py"]
                WebClientConfigInjector["web_client_config_injector.py"]
                DefaultWebClientConfig["default_web_client_config_injector.py"]
            end
            
            subgraph V1EventCallback["event_callback/"]
                EventCallbackService["event_callback_service.py"]
                EventCallbackModels["event_callback_models.py"]
                EventCallbackResult["event_callback_result_models.py"]
                WebhookRouter["webhook_router.py"]
                SetTitleCallback["set_title_callback_processor.py"]
                SQLEventCallback["sql_event_callback_service.py"]
            end
            
            subgraph V1Services["services/"]
                JWTService["jwt_service.py"]
                DBSessionInjector["db_session_injector.py"]
                HTTPXClientInjector["httpx_client_injector.py"]
                Injector["injector.py"]
            end
            
            subgraph V1Utils["utils/"]
                DockerUtils["docker_utils.py"]
                EncryptionKey["encryption_key.py"]
                ImportUtils["import_utils.py"]
                LLMMetadata["llm_metadata.py"]
                SQLUtils["sql_utils.py"]
            end
            
            subgraph V1Lifespan["app_lifespan/"]
                AppLifespanService["app_lifespan_service.py"]
                OSSAppLifespan["oss_app_lifespan_service.py"]
                
                subgraph Alembic["alembic/"]
                    AlembicMigrations["Database migrations"]
                end
            end
        end
        
        subgraph SocketIOServer["Socket.IO Server"]
            SIOApp["socketio.ASGIApp"]
            SIONamespace["Namespace handlers"]
            
            subgraph SIOEvents["Events"]
                SIOConnect["connect"]
                SIODisconnect["disconnect"]
                SIOSubscribe["subscribe"]
                SIOUnsubscribe["unsubscribe"]
                SIOSendMessage["send_message"]
                SIOEvent["event (broadcast)"]
                SIOStatus["status"]
            end
        end
    end
    
    V0Core --> V0Routes
    V0Core --> V0Middleware
    V0Core --> SocketIOServer
    V0Routes --> V0Session
    V0Routes --> V0Services
    V0Routes --> V0ConvManager
    
    V1Core --> V1AppConversation
    V1Core --> V1Event
    V1Core --> V1Sandbox
    V1Core --> V1User
    V1Core --> V1WebClient
    V1Core --> V1EventCallback
    V1Core --> V1Services
    V1Core --> V1Lifespan
```

## Детальная архитектура Frontend Layer

```mermaid
flowchart TB
    subgraph FrontendLayer["🖥️ FRONTEND LAYER"]
        direction TB
        
        subgraph FrontendCore["Frontend Core (/frontend/src)"]
            subgraph EntryPoints["Entry Points"]
                RootTsx["root.tsx<br/>App root"]
                EntryClient["entry.client.tsx<br/>Client entry"]
                RoutesTsx["routes.ts<br/>Route definitions"]
            end
            
            subgraph QueryConfig["Query Configuration"]
                QueryClientConfig["query-client-config.ts<br/>TanStack Query setup"]
            end
        end
        
        subgraph APILayer["API Layer (/src/api)"]
            subgraph APICore["Core"]
                OpenHandsAxios["open-hands-axios.ts<br/>Axios instance"]
                OpenHandsTypes["open-hands.types.ts<br/>Type definitions"]
            end
            
            subgraph APIServices["API Services"]
                ConversationServiceAPI["conversation-service/<br/>Conversation CRUD"]
                EventServiceAPI["event-service/<br/>Event handling"]
                SettingsServiceAPI["settings-service/<br/>Settings management"]
                SecretsServiceAPI["secrets-service.ts<br/>Secrets management"]
                GitServiceAPI["git-service/<br/>Git operations"]
                AuthServiceAPI["auth-service/<br/>Authentication"]
                BillingServiceAPI["billing-service/<br/>Billing (SaaS)"]
                UserServiceAPI["user-service/<br/>User management"]
                SandboxServiceAPI["sandbox-service/<br/>Sandbox management"]
                OptionServiceAPI["option-service/<br/>Options/config"]
                SuggestionsServiceAPI["suggestions-service/<br/>Task suggestions"]
                IntegrationServiceAPI["integration-service/<br/>Integrations"]
                MicroagentServiceAPI["microagent-management-service/<br/>Microagents"]
            end
            
            subgraph APIUtils["Utilities"]
                ConversationUtils["conversation.utils.ts"]
                InvariantService["invariant-service.ts"]
                APIKeys["api-keys.ts"]
                SharedConvService["shared-conversation-service.api.ts"]
            end
        end
        
        subgraph ComponentsLayer["Components (/src/components)"]
            subgraph Features["features/"]
                ChatFeature["Chat components"]
                TerminalFeature["Terminal components"]
                FileExplorerFeature["File explorer"]
                BrowserFeature["Browser preview"]
                SettingsFeature["Settings UI"]
            end
            
            subgraph Shared["shared/"]
                SharedComponents["Shared components"]
            end
            
            subgraph UI["ui/"]
                UIComponents["UI primitives"]
            end
            
            subgraph V1Components["v1/"]
                V1UIComponents["V1 specific components"]
            end
            
            subgraph Providers["providers/"]
                ProviderComponents["Context providers"]
            end
        end
        
        subgraph HooksLayer["Hooks (/src/hooks)"]
            subgraph ChatHooks["chat/"]
                UseSendMessage["use-send-message.ts"]
            end
            
            subgraph MutationHooks["mutation/"]
                MutationHooksFiles["Mutation hooks"]
            end
            
            subgraph QueryHooks["query/"]
                QueryHooksFiles["Query hooks"]
            end
            
            subgraph GeneralHooks["General Hooks"]
                UseAgentState["use-agent-state.ts"]
                UseWebSocket["use-websocket.ts"]
                UseTerminal["use-terminal.ts"]
                UseConversationId["use-conversation-id.ts"]
                UseRuntimeIsReady["use-runtime-is-ready.ts"]
                UseHandleWSEvents["use-handle-ws-events.ts"]
                UseV0HandleWSEvents["use-v0-handle-ws-events.ts"]
                UseHandleRuntimeActive["use-handle-runtime-active.ts"]
                UseDownloadConversation["use-download-conversation.ts"]
                UseAutoLogin["use-auto-login.ts"]
                UseAuthCallback["use-auth-callback.ts"]
                UseGitHubAuthUrl["use-github-auth-url.ts"]
                UseUserProviders["use-user-providers.ts"]
                UseSettingsNavItems["use-settings-nav-items.ts"]
            end
        end
        
        subgraph ContextLayer["Context (/src/context & /src/contexts)"]
            WSClientProvider["ws-client-provider.tsx<br/>WebSocket client"]
            ConvSubscriptionsProvider["conversation-subscriptions-provider.tsx"]
            ScrollContext["scroll-context.tsx"]
            ConvWebSocketContext["conversation-websocket-context.tsx"]
            WebSocketProviderWrapper["websocket-provider-wrapper.tsx"]
        end
        
        subgraph RoutesLayer["Routes (/src/routes)"]
            ConversationRoute["conversation.tsx"]
            SettingsRoutes["app-settings.tsx"]
            BillingRoute["billing.tsx"]
            APIKeysRoute["api-keys.tsx"]
            AcceptTOSRoute["accept-tos.tsx"]
            BrowserTabRoute["browser-tab.tsx"]
            ChangesTabRoute["changes-tab.tsx"]
            TerminalTabRoute["terminal-tab.tsx"]
            JupyterTabRoute["jupyter-tab.tsx"]
            VSCodeTabRoute["vscode-tab.tsx"]
        end
        
        subgraph I18nLayer["Internationalization (/src/i18n)"]
            I18nIndex["index.ts"]
            I18nDeclaration["declaration.ts"]
            TranslationJSON["translation.json"]
        end
        
        subgraph MocksLayer["Mocks (/src/mocks)"]
            MockHandlers["handlers.ts"]
            MockHandlersWS["handlers.ws.ts"]
            MockBrowser["browser.ts"]
            MockNode["node.ts"]
            SpecificMocks["Specific mock handlers"]
        end
        
        subgraph AssetsLayer["Assets"]
            Icons["icons/"]
            Branding["assets/branding/"]
            Styles["index.css"]
        end
    end
    
    FrontendCore --> APILayer
    FrontendCore --> ComponentsLayer
    FrontendCore --> HooksLayer
    FrontendCore --> ContextLayer
    FrontendCore --> RoutesLayer
    ComponentsLayer --> HooksLayer
    HooksLayer --> APILayer
    HooksLayer --> ContextLayer
```

## V0 Server Routes

```mermaid
classDiagram
    class ConversationRoutes {
        +POST /api/conversations
        +GET /api/conversations
        +GET /api/conversations/{id}
        +DELETE /api/conversations/{id}
        +POST /api/conversations/{id}/start
    }
    
    class FilesRoutes {
        +GET /api/files
        +POST /api/files/upload
        +GET /api/files/download
    }
    
    class SettingsRoutes {
        +GET /api/settings
        +POST /api/settings
    }
    
    class SecretsRoutes {
        +GET /api/secrets
        +POST /api/secrets
        +DELETE /api/secrets/{name}
    }
    
    class GitRoutes {
        +GET /api/git/repos
        +GET /api/git/branches
        +POST /api/git/clone
    }
    
    class HealthRoutes {
        +GET /health
        +GET /api/health
    }
```

## WebSocket Communication

```mermaid
sequenceDiagram
    participant Client as Frontend
    participant SocketIO as Socket.IO Server
    participant ConvManager as ConversationManager
    participant EventStream as EventStream

    Client->>SocketIO: connect()
    SocketIO-->>Client: connected
    
    Client->>SocketIO: subscribe(conversation_id)
    SocketIO->>ConvManager: get_conversation(id)
    ConvManager->>EventStream: subscribe(callback)
    
    loop События
        EventStream->>SocketIO: on_event(event)
        SocketIO->>Client: emit("event", event)
    end
    
    Client->>SocketIO: send_message(content)
    SocketIO->>EventStream: add_event(MessageAction)
    
    Client->>SocketIO: disconnect()
    SocketIO->>EventStream: unsubscribe()
```

## Socket.IO Events

| Event | Direction | Описание |
|-------|-----------|----------|
| `connect` | Client → Server | Подключение |
| `disconnect` | Client → Server | Отключение |
| `subscribe` | Client → Server | Подписка на conversation |
| `unsubscribe` | Client → Server | Отписка |
| `send_message` | Client → Server | Отправка сообщения |
| `event` | Server → Client | Событие из EventStream |
| `status` | Server → Client | Статус runtime |
| `error` | Server → Client | Ошибка |

## V1 Server Architecture

```mermaid
flowchart TB
    subgraph V1Server["V1 Application Server"]
        Router["v1_router.py"]
        
        subgraph AppConversation["app_conversation/"]
            ConvRouter["app_conversation_router.py"]
            ConvService["app_conversation_service.py"]
            ConvModels["app_conversation_models.py"]
        end
        
        subgraph Event["event/"]
            EventRouter["event_router.py"]
            EventService["event_service.py"]
            EventStore["event_store.py"]
        end
        
        subgraph Sandbox["sandbox/"]
            SandboxRouter["sandbox_router.py"]
            SandboxService["sandbox_service.py"]
            DockerSandbox["docker_sandbox_service.py"]
            RemoteSandbox["remote_sandbox_service.py"]
        end
        
        subgraph User["user/"]
            UserRouter["user_router.py"]
            UserContext["user_context.py"]
            AuthContext["auth_user_context.py"]
        end
    end
    
    Router --> AppConversation
    Router --> Event
    Router --> Sandbox
    Router --> User
```

## Frontend Architecture

```mermaid
flowchart TB
    subgraph Frontend["Frontend (/frontend)"]
        subgraph Core["Core"]
            App["App.tsx"]
            Routes["routes/"]
            Providers["providers/"]
        end
        
        subgraph API["API Layer"]
            OpenHandsAxios["open-hands-axios.ts"]
            ConversationAPI["conversation-service/"]
            EventAPI["event-service/"]
            SettingsAPI["settings-service/"]
            GitAPI["git-service/"]
        end
        
        subgraph Components["Components"]
            Features["features/"]
            Shared["shared/"]
            UI["ui/"]
        end
        
        subgraph State["State Management"]
            Hooks["hooks/"]
            Context["context/"]
            QueryClient["React Query"]
        end
        
        subgraph WebSocket["WebSocket"]
            WSProvider["ws-client-provider.tsx"]
            WSContext["websocket-context.tsx"]
        end
    end
    
    App --> Routes
    App --> Providers
    Routes --> Components
    Components --> API
    Components --> State
    State --> WebSocket
```

## Frontend Routes

```mermaid
flowchart TB
    subgraph Routes["Frontend Routes"]
        Root["/"]
        Conversation["/conversation/:id"]
        Settings["/settings"]
        APIKeys["/api-keys"]
        Billing["/billing"]
        AcceptTOS["/accept-tos"]
    end
    
    Root --> Conversation
    Root --> Settings
    Settings --> APIKeys
    Settings --> Billing
```

## API Services

```mermaid
classDiagram
    class ConversationService {
        +createConversation()
        +getConversations()
        +getConversation(id)
        +deleteConversation(id)
        +startConversation(id, task)
    }
    
    class EventService {
        +getEvents(conversationId)
        +sendMessage(conversationId, content)
    }
    
    class SettingsService {
        +getSettings()
        +saveSettings(settings)
    }
    
    class GitService {
        +getRepositories()
        +getBranches(repo)
        +cloneRepository(url)
    }
    
    class SecretsService {
        +getSecrets()
        +addSecret(name, value)
        +deleteSecret(name)
    }
```

## WebSocket Provider

```mermaid
flowchart TB
    subgraph WSProvider["WebSocket Provider"]
        Connect["connect()"]
        Subscribe["subscribe(conversationId)"]
        
        subgraph Handlers["Event Handlers"]
            OnEvent["onEvent()"]
            OnStatus["onStatus()"]
            OnError["onError()"]
        end
        
        subgraph State["State"]
            Connected["isConnected"]
            Events["events[]"]
            Status["runtimeStatus"]
        end
    end
    
    Connect --> Subscribe
    Subscribe --> Handlers
    Handlers --> State
```

## Middleware

```mermaid
flowchart TB
    subgraph Middleware["Server Middleware"]
        CORS["LocalhostCORSMiddleware"]
        Cache["CacheControlMiddleware"]
        RateLimit["RateLimitMiddleware"]
        Auth["Authentication"]
    end
    
    Request["HTTP Request"]
    Response["HTTP Response"]
    
    Request --> CORS
    CORS --> Cache
    Cache --> RateLimit
    RateLimit --> Auth
    Auth --> Handler["Route Handler"]
    Handler --> Response
```

## ConversationManager

```mermaid
classDiagram
    class ConversationManager {
        +conversations: dict
        +create_conversation(settings) Conversation
        +get_conversation(id) Conversation
        +delete_conversation(id)
        +start_conversation(id, task)
        +stop_conversation(id)
    }
    
    class Conversation {
        +id: str
        +event_stream: EventStream
        +runtime: Runtime
        +controller: AgentController
        +status: ConversationStatus
    }
    
    class ConversationStatus {
        <<enumeration>>
        CREATED
        RUNNING
        PAUSED
        FINISHED
        ERROR
    }
    
    ConversationManager --> Conversation
    Conversation --> ConversationStatus
```

## Запуск сервера

### Development Mode

```bash
# Backend (порт 3000)
make start-backend

# Frontend (порт 3001)
make start-frontend

# Или вместе
make run
```

### Production Mode

```bash
# Docker
make docker-run

# Или напрямую
docker compose up
```

## Конфигурация сервера

```python
# openhands/server/shared.py
server_config = ServerConfig(
    app_mode=AppMode.OPENHANDS,
    enable_v1=True,
    file_store="local",
    ...
)
```
