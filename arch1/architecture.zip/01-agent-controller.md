# Agent & Controller Layer

## Обзор

Слой агентов и контроллера — это "мозг" OpenHands. Он отвечает за:
- Управление жизненным циклом агента
- Обработку действий и наблюдений
- Взаимодействие с LLM
- Управление состоянием сессии

## Детальная архитектура Agent Layer

```mermaid
flowchart TB
    subgraph AgentLayer["🤖 AGENT LAYER"]
        direction TB
        
        subgraph AgentBase["Agent Base Class (controller/agent.py)"]
            AgentClass["Agent"]
            AgentName["name: str"]
            AgentConfig["config: AgentConfig"]
            AgentLLM["llm: LLM"]
            AgentMCPTools["mcp_tools: dict"]
            AgentPromptManager["_prompt_manager: PromptManager"]
            
            subgraph AgentMethods["Methods"]
                StepMethod["step(state: State) → Action"]
                ResetMethod["reset()"]
                GetSystemMsg["get_system_message() → SystemMessageAction"]
                AddMCPTools["add_mcp_tools(tools)"]
            end
        end
        
        subgraph AgentHub["Agent Hub (/openhands/agenthub)"]
            subgraph CodeActAgentModule["CodeActAgent (Main)"]
                CodeActClass["CodeActAgent v2.2"]
                CodeActVersion["VERSION = '2.2'"]
                
                subgraph CodeActComponents["Components"]
                    PendingActions["pending_actions: deque[Action]"]
                    ConvMemory["conversation_memory: ConversationMemory"]
                    CondenserInst["condenser: Condenser"]
                    ToolsList["tools: list[ChatCompletionToolParam]"]
                end
                
                subgraph CodeActMethods["Methods"]
                    CodeActStep["step(state) → Action"]
                    GetMessages["_get_messages(events) → list[Message]"]
                    GetInitialMsg["_get_initial_user_message(history)"]
                    ResponseToActions["response_to_actions(response) → list[Action]"]
                    GetTools["_get_tools() → list[Tool]"]
                end
            end
            
            subgraph OtherAgents["Other Agents"]
                BrowsingAgentClass["BrowsingAgent<br/>Web browsing specialist"]
                ReadonlyAgentClass["ReadonlyAgent<br/>Read-only operations"]
                VisualBrowsingClass["VisualBrowsingAgent<br/>Visual SoM browsing"]
                LocAgentClass["LocAgent<br/>Code localization"]
                DummyAgentClass["DummyAgent<br/>Testing purposes"]
            end
        end
        
        subgraph AgentTools["Agent Tools (/agenthub/codeact_agent/tools)"]
            subgraph CoreTools["Core Tools"]
                CmdRunTool["cmd_run<br/>Execute bash commands"]
                IPythonTool["ipython<br/>Execute Python code"]
                StrReplaceEditor["str_replace_editor<br/>File editing (ACI)"]
                BrowserTool["browser<br/>Web interaction"]
            end
            
            subgraph UtilityTools["Utility Tools"]
                ThinkTool["think<br/>Log reasoning"]
                FinishTool["finish<br/>Complete task"]
                TaskTrackerTool["task_tracker<br/>Task management"]
                CondensationReq["condensation_request<br/>Request memory condensation"]
            end
            
            subgraph AdvancedTools["Advanced Tools"]
                LLMEditorTool["llm_based_edit<br/>AI-powered file editing"]
            end
        end
        
        subgraph PluginRequirements["Plugin Requirements"]
            AgentSkillsReq["AgentSkillsRequirement<br/>Python helper functions"]
            JupyterReq["JupyterRequirement<br/>IPython kernel"]
            VSCodeReq["VSCodeRequirement<br/>VSCode server (non-headless)"]
        end
    end
    
    AgentBase --> AgentHub
    CodeActAgentModule --> AgentTools
    CodeActAgentModule --> PluginRequirements
```

## Детальная архитектура Controller Layer

```mermaid
flowchart TB
    subgraph ControllerLayer["⚙️ CONTROLLER LAYER"]
        direction TB
        
        subgraph AgentControllerClass["AgentController (/controller/agent_controller.py)"]
            subgraph ControllerAttributes["Attributes"]
                ControllerId["id: str"]
                ControllerAgent["agent: Agent"]
                ControllerEventStream["event_stream: EventStream"]
                ControllerState["state: State"]
                MaxIterations["max_iterations: int"]
                ConfirmationMode["confirmation_mode: bool"]
                Delegate["delegate: AgentController | None"]
                Parent["parent: AgentController | None"]
                PendingAction["_pending_action_info: tuple[Action, float]"]
                SecurityAnalyzer["security_analyzer: SecurityAnalyzer"]
            end
            
            subgraph ControllerMethods["Methods"]
                ControllerStep["step() → async"]
                StepWithException["_step_with_exception_handling()"]
                OnEvent["on_event(event: Event)"]
                SetAgentState["set_agent_state_to(state: AgentState)"]
                HandleSecurityAnalyzer["_handle_security_analyzer(action)"]
                AddSystemMessage["_add_system_message()"]
                ReactToException["_react_to_exception(e)"]
                Close["close(set_stop_state: bool)"]
                GetTrajectory["get_trajectory() → list"]
            end
            
            subgraph ControllerHelpers["Helper Components"]
                StateTrackerInst["state_tracker: StateTracker"]
                StuckDetectorInst["_stuck_detector: StuckDetector"]
                ReplayManagerInst["_replay_manager: ReplayManager"]
                ConversationStats["conversation_stats: ConversationStats"]
            end
        end
        
        subgraph StateManagement["State Management (/controller/state)"]
            subgraph StateClass["State Class"]
                StateHistory["history: list[Event]"]
                StateIteration["iteration: int"]
                StateAgentState["agent_state: AgentState"]
                StateLastError["last_error: str | None"]
                StateStartId["start_id: int"]
                StateMetrics["metrics: Metrics"]
                
                subgraph StateMethods["Methods"]
                    GetLastUserMsg["get_last_user_message() → MessageAction"]
                    SaveToSession["save_to_session(sid, file_store)"]
                    RestoreFromSession["restore_from_session()"]
                    ToLLMMetadata["to_llm_metadata() → dict"]
                end
            end
            
            subgraph StateTrackerClass["StateTracker"]
                TrackerState["state: State"]
                TrackerSid["sid: str"]
                TrackerFileStore["file_store: FileStore"]
                TrackerClose["close(event_stream)"]
            end
        end
        
        subgraph StuckDetection["Stuck Detection (/controller/stuck.py)"]
            StuckDetectorClass["StuckDetector"]
            StuckState["state: State"]
            IsStuck["is_stuck() → bool"]
            DetectLoop["_detect_action_loop()"]
            DetectRepetition["_detect_repetitive_actions()"]
        end
        
        subgraph ReplayModule["Replay Module (/controller/replay.py)"]
            ReplayManagerClass["ReplayManager"]
            ReplayEvents["replay_events: list[Event]"]
            GetReplayEvents["get_replay_events(trajectory) → list[Event]"]
        end
        
        subgraph AgentStates["Agent States (core/schema)"]
            direction LR
            LOADING["LOADING"]
            INIT["INIT"]
            RUNNING["RUNNING"]
            PAUSED["PAUSED"]
            STOPPED["STOPPED"]
            FINISHED["FINISHED"]
            REJECTED["REJECTED"]
            ERROR["ERROR"]
            AWAITING_INPUT["AWAITING_USER_INPUT"]
            RATE_LIMITED["RATE_LIMITED"]
        end
    end
    
    AgentControllerClass --> StateManagement
    AgentControllerClass --> StuckDetection
    AgentControllerClass --> ReplayModule
    StateClass --> AgentStates
```

## Иерархия классов агентов

```mermaid
classDiagram
    class Agent {
        <<abstract>>
        +name: str
        +config: AgentConfig
        +llm: LLM
        +llm_registry: LLMRegistry
        +mcp_tools: dict[str, MCPTool]
        +sandbox_plugins: list[PluginRequirement]
        -_prompt_manager: PromptManager
        +step(state: State) Action*
        +reset()
        +get_system_message() SystemMessageAction
        +add_mcp_tools(tools: dict)
        #prompt_manager() PromptManager
    }
    
    class CodeActAgent {
        +VERSION: str = "2.2"
        +sandbox_plugins: list
        +pending_actions: deque[Action]
        +tools: list[ChatCompletionToolParam]
        +conversation_memory: ConversationMemory
        +condenser: Condenser
        +step(state: State) Action
        +reset()
        -_get_tools() list[ChatCompletionToolParam]
        -_get_messages(events, initial_msg, forgotten_ids) list[Message]
        -_get_initial_user_message(history) MessageAction
        +response_to_actions(response: ModelResponse) list[Action]
    }
    
    class BrowsingAgent {
        +response_parser: ResponseParser
        +step(state: State) Action
        -_parse_response(response) Action
    }
    
    class ReadonlyAgent {
        +tools: list[ChatCompletionToolParam]
        +step(state: State) Action
        -_get_tools() list
    }
    
    class VisualBrowsingAgent {
        +step(state: State) Action
    }
    
    class LocAgent {
        +tools: list[ChatCompletionToolParam]
        +step(state: State) Action
    }
    
    class DummyAgent {
        +step(state: State) Action
    }
    
    Agent <|-- CodeActAgent
    Agent <|-- BrowsingAgent
    Agent <|-- ReadonlyAgent
    Agent <|-- VisualBrowsingAgent
    Agent <|-- LocAgent
    Agent <|-- DummyAgent
```

## Доступные агенты

| Агент | Путь | Описание | Plugins |
|-------|------|----------|---------|
| **CodeActAgent** | `/agenthub/codeact_agent` | Основной агент для написания кода. Использует function calling. | AgentSkills, Jupyter |
| **BrowsingAgent** | `/agenthub/browsing_agent` | Агент для веб-браузинга | - |
| **ReadonlyAgent** | `/agenthub/readonly_agent` | Агент только для чтения (без изменений) | - |
| **VisualBrowsingAgent** | `/agenthub/visualbrowsing_agent` | Визуальный браузинг с SoM | - |
| **LocAgent** | `/agenthub/loc_agent` | Агент для локализации кода | - |
| **DummyAgent** | `/agenthub/dummy_agent` | Тестовый агент | - |

## CodeActAgent - Детальная архитектура

```mermaid
flowchart TB
    subgraph CodeActAgentDetail["CodeActAgent Detailed Flow"]
        direction TB
        
        subgraph Initialization["Initialization"]
            Init["__init__(config, llm_registry)"]
            CreateTools["_get_tools()"]
            CreateMemory["ConversationMemory(config, prompt_manager)"]
            CreateCondenser["Condenser.from_config(config.condenser)"]
            GetRouter["llm_registry.get_router(config)"]
        end
        
        subgraph StepFlow["step(state) Flow"]
            CheckPending["Check pending_actions"]
            CheckExit["Check /exit command"]
            
            subgraph CondenseHistory["Condense History"]
                CallCondenser["condenser.condensed_history(state)"]
                
                subgraph CondenseResult["Result"]
                    ViewResult["View(events, forgotten_ids)"]
                    CondensationResult["Condensation(action)"]
                end
            end
            
            subgraph ProcessMessages["Process Messages"]
                GetInitialMsg["_get_initial_user_message(history)"]
                CallGetMessages["_get_messages(events, initial_msg, forgotten_ids)"]
                
                subgraph MemoryProcess["ConversationMemory.process_events()"]
                    EnsureSystem["_ensure_system_message()"]
                    EnsureInitial["_ensure_initial_user_message()"]
                    ProcessActions["_process_action() for each"]
                    ProcessObs["_process_observation() for each"]
                    FilterUnmatched["_filter_unmatched_tool_calls()"]
                    ApplyFormatting["_apply_user_message_formatting()"]
                end
            end
            
            subgraph LLMCall["LLM Call"]
                PrepareParams["Prepare params: messages, tools, extra_body"]
                CheckTools["check_tools(tools, llm.config)"]
                Completion["llm.completion(**params)"]
            end
            
            subgraph ProcessResponse["Process Response"]
                CallResponseToActions["response_to_actions(response)"]
                
                subgraph FunctionCalling["function_calling.py"]
                    ParseToolCalls["Parse tool_calls from response"]
                    CreateActions["Create Action objects"]
                    HandleMCP["Handle MCP tools"]
                end
                
                AddToPending["Add to pending_actions"]
                ReturnFirst["Return pending_actions.popleft()"]
            end
        end
        
        Initialization --> StepFlow
        CheckPending -->|"has pending"| ReturnFirst
        CheckPending -->|"empty"| CheckExit
        CheckExit -->|"/exit"| FinishAction["AgentFinishAction()"]
        CheckExit -->|"continue"| CondenseHistory
        
        CallCondenser --> ViewResult
        CallCondenser --> CondensationResult
        ViewResult --> ProcessMessages
        CondensationResult --> ReturnCondensation["Return CondensationAction"]
        
        ProcessMessages --> LLMCall
        LLMCall --> ProcessResponse
    end
```

## AgentController - Детальная архитектура

```mermaid
classDiagram
    class AgentController {
        +id: str
        +user_id: str | None
        +file_store: FileStore | None
        +agent: Agent
        +headless_mode: bool
        +is_delegate: bool
        +conversation_stats: ConversationStats
        +event_stream: EventStream
        +state_tracker: StateTracker
        +state: State
        +agent_to_llm_config: dict[str, LLMConfig]
        +agent_configs: dict[str, AgentConfig]
        +_initial_max_iterations: int
        +_initial_max_budget_per_task: float | None
        +_stuck_detector: StuckDetector
        +status_callback: Callable | None
        +_replay_manager: ReplayManager
        +confirmation_mode: bool
        +security_analyzer: SecurityAnalyzer | None
        +delegate: AgentController | None
        +parent: AgentController | None
        +_pending_action_info: tuple[Action, float] | None
        +_closed: bool
        
        +__init__(agent, event_stream, conversation_stats, ...)
        +step()
        +close(set_stop_state: bool)
        +log(level, message, extra, exc_info)
        +on_event(event: Event)
        +set_agent_state_to(state: AgentState)
        +get_state() State
        +get_trajectory(save_screenshots: bool) list
        -_step_with_exception_handling()
        -_step()
        -_handle_security_analyzer(action: Action)
        -_add_system_message()
        -_react_to_exception(e: Exception)
        -set_initial_state(state, conversation_stats, ...)
    }
    
    class State {
        +history: list[Event]
        +iteration: int
        +agent_state: AgentState
        +last_error: str | None
        +start_id: int
        +end_id: int
        +truncation_id: int
        +confirmation_state: ConfirmationState
        +metrics: Metrics
        +delegates: dict
        +extra_data: dict
        
        +get_last_user_message() MessageAction | None
        +get_last_agent_message() MessageAction | None
        +get_last_action() Action | None
        +get_last_observation() Observation | None
        +save_to_session(sid, file_store, user_id)
        +restore_from_session(sid, file_store, user_id) State
        +to_llm_metadata(model_name, agent_name) dict
    }
    
    class StateTracker {
        +sid: str
        +file_store: FileStore | None
        +user_id: str | None
        +state: State
        
        +close(event_stream: EventStream)
    }
    
    class StuckDetector {
        +state: State
        -_last_actions: list[Action]
        
        +is_stuck() bool
        -_detect_action_loop() bool
        -_detect_repetitive_actions() bool
    }
    
    class ReplayManager {
        +replay_events: list[Event] | None
        
        +get_replay_events(trajectory: list) list[Event]
        +has_replay_events() bool
        +get_next_replay_event() Event | None
    }
    
    AgentController --> State
    AgentController --> StateTracker
    AgentController --> StuckDetector
    AgentController --> ReplayManager
    AgentController --> Agent
```

## Жизненный цикл агента

```mermaid
stateDiagram-v2
    [*] --> LOADING: Инициализация контроллера
    
    LOADING --> INIT: Runtime подключен
    note right of LOADING
        - Создание EventStream
        - Создание Runtime
        - Инициализация Agent
    end note
    
    INIT --> RUNNING: MessageAction от пользователя
    note right of INIT
        - Runtime готов
        - Agent инициализирован
        - Ожидание задачи
    end note
    
    RUNNING --> AWAITING_USER_INPUT: Agent запросил ввод
    AWAITING_USER_INPUT --> RUNNING: Пользователь ответил
    
    RUNNING --> PAUSED: Пользователь нажал паузу
    PAUSED --> RUNNING: Пользователь продолжил
    
    RUNNING --> RATE_LIMITED: LLM rate limit
    RATE_LIMITED --> RUNNING: После retry
    RATE_LIMITED --> ERROR: Все retry исчерпаны
    
    RUNNING --> FINISHED: AgentFinishAction
    note right of FINISHED
        - Задача выполнена
        - Результат сохранён
    end note
    
    RUNNING --> REJECTED: AgentRejectAction
    note right of REJECTED
        - Задача отклонена
        - Причина указана
    end note
    
    RUNNING --> ERROR: Исключение
    note right of ERROR
        - LLM ошибка
        - Runtime ошибка
        - Превышен бюджет
    end note
    
    RUNNING --> STOPPED: Пользователь остановил
    note right of STOPPED
        - Принудительная остановка
        - Состояние сохранено
    end note
    
    FINISHED --> [*]
    REJECTED --> [*]
    ERROR --> [*]
    STOPPED --> [*]
```

## Детальный цикл выполнения (Agent Loop)

```mermaid
sequenceDiagram
    participant Server as Server/ConversationManager
    participant Controller as AgentController
    participant StateTracker as StateTracker
    participant State as State
    participant StuckDetector as StuckDetector
    participant Agent as CodeActAgent
    participant Memory as ConversationMemory
    participant Condenser as Condenser
    participant LLM as LLM
    participant EventStream as EventStream
    participant Runtime as Runtime
    participant SecurityAnalyzer as SecurityAnalyzer

    Server->>Controller: Создание AgentController
    Controller->>StateTracker: Инициализация
    StateTracker->>State: Создание/восстановление State
    Controller->>EventStream: subscribe(AGENT_CONTROLLER)
    Controller->>Controller: _add_system_message()
    
    Note over Controller: Ожидание события
    
    EventStream->>Controller: on_event(MessageAction from user)
    Controller->>Controller: set_agent_state_to(RUNNING)
    
    loop Agent Loop (while not end_state)
        Controller->>StuckDetector: is_stuck()
        
        alt Stuck detected
            StuckDetector-->>Controller: true
            Controller->>EventStream: add_event(LoopDetectionObservation)
            Controller->>Agent: step(state) with recovery
        else Not stuck
            StuckDetector-->>Controller: false
            Controller->>Agent: step(state)
        end
        
        Agent->>Condenser: condensed_history(state)
        
        alt View returned
            Condenser-->>Agent: View(events, forgotten_ids)
            Agent->>Memory: process_events(events, initial_msg, forgotten_ids)
            Memory->>Memory: _ensure_system_message()
            Memory->>Memory: _ensure_initial_user_message()
            
            loop For each event
                alt Action
                    Memory->>Memory: _process_action(action)
                else Observation
                    Memory->>Memory: _process_observation(obs)
                end
            end
            
            Memory->>Memory: _filter_unmatched_tool_calls()
            Memory-->>Agent: list[Message]
            
            Agent->>LLM: completion(messages, tools)
            LLM-->>Agent: ModelResponse
            
            Agent->>Agent: response_to_actions(response)
            Agent-->>Controller: Action
            
        else Condensation returned
            Condenser-->>Agent: Condensation(action)
            Agent-->>Controller: CondensationAction
        end
        
        Controller->>SecurityAnalyzer: _handle_security_analyzer(action)
        SecurityAnalyzer-->>Controller: security_risk
        
        alt Confirmation required
            Controller->>Controller: set_agent_state_to(AWAITING_USER_CONFIRMATION)
            Note over Controller: Wait for user confirmation
        end
        
        Controller->>EventStream: add_event(action, AGENT)
        EventStream->>Runtime: on_event(action)
        
        Runtime->>Runtime: run_action(action)
        Runtime->>EventStream: add_event(observation, AGENT)
        
        EventStream->>Controller: on_event(observation)
        Controller->>State: Update history
        
        alt AgentFinishAction
            Controller->>Controller: set_agent_state_to(FINISHED)
        else AgentRejectAction
            Controller->>Controller: set_agent_state_to(REJECTED)
        else Error
            Controller->>Controller: set_agent_state_to(ERROR)
        else Continue
            Note over Controller: Next iteration
        end
    end
    
    Controller->>StateTracker: close(event_stream)
    Controller->>EventStream: unsubscribe()
```

## Конфигурация агента

```mermaid
classDiagram
    class AgentConfig {
        +name: str = "CodeActAgent"
        +llm_config: str = "llm"
        +enable_cmd: bool = true
        +enable_browsing: bool = true
        +enable_jupyter: bool = true
        +enable_editor: bool = true
        +enable_llm_editor: bool = false
        +enable_think: bool = true
        +enable_finish: bool = true
        +enable_mcp: bool = false
        +enable_plan_mode: bool = false
        +enable_condensation_request: bool = false
        +enable_som_visual_browsing: bool = false
        +condenser: CondenserConfig
        +runtime: str = "docker"
        +resolved_system_prompt_filename: str
        +micro_agent_name: str | None
    }
    
    class CondenserConfig {
        +type: str = "noop"
        +max_events: int = 100
        +keep_first_n: int = 5
        +llm_config: str | None
        +max_size: int = 50000
    }
    
    class LLMConfig {
        +model: str
        +api_key: SecretStr
        +base_url: str | None
        +temperature: float = 0.0
        +max_output_tokens: int = 4096
        +num_retries: int = 5
        +timeout: int = 120
        +max_message_chars: int | None
        +caching_prompt: bool = false
        +drop_params: bool = true
    }
    
    class SandboxConfig {
        +runtime: str = "docker"
        +base_container_image: str
        +timeout: int = 120
        +enable_auto_lint: bool = true
        +use_host_network: bool = false
        +selected_repo: str | None
        +selected_branch: str | None
    }
    
    AgentConfig --> CondenserConfig
    AgentConfig ..> LLMConfig : references
    AgentConfig ..> SandboxConfig : references
```

## Инструменты CodeActAgent

### Детальное описание инструментов

```mermaid
flowchart TB
    subgraph Tools["CodeActAgent Tools"]
        subgraph CmdRun["cmd_run Tool"]
            CmdRunDesc["Execute bash commands in sandbox"]
            CmdRunParams["Parameters:<br/>- command: str<br/>- thought: str (optional)"]
            CmdRunReturn["Returns: CmdOutputObservation<br/>- content: stdout/stderr<br/>- exit_code: int"]
        end
        
        subgraph IPython["ipython Tool"]
            IPythonDesc["Execute Python code in IPython kernel"]
            IPythonParams["Parameters:<br/>- code: str"]
            IPythonReturn["Returns: IPythonRunCellObservation<br/>- content: output<br/>- images: list (base64)"]
        end
        
        subgraph StrReplace["str_replace_editor Tool"]
            StrReplaceDesc["File operations using ACI"]
            StrReplaceCommands["Commands:<br/>- view: View file/directory<br/>- create: Create new file<br/>- str_replace: Replace text<br/>- insert: Insert at line<br/>- undo_edit: Undo last edit"]
            StrReplaceParams["Parameters:<br/>- command: str<br/>- path: str<br/>- old_str/new_str: str<br/>- file_text: str<br/>- insert_line: int"]
        end
        
        subgraph Browser["browser Tool"]
            BrowserDesc["Web browsing with Playwright"]
            BrowserActions["Actions:<br/>- goto(url)<br/>- click(element_id)<br/>- fill(element_id, value)<br/>- scroll(x, y)<br/>- go_back/go_forward<br/>- press(key)"]
            BrowserReturn["Returns: BrowserOutputObservation<br/>- content: page content<br/>- screenshot: base64<br/>- url: current URL"]
        end
        
        subgraph Think["think Tool"]
            ThinkDesc["Log agent's reasoning process"]
            ThinkParams["Parameters:<br/>- thought: str"]
            ThinkReturn["Returns: AgentThinkObservation"]
        end
        
        subgraph Finish["finish Tool"]
            FinishDesc["Complete the task"]
            FinishParams["Parameters:<br/>- outputs: dict (optional)"]
            FinishReturn["Returns: AgentFinishAction"]
        end
        
        subgraph TaskTracker["task_tracker Tool"]
            TaskTrackerDesc["Manage task list"]
            TaskTrackerCommands["Commands:<br/>- view: Show tasks<br/>- plan: Update task list"]
            TaskTrackerParams["Parameters:<br/>- command: str<br/>- task_list: list[Task]"]
        end
    end
```

### Таблица инструментов

| Инструмент | Описание | Параметры | Возвращает |
|------------|----------|-----------|------------|
| `cmd_run` | Выполнение bash команд | `command`, `thought` | `CmdOutputObservation` |
| `ipython` | Выполнение Python кода | `code` | `IPythonRunCellObservation` |
| `str_replace_editor` | Редактирование файлов | `command`, `path`, `old_str`, `new_str`, etc. | `FileEditObservation` / `FileReadObservation` |
| `browser` | Веб-браузинг | `action`, `url`, `element_id`, etc. | `BrowserOutputObservation` |
| `think` | Логирование мыслей | `thought` | `AgentThinkObservation` |
| `finish` | Завершение задачи | `outputs` | `AgentFinishAction` |
| `task_tracker` | Управление задачами | `command`, `task_list` | `TaskTrackingObservation` |
| `condensation_request` | Запрос сжатия памяти | - | `CondensationRequestAction` |

### Пример function call

```json
{
  "name": "str_replace_editor",
  "arguments": {
    "command": "str_replace",
    "path": "/workspace/app.py",
    "old_str": "def hello():\n    print('Hello')",
    "new_str": "def hello():\n    print('Hello, World!')"
  }
}
```

```json
{
  "name": "cmd_run",
  "arguments": {
    "command": "git status && git diff",
    "thought": "Проверяю изменения в репозитории перед коммитом"
  }
}
```

```json
{
  "name": "browser",
  "arguments": {
    "action": "goto",
    "url": "https://example.com"
  }
}
```
