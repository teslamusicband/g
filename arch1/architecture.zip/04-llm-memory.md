# LLM & Memory Layer

## Обзор

LLM Layer отвечает за взаимодействие с языковыми моделями, а Memory Layer управляет историей разговора и её сжатием.

## Детальная архитектура LLM Layer

```mermaid
flowchart TB
    subgraph LLMLayer["🧠 LLM LAYER"]
        direction TB
        
        subgraph LLMCore["LLM Core (/openhands/llm)"]
            subgraph LLMClass["LLM Class (llm.py)"]
                LLMAttributes["Attributes:<br/>- config: LLMConfig<br/>- service_id: str<br/>- metrics: Metrics<br/>- model_info: ModelInfo<br/>- tokenizer<br/>- _completion: partial<br/>- _function_calling_active: bool<br/>- cost_metric_supported: bool"]
                
                subgraph LLMMethods["Core Methods"]
                    Completion["completion(messages, tools, **kwargs) → ModelResponse"]
                    InitModelInfo["init_model_info()"]
                    VisionIsActive["vision_is_active() → bool"]
                    IsFunctionCalling["is_function_calling_active() → bool"]
                    IsCachingPrompt["is_caching_prompt_active() → bool"]
                    FormatMessages["format_messages_for_llm(messages) → list[dict]"]
                end
                
                subgraph LLMInternal["Internal"]
                    CompletionWrapper["wrapper() - Retry decorator"]
                    LogPrompt["log_prompt(messages)"]
                    LogResponse["log_response(response)"]
                    UpdateMetrics["_update_metrics()"]
                end
            end
            
            subgraph LLMVariants["LLM Variants"]
                AsyncLLMClass["AsyncLLM<br/>- async completion()"]
                StreamingLLMClass["StreamingLLM<br/>- streaming completion()"]
            end
            
            subgraph LLMRegistry["LLMRegistry (llm_registry.py)"]
                RegistryClass["LLMRegistry"]
                RegisterLLM["register(service_id, llm)"]
                GetLLM["get(service_id) → LLM"]
                GetRouter["get_router(config) → LLM"]
                CreateLLM["create_llm(config) → LLM"]
            end
        end
        
        subgraph LLMMixins["LLM Mixins"]
            subgraph RetryMixinClass["RetryMixin (retry_mixin.py)"]
                RetryDecorator["retry_decorator()"]
                RetryExceptions["LLM_RETRY_EXCEPTIONS:<br/>- APIConnectionError<br/>- RateLimitError<br/>- ServiceUnavailableError<br/>- BadGatewayError<br/>- Timeout<br/>- InternalServerError"]
                RetryConfig["Config:<br/>- num_retries<br/>- retry_min_wait<br/>- retry_max_wait<br/>- retry_multiplier"]
            end
            
            subgraph DebugMixinClass["DebugMixin (debug_mixin.py)"]
                LogPromptMethod["log_prompt(messages)"]
                LogResponseMethod["log_response(response)"]
                LogCompletions["log_completions (to file)"]
            end
        end
        
        subgraph LLMUtils["LLM Utilities"]
            subgraph FnCallConverter["Function Call Converter (fn_call_converter.py)"]
                ConvertToNonFnCall["convert_fncall_messages_to_non_fncall_messages()"]
                ConvertToFnCall["convert_non_fncall_messages_to_fncall_messages()"]
                StopWords["STOP_WORDS for mock FC"]
                ToolCallFormat["Tool call format conversion"]
            end
            
            subgraph ModelFeaturesModule["Model Features (model_features.py)"]
                GetFeatures["get_features(model) → ModelFeatures"]
                
                subgraph Features["Feature Detection"]
                    SupportsFunctionCalling["supports_function_calling"]
                    SupportsVision["supports_vision"]
                    SupportsPromptCaching["supports_prompt_caching"]
                    SupportsReasoningEffort["supports_reasoning_effort"]
                    SupportsStopWords["supports_stop_words"]
                end
            end
            
            subgraph MetricsModule["Metrics (metrics.py)"]
                MetricsClass["Metrics"]
                AccumulatedCost["accumulated_cost: float"]
                TotalTokens["total_tokens: int"]
                PromptTokens["prompt_tokens: int"]
                CompletionTokens["completion_tokens: int"]
                ResponseLatencies["response_latencies: list"]
                AddCost["add_cost()"]
                AddLatency["add_response_latency()"]
            end
            
            subgraph LLMUtilsModule["LLM Utils (llm_utils.py)"]
                CheckTools["check_tools(tools, config)"]
                GetMaxTokens["get_max_tokens()"]
            end
            
            subgraph ToolNamesModule["Tool Names (tool_names.py)"]
                ToolNameConstants["Tool name constants"]
            end
        end
        
        subgraph LLMRouter["LLM Router (/llm/router)"]
            RouterClass["Router"]
            RoutingConfig["RoutingConfig"]
            ModelSelection["Model selection logic"]
            LoadBalancing["Load balancing"]
        end
        
        subgraph BedrockModule["Bedrock Support (bedrock.py)"]
            BedrockConfig["AWS Bedrock configuration"]
            BedrockAuth["AWS authentication"]
        end
    end
    
    subgraph LiteLLMIntegration["LiteLLM Integration"]
        LiteLLMCompletion["litellm.completion()"]
        LiteLLMMessage["litellm.Message"]
        LiteLLMModelInfo["litellm.ModelInfo"]
        LiteLLMCost["litellm.completion_cost()"]
        
        subgraph Providers["Supported Providers"]
            OpenAIProvider["OpenAI<br/>- gpt-4, gpt-4o<br/>- o1, o3, o4"]
            AnthropicProvider["Anthropic<br/>- claude-3.5-sonnet<br/>- claude-4-sonnet<br/>- claude-4-opus"]
            GoogleProvider["Google<br/>- gemini-2.0-flash<br/>- gemini-2.5-pro"]
            AzureProvider["Azure OpenAI<br/>- azure/gpt-4"]
            BedrockProvider["AWS Bedrock<br/>- bedrock/claude"]
            OllamaProvider["Ollama<br/>- ollama/llama3"]
            LiteLLMProxyProvider["LiteLLM Proxy<br/>- litellm_proxy/*"]
            OpenHandsProvider["OpenHands<br/>- openhands/*"]
        end
    end
    
    LLMClass --> LLMMixins
    LLMClass --> LLMUtils
    LLMClass --> LiteLLMIntegration
    LLMCore --> LLMRouter
    LLMCore --> BedrockModule
```

## Детальная архитектура Memory Layer

```mermaid
flowchart TB
    subgraph MemoryLayer["🧠 MEMORY LAYER"]
        direction TB
        
        subgraph MemoryCore["Memory Core (/openhands/memory)"]
            subgraph ConversationMemoryClass["ConversationMemory (conversation_memory.py)"]
                CMAttributes["Attributes:<br/>- agent_config: AgentConfig<br/>- prompt_manager: PromptManager"]
                
                subgraph CMMethods["Core Methods"]
                    ProcessEvents["process_events(history, initial_action, forgotten_ids, max_chars, vision) → list[Message]"]
                    ApplyPromptCaching["apply_prompt_caching(messages)"]
                end
                
                subgraph CMInternal["Internal Methods"]
                    EnsureSystemMessage["_ensure_system_message(events)"]
                    EnsureInitialUserMessage["_ensure_initial_user_message(events, initial_action, forgotten_ids)"]
                    ProcessAction["_process_action(action, pending_tool_calls, vision) → list[Message]"]
                    ProcessObservation["_process_observation(obs, tool_call_map, max_chars, vision, som) → list[Message]"]
                    FilterUnmatchedToolCalls["_filter_unmatched_tool_calls(messages)"]
                    ApplyUserMessageFormatting["_apply_user_message_formatting(messages)"]
                    IsValidImageUrl["_is_valid_image_url(url)"]
                end
            end
            
            subgraph MemoryClass["Memory (memory.py)"]
                MemoryAttributes["Attributes:<br/>- event_stream: EventStream<br/>- microagents: list[BaseMicroagent]"]
                
                subgraph MemoryMethods["Methods"]
                    GetMicroagentKnowledge["get_microagent_knowledge()"]
                    GetRepoInstructions["get_repo_instructions()"]
                end
            end
            
            subgraph ViewClass["View (view.py)"]
                ViewAttributes["Attributes:<br/>- events: list[Event]<br/>- forgotten_event_ids: set[int]"]
            end
        end
        
        subgraph CondenserModule["Condenser Module (/memory/condenser)"]
            subgraph CondenserBase["Condenser Base"]
                CondenserClass["Condenser (Abstract)"]
                CondensedHistory["condensed_history(state) → View | Condensation"]
                FromConfig["from_config(config, llm_registry) → Condenser"]
            end
            
            subgraph CondenserTypes["Condenser Implementations"]
                subgraph NoOpCondenserClass["NoOpCondenser"]
                    NoOpDesc["Returns all events unchanged"]
                    NoOpUseCase["Use: Short sessions"]
                end
                
                subgraph RecentEventsCondenserClass["RecentEventsCondenser"]
                    RECConfig["Config:<br/>- max_events: int<br/>- keep_first_n: int"]
                    RECDesc["Keeps first N + last (max - N) events"]
                    RECUseCase["Use: Simple truncation"]
                end
                
                subgraph LLMCondenserClass["LLMCondenser"]
                    LLMCConfig["Config:<br/>- llm_config: str"]
                    LLMCDesc["Uses LLM to summarize history"]
                    LLMCUseCase["Use: Intelligent summarization"]
                end
                
                subgraph AmortizedCondenserClass["AmortizedCondenser"]
                    ACConfig["Config:<br/>- max_size: int"]
                    ACDesc["Gradual condensation over time"]
                    ACUseCase["Use: Very long sessions"]
                end
            end
            
            subgraph CondensationResult["Condensation Results"]
                ViewResult["View<br/>- events: list[Event]<br/>- forgotten_event_ids: set[int]"]
                CondensationResult2["Condensation<br/>- action: CondensationAction"]
            end
        end
        
        subgraph MessageModule["Message Module (/core/message.py)"]
            subgraph MessageClass["Message Class"]
                MessageRole["role: 'user' | 'assistant' | 'system' | 'tool'"]
                MessageContent["content: list[Content]"]
                MessageToolCalls["tool_calls: list[ToolCall] | None"]
            end
            
            subgraph ContentTypes["Content Types"]
                TextContent["TextContent<br/>- type: 'text'<br/>- text: str"]
                ImageContent["ImageContent<br/>- type: 'image_url'<br/>- image_urls: list[str]"]
            end
            
            subgraph ToolCallClass["ToolCall"]
                ToolCallId["id: str"]
                ToolCallType["type: str"]
                ToolCallFunction["function: FunctionCall"]
            end
        end
        
        subgraph PromptModule["Prompt Module (/utils/prompt.py)"]
            subgraph PromptManagerClass["PromptManager"]
                PMAttributes["Attributes:<br/>- prompt_dir: str<br/>- system_prompt_filename: str"]
                
                subgraph PMMethods["Methods"]
                    GetSystemMessage["get_system_message() → str"]
                    GetUserMessage["get_user_message() → str"]
                    RenderTemplate["render_template(template, **kwargs)"]
                end
            end
            
            subgraph PromptTemplates["Prompt Templates"]
                SystemPrompt["system_prompt.j2"]
                UserPrompt["user_prompt.j2"]
                ToolDescriptions["Tool descriptions"]
            end
            
            subgraph PromptContext["Prompt Context"]
                RepositoryInfo["RepositoryInfo"]
                RuntimeInfo["RuntimeInfo"]
                ConversationInstructions["ConversationInstructions"]
            end
        end
    end
    
    ConversationMemoryClass --> CondenserModule
    ConversationMemoryClass --> MessageModule
    ConversationMemoryClass --> PromptModule
    CondenserBase --> CondenserTypes
    CondenserTypes --> CondensationResult
```

## LLM Class

```mermaid
classDiagram
    class LLM {
        +config: LLMConfig
        +metrics: Metrics
        +model_info: ModelInfo
        +completion(messages, tools) ModelResponse
        +vision_is_active() bool
        +is_function_calling_active() bool
        +is_caching_prompt_active() bool
        +format_messages_for_llm(messages) list
    }
    
    class RetryMixin {
        +retry_decorator()
        +retry_listener: Callable
    }
    
    class DebugMixin {
        +log_prompt(messages)
        +log_response(response)
    }
    
    class LLMConfig {
        +model: str
        +api_key: SecretStr
        +base_url: str
        +temperature: float
        +max_output_tokens: int
        +num_retries: int
        +timeout: int
        +custom_llm_provider: str
    }
    
    class Metrics {
        +model_name: str
        +accumulated_cost: float
        +total_tokens: int
        +add_response_latency()
        +add_cost()
    }
    
    LLM --|> RetryMixin
    LLM --|> DebugMixin
    LLM --> LLMConfig
    LLM --> Metrics
```

## Поддерживаемые провайдеры

| Provider | Модели | Особенности |
|----------|--------|-------------|
| **OpenAI** | GPT-4, GPT-4o, o1, o3 | Function calling, Vision |
| **Anthropic** | Claude 3.5, Claude 4 | Prompt caching, Vision |
| **Google** | Gemini 2.0, 2.5 | Thinking, Vision |
| **Azure** | Azure OpenAI models | Enterprise |
| **AWS Bedrock** | Claude, Titan | AWS integration |
| **Ollama** | Llama, Mistral, etc. | Local deployment |
| **LiteLLM Proxy** | Any supported | Unified API |

## Function Calling

```mermaid
flowchart TB
    subgraph FunctionCalling["Function Calling Flow"]
        Messages["Messages"]
        Tools["Tools Definition"]
        
        subgraph LLMCall["LLM Call"]
            Completion["completion()"]
            Response["ModelResponse"]
        end
        
        subgraph Conversion["Conversion (if needed)"]
            ToNonFnCall["convert_fncall_to_non_fncall"]
            FromNonFnCall["convert_non_fncall_to_fncall"]
        end
        
        ToolCalls["Tool Calls"]
        Actions["Actions"]
    end
    
    Messages --> Completion
    Tools --> Completion
    Completion --> Response
    
    Response -->|Native FC| ToolCalls
    Response -->|Mock FC| FromNonFnCall
    FromNonFnCall --> ToolCalls
    
    ToolCalls --> Actions
```

## Memory Layer Architecture

```mermaid
flowchart TB
    subgraph MemoryLayer["Memory Layer"]
        ConvMemory["ConversationMemory<br/>/openhands/memory/conversation_memory.py"]
        
        subgraph Condenser["Condenser"]
            CondenserBase["Condenser Base"]
            NoOpCondenser["NoOpCondenser"]
            RecentEventsCondenser["RecentEventsCondenser"]
            LLMCondenser["LLMCondenser"]
            AmortizedCondenser["AmortizedCondenser"]
        end
        
        subgraph View["View"]
            Events["Filtered Events"]
            ForgottenIds["Forgotten Event IDs"]
        end
    end
    
    ConvMemory --> Condenser
    Condenser --> View
```

## ConversationMemory

```mermaid
classDiagram
    class ConversationMemory {
        +agent_config: AgentConfig
        +prompt_manager: PromptManager
        +process_events(history, initial_action) list~Message~
        +apply_prompt_caching(messages)
        -_process_action(action) list~Message~
        -_process_observation(obs) list~Message~
        -_ensure_system_message(events)
        -_ensure_initial_user_message(events)
    }
    
    class Message {
        +role: str
        +content: list~Content~
        +tool_calls: list~ToolCall~
    }
    
    class TextContent {
        +type: str = "text"
        +text: str
    }
    
    class ImageContent {
        +type: str = "image_url"
        +image_urls: list~str~
    }
    
    ConversationMemory --> Message
    Message --> TextContent
    Message --> ImageContent
```

## Condenser Types

```mermaid
classDiagram
    class Condenser {
        <<abstract>>
        +condensed_history(state) View | Condensation
    }
    
    class NoOpCondenser {
        +condensed_history(state) View
    }
    
    class RecentEventsCondenser {
        +max_events: int
        +keep_first_n: int
        +condensed_history(state) View
    }
    
    class LLMCondenser {
        +llm: LLM
        +condensed_history(state) View | Condensation
    }
    
    class AmortizedCondenser {
        +max_size: int
        +condensed_history(state) View | Condensation
    }
    
    Condenser <|-- NoOpCondenser
    Condenser <|-- RecentEventsCondenser
    Condenser <|-- LLMCondenser
    Condenser <|-- AmortizedCondenser
```

### Описание Condenser'ов

| Condenser | Описание | Когда использовать |
|-----------|----------|-------------------|
| **NoOpCondenser** | Без сжатия | Короткие сессии |
| **RecentEventsCondenser** | Оставляет N последних событий | Простые задачи |
| **LLMCondenser** | Использует LLM для суммаризации | Длинные сессии |
| **AmortizedCondenser** | Постепенное сжатие | Очень длинные сессии |

## Процесс обработки истории

```mermaid
sequenceDiagram
    participant Agent as CodeActAgent
    participant Memory as ConversationMemory
    participant Condenser as Condenser
    participant LLM as LLM

    Agent->>Condenser: condensed_history(state)
    
    alt View (события готовы)
        Condenser-->>Agent: View(events, forgotten_ids)
        Agent->>Memory: process_events(events)
        Memory->>Memory: _ensure_system_message()
        Memory->>Memory: _ensure_initial_user_message()
        
        loop Для каждого события
            Memory->>Memory: _process_action() или _process_observation()
        end
        
        Memory-->>Agent: list[Message]
    else Condensation (нужно сжатие)
        Condenser-->>Agent: Condensation(action)
        Agent-->>Controller: CondensationAction
    end
    
    Agent->>LLM: completion(messages, tools)
```

## Prompt Caching (Anthropic)

```mermaid
flowchart TB
    subgraph PromptCaching["Prompt Caching"]
        Messages["Messages"]
        
        subgraph CachePoints["Cache Points"]
            SystemMsg["System Message<br/>cache_control: ephemeral"]
            FirstUser["First User Message<br/>cache_control: ephemeral"]
            LastAssistant["Last Assistant<br/>cache_control: ephemeral"]
        end
        
        CachedPrompt["Cached Prompt"]
    end
    
    Messages --> CachePoints
    CachePoints --> CachedPrompt
```

## LLM Configuration

```mermaid
classDiagram
    class LLMConfig {
        +model: str
        +api_key: SecretStr
        +base_url: str
        +api_version: str
        +temperature: float
        +top_p: float
        +top_k: int
        +max_output_tokens: int
        +max_message_chars: int
        +num_retries: int
        +retry_min_wait: int
        +retry_max_wait: int
        +timeout: int
        +custom_llm_provider: str
        +reasoning_effort: str
        +drop_params: bool
        +modify_params: bool
        +caching_prompt: bool
        +log_completions: bool
    }
```

## Пример конфигурации LLM

```toml
[llm]
model = "anthropic/claude-sonnet-4-20250514"
api_key = "sk-..."
temperature = 0.0
max_output_tokens = 4096
num_retries = 5
timeout = 120
caching_prompt = true

[llm.condenser]
type = "recent_events"
max_events = 100
keep_first_n = 5
```

## Model Features

```mermaid
flowchart TB
    subgraph ModelFeatures["Model Features Detection"]
        Model["Model Name"]
        
        subgraph Features["Features"]
            FunctionCalling["Function Calling"]
            Vision["Vision"]
            PromptCaching["Prompt Caching"]
            Reasoning["Reasoning Effort"]
            StopWords["Stop Words"]
        end
        
        FeatureSet["Feature Set"]
    end
    
    Model --> Features
    Features --> FeatureSet
```

| Feature | Модели |
|---------|--------|
| Function Calling | GPT-4, Claude 3+, Gemini |
| Vision | GPT-4o, Claude 3+, Gemini |
| Prompt Caching | Claude 3+ |
| Reasoning | o1, o3, Gemini 2.5 |
