# Запуск OpenHands с локальной Ollama

## Обзор

Это руководство описывает как запустить OpenHands с локальной моделью Ollama (например, `qwen3-coder:480b-a35b-q4_K_M`), работающей в Docker контейнере на хост-машине.

---

## ⚠️ ВАЖНО: Расположение конфигурационных файлов

### Где должен находиться config.toml

```mermaid
flowchart TB
    subgraph ConfigLocations["📁 Расположение config.toml"]
        direction TB
        
        subgraph Priority["Приоритет загрузки (от высшего к низшему)"]
            CLI["1. CLI параметр --config-file<br/>python -m openhands.core.main --config-file /path/to/config.toml"]
            CWD["2. Текущая рабочая директория<br/>./config.toml"]
            UserHome["3. Домашняя директория пользователя<br/>~/.openhands/config.toml"]
        end
        
        subgraph DockerPaths["Пути в Docker контейнере"]
            DockerCWD["Рабочая директория: /app<br/>→ /app/config.toml"]
            DockerMount["Монтируемая директория:<br/>~/.openhands → /.openhands<br/>→ /.openhands/config.toml"]
        end
    end
```

### Все конфигурационные файлы и директории

| Файл/Директория | Расположение | Описание | Обязательный |
|-----------------|--------------|----------|--------------|
| `config.toml` | `./config.toml` или `~/.openhands/config.toml` | Основная конфигурация | Нет (есть defaults) |
| `settings.json` | `{file_store_path}/settings.json` | Настройки из веб-интерфейса | Нет (создаётся автоматически) |
| `.openhands/` | `~/.openhands/` | Директория данных пользователя | Да (создаётся автоматически) |
| `workspace/` | `./workspace` или `{workspace_base}` | Рабочая директория агента | Да |
| `microagents/` | `~/.openhands/microagents/` | Пользовательские микроагенты | Нет |
| `skills/` | `~/.openhands/skills/` | Пользовательские навыки | Нет |

### Структура директории ~/.openhands

```
~/.openhands/
├── config.toml          # Пользовательская конфигурация (опционально)
├── settings.json        # Настройки из веб-интерфейса (создаётся автоматически)
├── sessions/            # Сохранённые сессии
│   └── {session_id}/
│       ├── events/      # История событий
│       └── state.json   # Состояние сессии
├── microagents/         # Пользовательские микроагенты
│   └── *.md
└── skills/              # Пользовательские навыки
    └── *.md
```

### Переменные окружения для путей

| Переменная | Значение по умолчанию | Описание |
|------------|----------------------|----------|
| `FILE_STORE` | `local` | Тип хранилища (local, s3, gcs, memory) |
| `FILE_STORE_PATH` | `/.openhands` (Docker) | Путь к хранилищу данных |
| `WORKSPACE_BASE` | `/opt/workspace_base` (Docker) | Базовая директория workspace |
| `WORKSPACE_MOUNT_PATH` | - | Путь монтирования workspace |

---

## Архитектура подключения

```mermaid
flowchart TB
    subgraph HostMachine["🖥️ Host Machine"]
        subgraph OllamaContainer["Ollama Docker Container"]
            OllamaServer["Ollama Server<br/>:11434"]
            QwenModel["qwen3-coder:480b-a35b-q4_K_M"]
        end
        
        subgraph OpenHandsContainer["OpenHands Docker Container"]
            OpenHandsServer["OpenHands Server<br/>:3000"]
            LLMModule["LLM Module<br/>(LiteLLM)"]
        end
        
        subgraph RuntimeContainer["Runtime Container"]
            ActionServer["Action Execution Server"]
        end
        
        DockerSocket["/var/run/docker.sock"]
    end
    
    User["👤 User<br/>Browser :3000"]
    
    User --> OpenHandsServer
    OpenHandsServer --> LLMModule
    LLMModule -->|"HTTP API<br/>host.docker.internal:11434"| OllamaServer
    OllamaServer --> QwenModel
    OpenHandsServer --> DockerSocket
    DockerSocket --> RuntimeContainer
```

## Предварительные требования

### 1. Ollama запущена и доступна

```bash
# Проверка что Ollama работает
curl http://localhost:11434/api/tags

# Проверка что модель загружена
ollama list
# Должна быть: qwen3-coder:480b-a35b-q4_K_M
```

### 2. Ollama слушает на 0.0.0.0

Ollama должна быть доступна не только на localhost, но и на `0.0.0.0:11434`, чтобы контейнеры могли к ней обращаться.

**Если Ollama запущена через Docker:**
```bash
docker run -d \
  --name ollama \
  -p 11434:11434 \
  -v ollama:/root/.ollama \
  ollama/ollama
```

**Если Ollama запущена нативно:**
```bash
# Установите переменную окружения перед запуском
OLLAMA_HOST=0.0.0.0:11434 ollama serve
```

## Способ 1: Docker Run (Рекомендуется)

### Шаг 1: Создайте директории и конфигурацию

```bash
# Создайте директории
mkdir -p ~/.openhands
mkdir -p ~/openhands-workspace

# Создайте config.toml для Ollama
cat > ~/.openhands/config.toml << 'EOF'
[core]
workspace_base = "/opt/workspace_base"
file_store = "local"
file_store_path = "/.openhands"

[llm]
model = "ollama/qwen3-coder:480b-a35b-q4_K_M"
base_url = "http://host.docker.internal:11434"
api_key = "ollama"
temperature = 0.0
timeout = 600
num_retries = 3
caching_prompt = false
drop_params = true

[agent]
name = "CodeActAgent"
enable_browsing = true
enable_jupyter = true
enable_cmd = true
enable_editor = true

[sandbox]
runtime = "docker"
timeout = 300

[condenser]
type = "noop"
EOF
```

### Шаг 2: Запустите OpenHands

```bash
docker run -it --rm \
  --name openhands-app \
  -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik \
  -e LOG_ALL_EVENTS=true \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v ~/.openhands:/.openhands \
  -v ~/openhands-workspace:/opt/workspace_base \
  -p 3000:3000 \
  --add-host host.docker.internal:host-gateway \
  docker.all-hands.dev/all-hands-ai/openhands:0.30
```

> **Важно**: 
> - `--add-host host.docker.internal:host-gateway` позволяет контейнеру обращаться к хост-машине по адресу `host.docker.internal`
> - `-v ~/.openhands:/.openhands` монтирует директорию с config.toml и settings.json
> - Конфигурация из `~/.openhands/config.toml` будет автоматически загружена

### Шаг 3: Проверьте логи

```bash
# В отдельном терминале
docker logs -f openhands-app
```

Вы должны увидеть:
```
Starting OpenHands...
INFO: config.toml not found: ... Toml values have not been applied.
```

Если config.toml найден:
```
INFO: Loaded configuration from /.openhands/config.toml
```

### Шаг 4 (Альтернатива): Настройте LLM в веб-интерфейсе

Если вы не создали config.toml, настройте через UI:

1. Откройте http://localhost:3000
2. Нажмите на иконку настроек (⚙️)
3. В разделе **LLM Provider** выберите **Ollama**
4. В поле **Model** введите: `ollama/qwen3-coder:480b-a35b-q4_K_M`
5. В поле **Base URL** введите: `http://host.docker.internal:11434`
6. Поле **API Key** оставьте пустым или введите `ollama`
7. Сохраните настройки

> **Примечание**: Настройки из веб-интерфейса сохраняются в `~/.openhands/settings.json` и имеют приоритет над config.toml для LLM настроек в веб-режиме.

## Способ 2: Development Mode (из исходников)

### Шаг 1: Клонируйте репозиторий

```bash
git clone https://github.com/All-Hands-AI/OpenHands.git
cd OpenHands
```

### Шаг 2: Создайте config.toml

```bash
cat > config.toml << 'EOF'
[core]
workspace_base = "./workspace"
file_store = "local"
file_store_path = "./.openhands"
max_iterations = 100

[llm]
# Формат модели: ollama/<имя_модели>
model = "ollama/qwen3-coder:480b-a35b-q4_K_M"

# URL Ollama сервера
# Для Docker: http://host.docker.internal:11434
# Для локального запуска: http://localhost:11434
base_url = "http://localhost:11434"

# API ключ не требуется для Ollama, но LiteLLM требует непустое значение
api_key = "ollama"

# Настройки для локальных моделей
temperature = 0.0
num_retries = 3
retry_min_wait = 5
retry_max_wait = 30
timeout = 600

# Отключаем prompt caching (не поддерживается Ollama)
caching_prompt = false

# Отключаем drop_params для совместимости
drop_params = true

[agent]
name = "CodeActAgent"
enable_browsing = true
enable_jupyter = true
enable_cmd = true
enable_editor = true
enable_think = true
enable_finish = true

[sandbox]
runtime = "docker"
base_container_image = "nikolaik/python-nodejs:python3.12-nodejs22"
timeout = 300
use_host_network = false

[condenser]
# Для больших моделей можно использовать noop
type = "noop"
EOF
```

### Шаг 3: Установите зависимости и запустите

```bash
# Установка зависимостей
make build

# Запуск
make run
```

### Шаг 4: Откройте приложение

- Frontend: http://localhost:3001
- Backend API: http://localhost:3000

## Способ 3: CLI Mode

### Шаг 1: Установите пакет

```bash
pip install openhands-ai
# или из исходников
cd OpenHands && poetry install
```

### Шаг 2: Создайте config.toml (как в Способе 2)

### Шаг 3: Запустите с задачей

```bash
python -m openhands.core.main \
  -c config.toml \
  -t "Создай простой Python скрипт hello.py который выводит 'Hello, World!'"
```

## Конфигурация LLM для Ollama

### Полная конфигурация config.toml

```toml
[llm]
# Формат: ollama/<model_name>
# Имя модели должно точно соответствовать выводу `ollama list`
model = "ollama/qwen3-coder:480b-a35b-q4_K_M"

# Base URL для Ollama API
# Варианты:
# - http://localhost:11434 (локальный запуск)
# - http://host.docker.internal:11434 (из Docker контейнера)
# - http://192.168.1.100:11434 (по IP хоста)
base_url = "http://localhost:11434"

# API ключ (Ollama не требует, но LiteLLM ожидает непустое значение)
api_key = "ollama"

# Температура генерации (0.0 = детерминированный вывод)
temperature = 0.0

# Максимальное количество токенов в ответе
# Для qwen3-coder рекомендуется 4096-8192
max_output_tokens = 4096

# Таймаут запроса в секундах
# Для больших моделей увеличьте до 300-600
timeout = 300

# Количество повторных попыток при ошибке
num_retries = 3
retry_min_wait = 5
retry_max_wait = 60

# Отключаем функции, не поддерживаемые Ollama
caching_prompt = false

# Разрешаем отбрасывать неподдерживаемые параметры
drop_params = true

# Отключаем vision (если модель не поддерживает)
disable_vision = true
```

### Переменные окружения (альтернатива config.toml)

```bash
export LLM_MODEL="ollama/qwen3-coder:480b-a35b-q4_K_M"
export LLM_BASE_URL="http://localhost:11434"
export LLM_API_KEY="ollama"
```

## Как это работает

### Поток запроса к Ollama

```mermaid
sequenceDiagram
    participant Agent as CodeActAgent
    participant LLM as LLM Module
    participant LiteLLM as LiteLLM
    participant Ollama as Ollama Server
    participant Model as qwen3-coder

    Agent->>LLM: completion(messages, tools)
    LLM->>LLM: Проверка model.startswith('ollama')
    LLM->>LiteLLM: litellm.completion(model="ollama/qwen3-coder:...")
    
    Note over LiteLLM: LiteLLM определяет провайдера<br/>по префиксу "ollama/"
    
    LiteLLM->>Ollama: POST http://localhost:11434/api/chat
    Note over Ollama: JSON body:<br/>{model: "qwen3-coder:...",<br/>messages: [...]}
    
    Ollama->>Model: Inference
    Model-->>Ollama: Generated tokens
    Ollama-->>LiteLLM: Response
    LiteLLM-->>LLM: ModelResponse
    LLM-->>Agent: Action
```

### Формат модели в LiteLLM

LiteLLM использует префикс `ollama/` для определения провайдера:

| Формат в config | Что происходит |
|-----------------|----------------|
| `ollama/qwen3-coder:480b-a35b-q4_K_M` | LiteLLM отправляет запрос к Ollama API |
| `qwen3-coder:480b-a35b-q4_K_M` | ❌ Ошибка - LiteLLM не знает провайдера |
| `ollama_chat/qwen3-coder:480b-a35b-q4_K_M` | Альтернативный формат (chat endpoint) |

## Сетевые настройки

### Доступ из Docker контейнера к хосту

```mermaid
flowchart LR
    subgraph DockerNetwork["Docker Network"]
        OpenHands["OpenHands Container"]
    end
    
    subgraph HostNetwork["Host Network"]
        Ollama["Ollama :11434"]
    end
    
    OpenHands -->|"host.docker.internal:11434"| Ollama
```

**Варианты адресов:**

| Сценарий | Base URL |
|----------|----------|
| OpenHands в Docker, Ollama на хосте | `http://host.docker.internal:11434` |
| OpenHands локально, Ollama локально | `http://localhost:11434` |
| OpenHands в Docker, Ollama в Docker (та же сеть) | `http://ollama:11434` |
| OpenHands в Docker, Ollama на другой машине | `http://192.168.x.x:11434` |

### Использование host network (альтернатива)

```bash
docker run -it --rm \
  --name openhands-app \
  --network host \
  -e SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik \
  -v /var/run/docker.sock:/var/run/docker.sock \
  -v ~/.openhands:/.openhands \
  -v ~/openhands-workspace:/opt/workspace_base \
  docker.all-hands.dev/all-hands-ai/openhands:0.30
```

При `--network host` используйте `base_url = "http://localhost:11434"`.

## Типичные ошибки и решения

### Ошибки в логах OpenHands Server (порт 3000)

#### Ошибка: config.toml not found

```
INFO: config.toml not found: [Errno 2] No such file or directory: 'config.toml'. Toml values have not been applied.
```

**Это НЕ ошибка!** Это информационное сообщение. OpenHands работает с настройками по умолчанию или из веб-интерфейса.

**Если хотите использовать config.toml:**
```bash
# Для Docker - создайте файл в ~/.openhands/
cat > ~/.openhands/config.toml << 'EOF'
[llm]
model = "ollama/qwen3-coder:480b-a35b-q4_K_M"
base_url = "http://host.docker.internal:11434"
api_key = "ollama"
EOF

# Убедитесь что директория монтируется
docker run ... -v ~/.openhands:/.openhands ...
```

#### Ошибка: Connection refused

```
Error: Connection refused to http://localhost:11434
```

**Причина**: OpenHands в Docker не может достучаться до localhost хоста.

**Решение**: Используйте `http://host.docker.internal:11434` вместо `http://localhost:11434`.

#### Ошибка: Model not found

```
Error: model 'qwen3-coder:480b-a35b-q4_K_M' not found
```

**Причина**: Модель не загружена в Ollama.

**Решение**:
```bash
ollama pull qwen3-coder:480b-a35b-q4_K_M
# или
ollama run qwen3-coder:480b-a35b-q4_K_M
```

#### Ошибка: Timeout

```
Error: Request timed out after 120 seconds
```

**Причина**: Большая модель требует больше времени на генерацию.

**Решение**: Увеличьте timeout в config.toml:
```toml
[llm]
timeout = 600  # 10 минут
```

#### Ошибка: Invalid API key

```
Error: Invalid API key
```

**Причина**: LiteLLM требует непустой API key.

**Решение**: Установите `api_key = "ollama"` (любое непустое значение).

#### Ошибка: Function calling not supported

```
Warning: Model does not support function calling, using mock implementation
```

**Это нормально!** OpenHands автоматически использует "mock function calling" через промпты для моделей без нативной поддержки function calling.

### Ошибки в логах Runtime Container

#### Ошибка: Cannot connect to Docker daemon

```
Error: Cannot connect to the Docker daemon at unix:///var/run/docker.sock
```

**Причина**: Docker socket не смонтирован или нет прав доступа.

**Решение**:
```bash
# Убедитесь что монтируете docker.sock
docker run ... -v /var/run/docker.sock:/var/run/docker.sock ...

# Проверьте права на хосте
ls -la /var/run/docker.sock
# Должно быть: srw-rw---- 1 root docker ...

# Если нужно, добавьте права
sudo chmod 666 /var/run/docker.sock
```

#### Ошибка: Runtime container failed to start

```
Error: Failed to start runtime container
```

**Причина**: Проблема с образом runtime или сетью.

**Решение**:
```bash
# Загрузите образ заранее
docker pull docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik

# Или используйте стандартный образ
docker pull nikolaik/python-nodejs:python3.12-nodejs22
```

#### Ошибка: host.docker.internal not resolved

```
Error: Could not resolve host: host.docker.internal
```

**Причина**: Отсутствует `--add-host` при запуске.

**Решение**:
```bash
docker run ... --add-host host.docker.internal:host-gateway ...
```

### Проверка что всё работает

```bash
# 1. Проверка Ollama
curl http://localhost:11434/api/tags
# Должен вернуть список моделей

# 2. Проверка OpenHands server
curl http://localhost:3000/health
# Должен вернуть {"status": "ok"}

# 3. Проверка доступа из контейнера к Ollama
docker exec openhands-app curl http://host.docker.internal:11434/api/tags
# Должен вернуть список моделей

# 4. Проверка runtime контейнера
docker ps | grep runtime
# Должен показать запущенный runtime контейнер после начала задачи
```

## Оптимизация для больших моделей

### Настройки для qwen3-coder:480b

```toml
[llm]
model = "ollama/qwen3-coder:480b-a35b-q4_K_M"
base_url = "http://host.docker.internal:11434"
api_key = "ollama"

# Увеличенные таймауты для большой модели
timeout = 600
num_retries = 2
retry_min_wait = 10
retry_max_wait = 120

# Ограничение токенов для экономии памяти
max_output_tokens = 4096
max_message_chars = 20000

# Температура
temperature = 0.0

# Отключаем неподдерживаемые функции
caching_prompt = false
disable_vision = true

[condenser]
# Используем простой condenser для экономии контекста
type = "recent"
max_events = 50
keep_first = 3

[core]
# Ограничиваем итерации
max_iterations = 50
```

### Настройки Ollama для производительности

```bash
# Увеличьте контекст если нужно
OLLAMA_NUM_CTX=8192 ollama serve

# Или через Docker
docker run -d \
  --name ollama \
  -p 11434:11434 \
  -e OLLAMA_NUM_CTX=8192 \
  -v ollama:/root/.ollama \
  ollama/ollama
```

## Проверка работоспособности

### 1. Проверка Ollama

```bash
# Проверка API
curl http://localhost:11434/api/tags

# Тестовый запрос
curl http://localhost:11434/api/generate -d '{
  "model": "qwen3-coder:480b-a35b-q4_K_M",
  "prompt": "Hello",
  "stream": false
}'
```

### 2. Проверка OpenHands

```bash
# Health check
curl http://localhost:3000/health

# Проверка доступных моделей (если настроено)
curl http://localhost:3000/api/options/models
```

### 3. Тестовая задача

В веб-интерфейсе введите простую задачу:
```
Создай файл test.py с функцией hello() которая возвращает строку "Hello, World!"
```

## Полный пример docker-compose.yml

```yaml
version: '3.8'

services:
  ollama:
    image: ollama/ollama
    container_name: ollama
    ports:
      - "11434:11434"
    volumes:
      - ollama_data:/root/.ollama
    environment:
      - OLLAMA_NUM_CTX=8192
    restart: unless-stopped

  openhands:
    image: docker.all-hands.dev/all-hands-ai/openhands:0.30
    container_name: openhands
    ports:
      - "3000:3000"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - ~/.openhands:/.openhands
      - ./workspace:/opt/workspace_base
    environment:
      - SANDBOX_RUNTIME_CONTAINER_IMAGE=docker.all-hands.dev/all-hands-ai/runtime:0.30-nikolaik
      - LOG_ALL_EVENTS=true
    extra_hosts:
      - "host.docker.internal:host-gateway"
    depends_on:
      - ollama
    restart: unless-stopped

volumes:
  ollama_data:
```

Запуск:
```bash
docker-compose up -d

# Загрузка модели
docker exec -it ollama ollama pull qwen3-coder:480b-a35b-q4_K_M

# Открыть http://localhost:3000
```

## Резюме

| Параметр | Значение для Ollama |
|----------|---------------------|
| Model | `ollama/qwen3-coder:480b-a35b-q4_K_M` |
| Base URL (Docker) | `http://host.docker.internal:11434` |
| Base URL (Local) | `http://localhost:11434` |
| API Key | `ollama` (любое непустое) |
| Timeout | `300-600` секунд |
| Function Calling | Mock (через промпты) |
