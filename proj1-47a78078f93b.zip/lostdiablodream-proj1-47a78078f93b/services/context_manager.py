#!/usr/bin/env python3
"""
Context Manager Service for AI Agent System
Manages context storage, retrieval, and iteration tracking
"""

import os
import json
import hashlib
import asyncio
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import asyncpg
import redis.asyncio as redis
import uvicorn

# Configuration
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://n8n:n8n123@localhost:5432/context_db")
REDIS_URL = os.getenv("REDIS_URL", "redis://:redis123@localhost:6379/0")

# Data models
@dataclass
class Context:
    session_id: str
    prompt_hash: str
    context_data: Dict[str, Any]
    iteration_count: int = 1
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class ContextRequest(BaseModel):
    session_id: str
    prompt: str
    context_data: Dict[str, Any]

class ContextResponse(BaseModel):
    session_id: str
    prompt_hash: str
    context_data: Dict[str, Any]
    iteration_count: int
    created_at: str
    updated_at: str

class ArchitectureRefinement(BaseModel):
    session_id: str
    iteration: int
    original_prompt: str
    refined_architecture: Dict[str, Any]
    feedback: Optional[Dict[str, Any]] = None

# FastAPI app
app = FastAPI(title="AI Agent Context Manager", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database connection pool
db_pool = None
redis_client = None

async def get_db():
    return db_pool

async def get_redis():
    return redis_client

@app.on_event("startup")
async def startup():
    global db_pool, redis_client
    
    # Initialize database connection pool
    db_pool = await asyncpg.create_pool(DATABASE_URL)
    
    # Initialize Redis connection
    redis_client = redis.from_url(REDIS_URL)
    
    print("Context Manager Service started successfully")

@app.on_event("shutdown")
async def shutdown():
    global db_pool, redis_client
    
    if db_pool:
        await db_pool.close()
    
    if redis_client:
        await redis_client.close()

def generate_prompt_hash(prompt: str) -> str:
    """Generate hash for prompt to enable deduplication"""
    return hashlib.sha256(prompt.encode()).hexdigest()

@app.post("/context", response_model=ContextResponse)
async def store_context(
    request: ContextRequest,
    db: asyncpg.Pool = Depends(get_db),
    redis_conn: redis.Redis = Depends(get_redis)
):
    """Store or update context for a session"""
    try:
        prompt_hash = generate_prompt_hash(request.prompt)
        
        # Check if context already exists
        async with db.acquire() as conn:
            existing = await conn.fetchrow(
                "SELECT * FROM contexts WHERE session_id = $1 AND prompt_hash = $2",
                request.session_id, prompt_hash
            )
            
            if existing:
                # Update existing context
                await conn.execute(
                    """UPDATE contexts 
                       SET context_data = $1, iteration_count = iteration_count + 1, updated_at = CURRENT_TIMESTAMP
                       WHERE session_id = $2 AND prompt_hash = $3""",
                    json.dumps(request.context_data), request.session_id, prompt_hash
                )
                iteration_count = existing['iteration_count'] + 1
            else:
                # Create new context
                await conn.execute(
                    """INSERT INTO contexts (session_id, prompt_hash, context_data, iteration_count)
                       VALUES ($1, $2, $3, 1)""",
                    request.session_id, prompt_hash, json.dumps(request.context_data)
                )
                iteration_count = 1
            
            # Get updated record
            record = await conn.fetchrow(
                "SELECT * FROM contexts WHERE session_id = $1 AND prompt_hash = $2",
                request.session_id, prompt_hash
            )
        
        # Cache in Redis for fast access
        cache_key = f"context:{request.session_id}:{prompt_hash}"
        await redis_conn.setex(
            cache_key, 3600,  # 1 hour TTL
            json.dumps({
                "context_data": request.context_data,
                "iteration_count": iteration_count,
                "updated_at": record['updated_at'].isoformat()
            })
        )
        
        return ContextResponse(
            session_id=record['session_id'],
            prompt_hash=record['prompt_hash'],
            context_data=json.loads(record['context_data']),
            iteration_count=record['iteration_count'],
            created_at=record['created_at'].isoformat(),
            updated_at=record['updated_at'].isoformat()
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to store context: {str(e)}")

@app.get("/context/{session_id}", response_model=List[ContextResponse])
async def get_contexts(
    session_id: str,
    db: asyncpg.Pool = Depends(get_db)
):
    """Get all contexts for a session"""
    try:
        async with db.acquire() as conn:
            records = await conn.fetch(
                "SELECT * FROM contexts WHERE session_id = $1 ORDER BY updated_at DESC",
                session_id
            )
        
        return [
            ContextResponse(
                session_id=record['session_id'],
                prompt_hash=record['prompt_hash'],
                context_data=json.loads(record['context_data']),
                iteration_count=record['iteration_count'],
                created_at=record['created_at'].isoformat(),
                updated_at=record['updated_at'].isoformat()
            )
            for record in records
        ]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get contexts: {str(e)}")

@app.post("/architecture-refinement")
async def store_architecture_refinement(
    refinement: ArchitectureRefinement,
    db: asyncpg.Pool = Depends(get_db)
):
    """Store architecture refinement iteration"""
    try:
        async with db.acquire() as conn:
            await conn.execute(
                """INSERT INTO architecture_history 
                   (session_id, iteration, original_prompt, refined_architecture, feedback)
                   VALUES ($1, $2, $3, $4, $5)""",
                refinement.session_id,
                refinement.iteration,
                refinement.original_prompt,
                json.dumps(refinement.refined_architecture),
                json.dumps(refinement.feedback) if refinement.feedback else None
            )
        
        return {"status": "success", "message": "Architecture refinement stored"}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to store refinement: {str(e)}")

@app.get("/architecture-refinement/{session_id}")
async def get_architecture_history(
    session_id: str,
    db: asyncpg.Pool = Depends(get_db)
):
    """Get architecture refinement history for a session"""
    try:
        async with db.acquire() as conn:
            records = await conn.fetch(
                "SELECT * FROM architecture_history WHERE session_id = $1 ORDER BY iteration",
                session_id
            )
        
        return [
            {
                "session_id": record['session_id'],
                "iteration": record['iteration'],
                "original_prompt": record['original_prompt'],
                "refined_architecture": json.loads(record['refined_architecture']),
                "feedback": json.loads(record['feedback']) if record['feedback'] else None,
                "created_at": record['created_at'].isoformat()
            }
            for record in records
        ]
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get architecture history: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "context-manager"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)