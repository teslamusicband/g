#!/usr/bin/env python3
"""
DevOps Orchestrator Service for AI Agent System
Manages Docker containers, deployments, and infrastructure operations
"""

import os
import json
import asyncio
import subprocess
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import docker
import uvicorn

# Configuration
ARTIFACTS_PATH = os.getenv("ARTIFACTS_PATH", "/app/artifacts")
DOCKER_HOST = os.getenv("DOCKER_HOST", "unix:///var/run/docker.sock")

# Data models
class DeploymentRequest(BaseModel):
    session_id: str
    product_name: str
    product_type: str
    source_code: Dict[str, str]  # filename -> content
    dockerfile_content: Optional[str] = None
    docker_compose_content: Optional[str] = None
    environment_vars: Optional[Dict[str, str]] = None

class DeploymentResponse(BaseModel):
    session_id: str
    product_name: str
    deployment_id: str
    status: str
    container_id: Optional[str] = None
    port_mappings: Optional[Dict[str, int]] = None
    logs: Optional[List[str]] = None

class ContainerInfo(BaseModel):
    container_id: str
    name: str
    status: str
    ports: Dict[str, int]
    created_at: str

# FastAPI app
app = FastAPI(title="AI Agent DevOps Orchestrator", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Docker client
docker_client = None
deployments = {}  # In-memory storage for deployment tracking

@app.on_event("startup")
async def startup():
    global docker_client
    
    try:
        docker_client = docker.from_env()
        # Test connection
        docker_client.ping()
        print("DevOps Orchestrator Service started successfully")
        print(f"Docker client connected to: {docker_client.api.base_url}")
    except Exception as e:
        print(f"Failed to connect to Docker: {e}")
        docker_client = None

@app.on_event("shutdown")
async def shutdown():
    global docker_client
    
    if docker_client:
        docker_client.close()

def create_dockerfile(product_type: str, custom_content: Optional[str] = None) -> str:
    """Generate Dockerfile based on product type"""
    if custom_content:
        return custom_content
    
    dockerfiles = {
        "web_app": """
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
""",
        "api": """
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
""",
        "microservice": """
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["python", "main.py"]
""",
        "static_site": """
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
"""
    }
    
    return dockerfiles.get(product_type, dockerfiles["web_app"])

def create_docker_compose(product_name: str, product_type: str, custom_content: Optional[str] = None) -> str:
    """Generate docker-compose.yml based on product type"""
    if custom_content:
        return custom_content
    
    port_mapping = {
        "web_app": "3000:3000",
        "api": "8000:8000",
        "microservice": "8000:8000",
        "static_site": "80:80"
    }
    
    port = port_mapping.get(product_type, "3000:3000")
    
    return f"""
version: '3.8'
services:
  {product_name}:
    build: .
    ports:
      - "{port}"
    restart: unless-stopped
    environment:
      - NODE_ENV=production
"""

async def run_command(command: List[str], cwd: str) -> tuple[int, str, str]:
    """Run shell command asynchronously"""
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=cwd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        return process.returncode, stdout.decode(), stderr.decode()
    except Exception as e:
        return 1, "", str(e)

@app.post("/deploy", response_model=DeploymentResponse)
async def deploy_product(
    request: DeploymentRequest,
    background_tasks: BackgroundTasks
):
    """Deploy a product using Docker"""
    try:
        if not docker_client:
            raise HTTPException(status_code=500, detail="Docker client not available")
        
        deployment_id = f"{request.session_id}_{request.product_name}_{int(datetime.now().timestamp())}"
        
        # Create artifacts directory
        product_dir = Path(ARTIFACTS_PATH) / request.session_id / request.product_name
        product_dir.mkdir(parents=True, exist_ok=True)
        
        # Write source code files
        for filename, content in request.source_code.items():
            file_path = product_dir / filename
            file_path.write_text(content)
        
        # Create Dockerfile
        dockerfile_content = create_dockerfile(request.product_type, request.dockerfile_content)
        (product_dir / "Dockerfile").write_text(dockerfile_content)
        
        # Create docker-compose.yml
        compose_content = create_docker_compose(
            request.product_name, 
            request.product_type, 
            request.docker_compose_content
        )
        (product_dir / "docker-compose.yml").write_text(compose_content)
        
        # Store deployment info
        deployments[deployment_id] = {
            "session_id": request.session_id,
            "product_name": request.product_name,
            "product_type": request.product_type,
            "status": "building",
            "created_at": datetime.now().isoformat(),
            "product_dir": str(product_dir)
        }
        
        # Start deployment in background
        background_tasks.add_task(build_and_deploy, deployment_id, str(product_dir))
        
        return DeploymentResponse(
            session_id=request.session_id,
            product_name=request.product_name,
            deployment_id=deployment_id,
            status="building"
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Deployment failed: {str(e)}")

async def build_and_deploy(deployment_id: str, product_dir: str):
    """Build and deploy product in background"""
    try:
        # Update status
        deployments[deployment_id]["status"] = "building"
        
        # Build Docker image
        image_name = f"ai-agent-{deployment_id.lower()}"
        
        # Build using docker-compose
        returncode, stdout, stderr = await run_command(
            ["docker-compose", "build"],
            product_dir
        )
        
        if returncode != 0:
            deployments[deployment_id]["status"] = "build_failed"
            deployments[deployment_id]["error"] = stderr
            return
        
        # Deploy using docker-compose
        deployments[deployment_id]["status"] = "deploying"
        
        returncode, stdout, stderr = await run_command(
            ["docker-compose", "up", "-d"],
            product_dir
        )
        
        if returncode != 0:
            deployments[deployment_id]["status"] = "deploy_failed"
            deployments[deployment_id]["error"] = stderr
            return
        
        # Get container info
        try:
            containers = docker_client.containers.list(
                filters={"label": f"com.docker.compose.project={Path(product_dir).name}"}
            )
            
            if containers:
                container = containers[0]
                deployments[deployment_id]["container_id"] = container.id
                deployments[deployment_id]["status"] = "running"
                
                # Extract port mappings
                port_mappings = {}
                for port, bindings in container.ports.items():
                    if bindings:
                        port_mappings[port] = int(bindings[0]['HostPort'])
                
                deployments[deployment_id]["port_mappings"] = port_mappings
            else:
                deployments[deployment_id]["status"] = "deployed_no_container"
                
        except Exception as e:
            deployments[deployment_id]["status"] = "running"  # Assume it's running
            deployments[deployment_id]["container_error"] = str(e)
        
    except Exception as e:
        deployments[deployment_id]["status"] = "failed"
        deployments[deployment_id]["error"] = str(e)

@app.get("/deployment/{deployment_id}", response_model=DeploymentResponse)
async def get_deployment_status(deployment_id: str):
    """Get deployment status"""
    if deployment_id not in deployments:
        raise HTTPException(status_code=404, detail="Deployment not found")
    
    deployment = deployments[deployment_id]
    
    return DeploymentResponse(
        session_id=deployment["session_id"],
        product_name=deployment["product_name"],
        deployment_id=deployment_id,
        status=deployment["status"],
        container_id=deployment.get("container_id"),
        port_mappings=deployment.get("port_mappings")
    )

@app.get("/deployments/{session_id}")
async def get_session_deployments(session_id: str):
    """Get all deployments for a session"""
    session_deployments = {
        k: v for k, v in deployments.items() 
        if v["session_id"] == session_id
    }
    
    return session_deployments

@app.delete("/deployment/{deployment_id}")
async def stop_deployment(deployment_id: str):
    """Stop and remove deployment"""
    if deployment_id not in deployments:
        raise HTTPException(status_code=404, detail="Deployment not found")
    
    try:
        deployment = deployments[deployment_id]
        product_dir = deployment["product_dir"]
        
        # Stop containers using docker-compose
        returncode, stdout, stderr = await run_command(
            ["docker-compose", "down"],
            product_dir
        )
        
        if returncode == 0:
            deployments[deployment_id]["status"] = "stopped"
            return {"status": "success", "message": "Deployment stopped"}
        else:
            return {"status": "error", "message": stderr}
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to stop deployment: {str(e)}")

@app.get("/containers")
async def list_containers():
    """List all running containers"""
    try:
        if not docker_client:
            raise HTTPException(status_code=500, detail="Docker client not available")
        
        containers = docker_client.containers.list()
        
        container_info = []
        for container in containers:
            port_mappings = {}
            for port, bindings in container.ports.items():
                if bindings:
                    port_mappings[port] = int(bindings[0]['HostPort'])
            
            container_info.append(ContainerInfo(
                container_id=container.id[:12],
                name=container.name,
                status=container.status,
                ports=port_mappings,
                created_at=container.attrs['Created']
            ))
        
        return container_info
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list containers: {str(e)}")

@app.post("/execute-command")
async def execute_command(
    command: str,
    working_directory: Optional[str] = None
):
    """Execute shell command (use with caution)"""
    try:
        cwd = working_directory or ARTIFACTS_PATH
        
        # Basic security check - only allow safe commands
        safe_commands = ['ls', 'pwd', 'cat', 'grep', 'find', 'docker', 'git']
        command_parts = command.split()
        
        if not command_parts or command_parts[0] not in safe_commands:
            raise HTTPException(status_code=400, detail="Command not allowed")
        
        returncode, stdout, stderr = await run_command(command_parts, cwd)
        
        return {
            "command": command,
            "returncode": returncode,
            "stdout": stdout,
            "stderr": stderr
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Command execution failed: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    docker_status = "connected" if docker_client else "disconnected"
    return {
        "status": "healthy", 
        "service": "devops-orchestrator",
        "docker_status": docker_status
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)