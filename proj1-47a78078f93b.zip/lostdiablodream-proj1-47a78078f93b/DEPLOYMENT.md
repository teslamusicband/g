# AI Agent System Deployment Guide

## Обзор

Данная система AI-агента создает полностью работающие продукты на основе промптов пользователя. Система состоит из нескольких микросервисов, оркестрируемых через n8n workflow engine.

## Предварительные требования

### Системные требования
- Linux/macOS/Windows с Docker
- Минимум 8GB RAM
- 20GB свободного места на диске
- Docker Engine 20.10+
- Docker Compose v2.0+

### Установка зависимостей

```bash
# Установка Docker (Ubuntu/Debian)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Установка Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Проверка установки
docker --version
docker-compose --version
```

## Быстрый старт

### 1. Клонирование репозитория

```bash
git clone <repository-url>
cd proj1
```

### 2. Инициализация DevOps утилит (опционально)

```bash
chmod +x scripts/init-devops-tools.sh
sudo ./scripts/init-devops-tools.sh
```

### 3. Запуск системы

```bash
chmod +x scripts/start-ai-agent.sh
./scripts/start-ai-agent.sh
```

### 4. Проверка работоспособности

```bash
chmod +x scripts/test-ai-agent.sh
./scripts/test-ai-agent.sh
```

## Архитектура развертывания

### Компоненты системы

1. **n8n Workflow Engine** (порт 12000)
   - Основной оркестратор системы
   - Веб-интерфейс для управления workflow
   - Обработка входящих промптов

2. **PostgreSQL Database** (внутренний)
   - Хранение данных n8n
   - Контекст и история архитектурных решений
   - Метаданные продуктов

3. **Redis Cache** (внутренний)
   - Кэширование контекста
   - Сессионные данные
   - Быстрый доступ к часто используемым данным

4. **Ollama LLM Server** (порт 11434)
   - Локальные модели Llama
   - API для генерации кода и архитектуры
   - Обработка естественного языка

5. **Context Manager Service** (порт 12001)
   - Управление контекстом между итерациями
   - API для сохранения и извлечения контекста
   - История архитектурных решений

6. **DevOps Orchestrator Service** (порт 12002)
   - Управление Docker контейнерами
   - Развертывание созданных продуктов
   - Мониторинг состояния развертываний

### Сетевая архитектура

```
Internet
    |
    v
[Load Balancer] (опционально)
    |
    v
[n8n Web Interface] :12000
    |
    +-- [Context Manager] :12001
    |
    +-- [DevOps Orchestrator] :12002
    |
    +-- [Ollama LLM] :11434
    |
    +-- [PostgreSQL] (внутренний)
    |
    +-- [Redis] (внутренний)
```

## Конфигурация

### Переменные окружения

Основные переменные окружения можно настроить в `docker/docker-compose.yml`:

```yaml
# n8n Configuration
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=admin123
N8N_HOST=0.0.0.0
N8N_PORT=5678

# Database Configuration
DB_POSTGRESDB_HOST=postgres
DB_POSTGRESDB_DATABASE=n8n
DB_POSTGRESDB_USER=n8n
DB_POSTGRESDB_PASSWORD=n8n123

# Redis Configuration
REDIS_PASSWORD=redis123
```

### Настройка портов

По умолчанию система использует следующие порты:
- 12000: n8n Web Interface
- 12001: Context Manager API
- 12002: DevOps Orchestrator API (если включен)
- 11434: Ollama LLM API

Для изменения портов отредактируйте секцию `ports` в `docker-compose.yml`.

## Использование системы

### API Endpoints

#### Создание продукта
```bash
curl -X POST http://localhost:12000/webhook/ai-agent-create-product \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Create a simple web application with user authentication",
    "session_id": "my-session-123"
  }'
```

#### Проверка контекста
```bash
curl http://localhost:12001/context/my-session-123
```

#### Список развертываний
```bash
curl http://localhost:12002/deployments/my-session-123
```

### Веб-интерфейс n8n

1. Откройте http://localhost:12000
2. Войдите с учетными данными:
   - Username: `admin`
   - Password: `admin123`
3. Импортируйте workflow из `workflows/ai-agent-workflow.json`
4. Активируйте workflow

## Мониторинг и логирование

### Просмотр логов

```bash
# Все сервисы
docker-compose logs -f

# Конкретный сервис
docker-compose logs -f n8n
docker-compose logs -f postgres
docker-compose logs -f ollama
```

### Мониторинг ресурсов

```bash
# Статус контейнеров
docker-compose ps

# Использование ресурсов
docker stats

# Дисковое пространство
docker system df
```

### Health Checks

Система предоставляет health check endpoints:

```bash
# Context Manager
curl http://localhost:12001/health

# DevOps Orchestrator
curl http://localhost:12002/health

# Ollama
curl http://localhost:11434/api/tags
```

## Масштабирование

### Горизонтальное масштабирование

Для масштабирования отдельных компонентов:

```bash
# Масштабирование Context Manager
docker-compose up -d --scale context-manager=3

# Масштабирование DevOps Orchestrator
docker-compose up -d --scale devops-orchestrator=2
```

### Вертикальное масштабирование

Отредактируйте `docker-compose.yml` для увеличения ресурсов:

```yaml
services:
  ollama:
    deploy:
      resources:
        limits:
          memory: 8G
          cpus: '4'
```

## Безопасность

### Базовые настройки безопасности

1. **Изменение паролей по умолчанию**
   ```bash
   # Отредактируйте docker-compose.yml
   N8N_BASIC_AUTH_PASSWORD=your-secure-password
   DB_POSTGRESDB_PASSWORD=your-db-password
   ```

2. **Настройка HTTPS**
   ```yaml
   # Добавьте в n8n сервис
   environment:
     - N8N_PROTOCOL=https
     - N8N_SSL_KEY=/certs/key.pem
     - N8N_SSL_CERT=/certs/cert.pem
   ```

3. **Ограничение доступа к API**
   ```bash
   # Используйте firewall для ограничения доступа
   sudo ufw allow from 192.168.1.0/24 to any port 12000
   ```

## Резервное копирование

### Автоматическое резервное копирование

```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d_%H%M%S)
docker-compose exec postgres pg_dump -U n8n n8n > backup_n8n_$DATE.sql
docker-compose exec postgres pg_dump -U n8n context_db > backup_context_$DATE.sql
tar -czf backup_volumes_$DATE.tar.gz -C /var/lib/docker/volumes .
```

### Восстановление

```bash
# Восстановление базы данных
docker-compose exec -T postgres psql -U n8n n8n < backup_n8n_20240101_120000.sql

# Восстановление volumes
tar -xzf backup_volumes_20240101_120000.tar.gz -C /var/lib/docker/volumes
```

## Устранение неполадок

### Общие проблемы

1. **n8n не запускается**
   ```bash
   # Проверьте логи
   docker-compose logs n8n
   
   # Проверьте подключение к базе данных
   docker-compose exec postgres pg_isready -U n8n
   ```

2. **Ollama не отвечает**
   ```bash
   # Проверьте статус
   curl http://localhost:11434/api/tags
   
   # Перезапустите сервис
   docker-compose restart ollama
   ```

3. **Недостаточно памяти**
   ```bash
   # Увеличьте лимиты в docker-compose.yml
   deploy:
     resources:
       limits:
         memory: 4G
   ```

### Диагностические команды

```bash
# Проверка сети
docker network ls
docker network inspect proj1_ai-agent-network

# Проверка volumes
docker volume ls
docker volume inspect proj1_postgres_data

# Проверка образов
docker images
```

## Обновление системы

### Обновление компонентов

```bash
# Остановка системы
docker-compose down

# Обновление образов
docker-compose pull

# Запуск с новыми образами
docker-compose up -d
```

### Миграция данных

При обновлении системы убедитесь в совместимости схемы базы данных и выполните необходимые миграции.

## Поддержка

Для получения поддержки:
1. Проверьте логи системы
2. Убедитесь в соответствии системным требованиям
3. Проверьте сетевые настройки и доступность портов
4. Создайте issue в репозитории с подробным описанием проблемы