-- Create additional databases
CREATE DATABASE context_db;
CREATE DATABASE artifacts_db;

-- Connect to context_db and create tables
\c context_db;

-- Context storage table
CREATE TABLE IF NOT EXISTS contexts (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    prompt_hash VARCHAR(64) NOT NULL,
    context_data JSONB NOT NULL,
    iteration_count INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Architecture refinement history
CREATE TABLE IF NOT EXISTS architecture_history (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    iteration INTEGER NOT NULL,
    original_prompt TEXT NOT NULL,
    refined_architecture JSONB NOT NULL,
    feedback JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Product generation history
CREATE TABLE IF NOT EXISTS product_history (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    product_type VARCHAR(100) NOT NULL,
    generation_status VARCHAR(50) DEFAULT 'in_progress',
    artifacts_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_contexts_session_id ON contexts(session_id);
CREATE INDEX idx_contexts_prompt_hash ON contexts(prompt_hash);
CREATE INDEX idx_architecture_history_session_id ON architecture_history(session_id);
CREATE INDEX idx_product_history_session_id ON product_history(session_id);

-- Connect to artifacts_db and create tables
\c artifacts_db;

-- Artifacts storage table
CREATE TABLE IF NOT EXISTS artifacts (
    id SERIAL PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    artifact_name VARCHAR(255) NOT NULL,
    artifact_type VARCHAR(100) NOT NULL,
    file_path TEXT NOT NULL,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes
CREATE INDEX idx_artifacts_session_id ON artifacts(session_id);
CREATE INDEX idx_artifacts_type ON artifacts(artifact_type);