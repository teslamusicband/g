# AI Agent Product Creator System

🤖 **Автоматическая система создания продуктов на основе промптов с использованием локальных LLM моделей**

## Обзор

Данная система представляет собой комплексное решение для автоматического создания полностью работающих продуктов на основе текстовых промптов пользователя. Система использует локальные модели Llama для анализа требований, создания архитектуры, генерации кода и автоматического развертывания готовых продуктов.

### Ключевые возможности

- 🎯 **Создание продуктов по промпту**: Просто опишите что хотите получить
- 🧠 **Локальные LLM модели**: Использование Llama для полной автономности
- 🔄 **Итеративная переработка архитектуры**: Система улучшает архитектуру на основе анализа
- 🐳 **Автоматическое развертывание**: Docker-контейнеры создаются и запускаются автоматически
- 📊 **Управление контекстом**: Сохранение истории и контекста между итерациями
- 🛠️ **DevOps интеграция**: Полный цикл от кода до развертывания

## Архитектура системы

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   User Prompt   │───▶│   n8n Workflow   │───▶│  Llama LLM API  │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │                        │
                                ▼                        ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Context Manager │◀───│ Architecture     │───▶│ Code Generator  │
└─────────────────┘    │ Refinement Loop  │    └─────────────────┘
                       └──────────────────┘             │
                                                        ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Product Storage │◀───│ DevOps           │◀───│ Docker Deploy   │
└─────────────────┘    │ Orchestrator     │    └─────────────────┘
                       └──────────────────┘
```

## Быстрый старт

### 1. Предварительные требования

- Docker Engine 20.10+
- Docker Compose v2.0+
- 8GB+ RAM
- 20GB+ свободного места

### 2. Установка и запуск

```bash
# Клонирование репозитория
git clone <repository-url>
cd proj1

# Инициализация DevOps утилит (опционально)
chmod +x scripts/init-devops-tools.sh
sudo ./scripts/init-devops-tools.sh

# Запуск системы
chmod +x scripts/start-ai-agent.sh
./scripts/start-ai-agent.sh
```

### 3. Первое использование

После запуска системы откройте веб-интерфейс n8n:
- URL: http://localhost:12000
- Логин: `admin`
- Пароль: `admin123`

Или используйте API напрямую:

```bash
curl -X POST http://localhost:12000/webhook/ai-agent-create-product \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Create a simple web application with user registration and login",
    "session_id": "my-first-project"
  }'
```

## Компоненты системы

### 🔄 n8n Workflow Engine
- **Порт**: 12000
- **Назначение**: Основной оркестратор всех процессов
- **Функции**: Обработка промптов, управление потоком данных

### 🧠 Ollama LLM Server
- **Порт**: 11434
- **Назначение**: Локальные модели Llama для генерации кода и архитектуры
- **Модели**: Llama 3.1 (автоматически загружается)

### 🗃️ Context Manager
- **Порт**: 12001
- **Назначение**: Управление контекстом и историей проектов
- **База данных**: PostgreSQL + Redis

### 🛠️ DevOps Orchestrator
- **Порт**: 12002
- **Назначение**: Автоматическое развертывание созданных продуктов
- **Функции**: Docker контейнеры, мониторинг развертываний

## Примеры использования

### Создание веб-приложения

```json
{
  "prompt": "Create a modern web application for task management with user authentication, task creation, editing, and deletion. Use React for frontend and Node.js for backend.",
  "session_id": "task-manager-app"
}
```

### Создание API сервиса

```json
{
  "prompt": "Build a REST API for a blog platform with endpoints for posts, comments, and user management. Include authentication and data validation.",
  "session_id": "blog-api"
}
```

### Создание микросервиса

```json
{
  "prompt": "Create a microservice for user notifications that can send emails and push notifications. Include queue management and retry logic.",
  "session_id": "notification-service"
}
```

## Цикл работы системы

1. **Анализ промпта**: Система анализирует входной промпт и извлекает требования
2. **Создание архитектуры**: LLM генерирует архитектуру продукта
3. **Переработка архитектуры**: Итеративное улучшение архитектуры на основе сложности
4. **Генерация кода**: Создание исходного кода, Dockerfile, конфигураций
5. **Развертывание**: Автоматическое создание и запуск Docker контейнеров
6. **Мониторинг**: Отслеживание состояния развернутых продуктов

## API Endpoints

### Создание продукта
```
POST /webhook/ai-agent-create-product
Content-Type: application/json

{
  "prompt": "Your product description",
  "session_id": "unique-session-id"
}
```

### Управление контекстом
```
GET /context/{session_id}           # Получить контекст сессии
POST /context                       # Сохранить контекст
GET /architecture-refinement/{session_id}  # История архитектуры
```

### DevOps операции
```
GET /deployments/{session_id}       # Список развертываний
GET /deployment/{deployment_id}     # Статус развертывания
DELETE /deployment/{deployment_id}  # Остановить развертывание
GET /containers                     # Список контейнеров
```

## Мониторинг и логирование

### Просмотр логов
```bash
# Все сервисы
docker-compose logs -f

# Конкретный сервис
docker-compose logs -f n8n
docker-compose logs -f ollama
```

### Health Checks
```bash
curl http://localhost:12001/health  # Context Manager
curl http://localhost:12002/health  # DevOps Orchestrator
curl http://localhost:11434/api/tags # Ollama
```

## Тестирование

Запустите автоматические тесты:

```bash
chmod +x scripts/test-ai-agent.sh
./scripts/test-ai-agent.sh
```

Тесты включают:
- Проверку доступности всех сервисов
- Тестирование Context Manager API
- Тестирование DevOps Orchestrator
- Создание продуктов с различными промптами

## Структура проекта

```
proj1/
├── ARCHITECTURE.md          # Подробная архитектура системы
├── DEPLOYMENT.md           # Руководство по развертыванию
├── docker/                 # Docker конфигурации
│   ├── docker-compose.yml  # Основной compose файл
│   ├── Dockerfile.*        # Dockerfile для сервисов
│   └── init-db.sql        # Инициализация базы данных
├── services/               # Исходный код сервисов
│   ├── context_manager.py  # Context Manager сервис
│   └── devops_orchestrator.py # DevOps Orchestrator
├── workflows/              # n8n workflow файлы
│   └── ai-agent-workflow.json # Основной workflow
├── scripts/                # Утилиты и скрипты
│   ├── init-devops-tools.sh # Инициализация DevOps утилит
│   ├── start-ai-agent.sh   # Запуск системы
│   └── test-ai-agent.sh    # Тестирование системы
└── requirements.txt        # Python зависимости
```

## Конфигурация

### Основные настройки

Отредактируйте `docker/docker-compose.yml` для изменения:
- Портов сервисов
- Паролей и учетных данных
- Лимитов ресурсов
- Переменных окружения

### Настройка LLM моделей

```bash
# Подключение к Ollama контейнеру
docker-compose exec ollama bash

# Загрузка дополнительных моделей
ollama pull codellama
ollama pull mistral
```

## Безопасность

- Измените пароли по умолчанию в `docker-compose.yml`
- Используйте HTTPS для продакшн развертывания
- Ограничьте доступ к API endpoints через firewall
- Регулярно обновляйте Docker образы

## Устранение неполадок

### Общие проблемы

1. **Недостаточно памяти**: Увеличьте лимиты в docker-compose.yml
2. **Порты заняты**: Измените порты в конфигурации
3. **Ollama не отвечает**: Дождитесь загрузки модели (может занять несколько минут)

### Диагностика

```bash
# Статус контейнеров
docker-compose ps

# Использование ресурсов
docker stats

# Проверка сети
docker network inspect proj1_ai-agent-network
```

## Вклад в проект

1. Fork репозитория
2. Создайте feature branch
3. Внесите изменения
4. Добавьте тесты
5. Создайте Pull Request

## Лицензия

MIT License - см. файл LICENSE для подробностей.

## Поддержка

- 📖 Документация: См. файлы ARCHITECTURE.md и DEPLOYMENT.md
- 🐛 Баги: Создайте issue в репозитории
- 💡 Предложения: Обсуждения в разделе Discussions

---

**🚀 Создавайте продукты будущего с помощью AI уже сегодня!**