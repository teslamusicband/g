#!/bin/bash

# AI Agent System Test Script
# This script tests the AI Agent system with various prompts

set -e

echo "🧪 Testing AI Agent System..."

# Configuration
N8N_URL="http://localhost:12000"
WEBHOOK_URL="$N8N_URL/webhook/ai-agent-create-product"
CONTEXT_API="http://localhost:12001"
DEVOPS_API="http://localhost:12002"

# Test prompts
declare -a TEST_PROMPTS=(
    "Create a simple Hello World web application"
    "Build a REST API for a todo list application"
    "Create a static website with a contact form"
    "Build a microservice for user authentication"
    "Create a blog platform with admin panel"
)

# Function to test API endpoint
test_endpoint() {
    local url=$1
    local name=$2
    
    echo "🔍 Testing $name at $url..."
    
    if curl -s --max-time 10 "$url" > /dev/null 2>&1; then
        echo "  ✅ $name is responding"
        return 0
    else
        echo "  ❌ $name is not responding"
        return 1
    fi
}

# Function to test AI Agent with prompt
test_ai_agent() {
    local prompt=$1
    local session_id="test_$(date +%s)"
    
    echo "🤖 Testing AI Agent with prompt: '$prompt'"
    echo "   Session ID: $session_id"
    
    # Send request to AI Agent
    local response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d "{\"prompt\": \"$prompt\", \"session_id\": \"$session_id\"}" \
        "$WEBHOOK_URL" 2>/dev/null)
    
    if [ $? -eq 0 ] && [ -n "$response" ]; then
        echo "  ✅ Request sent successfully"
        
        # Parse response
        if echo "$response" | jq -e '.success' > /dev/null 2>&1; then
            local product_name=$(echo "$response" | jq -r '.product_name // "unknown"')
            local deployment_id=$(echo "$response" | jq -r '.deployment_id // "unknown"')
            local status=$(echo "$response" | jq -r '.status // "unknown"')
            
            echo "  📦 Product: $product_name"
            echo "  🚀 Deployment ID: $deployment_id"
            echo "  📊 Status: $status"
            
            if [ "$status" = "running" ]; then
                local port_mappings=$(echo "$response" | jq -r '.port_mappings // {}')
                echo "  🌐 Port mappings: $port_mappings"
            fi
            
            return 0
        else
            echo "  ❌ Request failed"
            echo "  📄 Response: $response"
            return 1
        fi
    else
        echo "  ❌ No response received"
        return 1
    fi
}

# Function to test context API
test_context_api() {
    echo "🗃️ Testing Context Manager API..."
    
    local session_id="test_context_$(date +%s)"
    local test_data='{
        "session_id": "'$session_id'",
        "prompt": "Test prompt for context storage",
        "context_data": {
            "test": true,
            "timestamp": "'$(date -Iseconds)'"
        }
    }'
    
    # Store context
    local store_response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d "$test_data" \
        "$CONTEXT_API/context" 2>/dev/null)
    
    if [ $? -eq 0 ] && echo "$store_response" | jq -e '.session_id' > /dev/null 2>&1; then
        echo "  ✅ Context storage successful"
        
        # Retrieve context
        local get_response=$(curl -s "$CONTEXT_API/context/$session_id" 2>/dev/null)
        
        if [ $? -eq 0 ] && echo "$get_response" | jq -e '.[0].session_id' > /dev/null 2>&1; then
            echo "  ✅ Context retrieval successful"
            return 0
        else
            echo "  ❌ Context retrieval failed"
            return 1
        fi
    else
        echo "  ❌ Context storage failed"
        echo "  📄 Response: $store_response"
        return 1
    fi
}

# Function to test DevOps API
test_devops_api() {
    echo "🔧 Testing DevOps Orchestrator API..."
    
    if test_endpoint "$DEVOPS_API/health" "DevOps API Health"; then
        # Test container listing
        local containers_response=$(curl -s "$DEVOPS_API/containers" 2>/dev/null)
        
        if [ $? -eq 0 ] && echo "$containers_response" | jq -e '. | type == "array"' > /dev/null 2>&1; then
            local container_count=$(echo "$containers_response" | jq '. | length')
            echo "  ✅ Container listing successful ($container_count containers)"
            return 0
        else
            echo "  ❌ Container listing failed"
            return 1
        fi
    else
        return 1
    fi
}

# Main test execution
echo "🚀 Starting AI Agent System Tests..."
echo "⏰ Test started at: $(date)"
echo ""

# Test basic connectivity
echo "📡 Testing basic connectivity..."
test_endpoint "$N8N_URL" "n8n Web Interface"
test_endpoint "$CONTEXT_API/health" "Context Manager"
test_endpoint "$DEVOPS_API/health" "DevOps Orchestrator"
test_endpoint "http://localhost:11434/api/tags" "Ollama LLM"

echo ""

# Test Context Manager
test_context_api

echo ""

# Test DevOps Orchestrator
test_devops_api

echo ""

# Test AI Agent with different prompts
echo "🤖 Testing AI Agent with various prompts..."
echo "⚠️  Note: These tests may take several minutes to complete"
echo ""

success_count=0
total_tests=${#TEST_PROMPTS[@]}

for i in "${!TEST_PROMPTS[@]}"; do
    prompt="${TEST_PROMPTS[$i]}"
    echo "📝 Test $((i+1))/$total_tests:"
    
    if test_ai_agent "$prompt"; then
        ((success_count++))
    fi
    
    echo ""
    
    # Wait between tests to avoid overwhelming the system
    if [ $((i+1)) -lt $total_tests ]; then
        echo "⏳ Waiting 30 seconds before next test..."
        sleep 30
    fi
done

# Test summary
echo "📊 Test Summary:"
echo "  ✅ Successful tests: $success_count/$total_tests"
echo "  📈 Success rate: $(( success_count * 100 / total_tests ))%"
echo "  ⏰ Test completed at: $(date)"

if [ $success_count -eq $total_tests ]; then
    echo ""
    echo "🎉 All tests passed! AI Agent System is working correctly."
    exit 0
else
    echo ""
    echo "⚠️  Some tests failed. Please check the logs for more details:"
    echo "   docker-compose logs -f"
    exit 1
fi