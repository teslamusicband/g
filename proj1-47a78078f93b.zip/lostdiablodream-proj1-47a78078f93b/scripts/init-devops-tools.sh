#!/bin/bash

# DevOps Tools Initialization Script for AI Agent System
# This script installs and configures essential DevOps utilities

set -e

echo "🚀 Initializing DevOps Tools for AI Agent System..."

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install package if not exists
install_if_missing() {
    if ! command_exists "$1"; then
        echo "📦 Installing $1..."
        case "$1" in
            "docker")
                curl -fsSL https://get.docker.com -o get-docker.sh
                sh get-docker.sh
                rm get-docker.sh
                ;;
            "docker-compose")
                curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
                chmod +x /usr/local/bin/docker-compose
                ;;
            "kubectl")
                curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
                chmod +x kubectl
                sudo mv kubectl /usr/local/bin/
                ;;
            "helm")
                curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
                ;;
            "terraform")
                wget -O- https://apt.releases.hashicorp.com/gpg | gpg --dearmor | sudo tee /usr/share/keyrings/hashicorp-archive-keyring.gpg
                echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
                sudo apt update && sudo apt install terraform
                ;;
            "ansible")
                pip3 install ansible
                ;;
            "jq")
                sudo apt-get update && sudo apt-get install -y jq
                ;;
            "yq")
                wget -qO /usr/local/bin/yq https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64
                chmod +x /usr/local/bin/yq
                ;;
            "git")
                sudo apt-get update && sudo apt-get install -y git
                ;;
            "curl")
                sudo apt-get update && sudo apt-get install -y curl
                ;;
            "wget")
                sudo apt-get update && sudo apt-get install -y wget
                ;;
        esac
        echo "✅ $1 installed successfully"
    else
        echo "✅ $1 already installed"
    fi
}

# Core utilities
echo "📋 Installing core utilities..."
install_if_missing "curl"
install_if_missing "wget"
install_if_missing "jq"
install_if_missing "yq"
install_if_missing "git"

# Container tools
echo "🐳 Installing container tools..."
install_if_missing "docker"
install_if_missing "docker-compose"

# Kubernetes tools
echo "☸️ Installing Kubernetes tools..."
install_if_missing "kubectl"
install_if_missing "helm"

# Infrastructure as Code
echo "🏗️ Installing Infrastructure as Code tools..."
install_if_missing "terraform"
install_if_missing "ansible"

# Additional useful tools
echo "🔧 Installing additional DevOps tools..."

# Install Node.js and npm (for various build tools)
if ! command_exists "node"; then
    echo "📦 Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
    echo "✅ Node.js installed successfully"
else
    echo "✅ Node.js already installed"
fi

# Install Python and pip (for automation scripts)
if ! command_exists "python3"; then
    echo "📦 Installing Python3..."
    sudo apt-get update && sudo apt-get install -y python3 python3-pip
    echo "✅ Python3 installed successfully"
else
    echo "✅ Python3 already installed"
fi

# Install monitoring tools
echo "📊 Installing monitoring tools..."

# Prometheus node exporter
if [ ! -f "/usr/local/bin/node_exporter" ]; then
    echo "📦 Installing Prometheus Node Exporter..."
    wget https://github.com/prometheus/node_exporter/releases/latest/download/node_exporter-1.6.1.linux-amd64.tar.gz
    tar xvfz node_exporter-1.6.1.linux-amd64.tar.gz
    sudo mv node_exporter-1.6.1.linux-amd64/node_exporter /usr/local/bin/
    rm -rf node_exporter-1.6.1.linux-amd64*
    echo "✅ Node Exporter installed successfully"
else
    echo "✅ Node Exporter already installed"
fi

# Create systemd service for node exporter
if [ ! -f "/etc/systemd/system/node_exporter.service" ]; then
    echo "📝 Creating Node Exporter systemd service..."
    sudo tee /etc/systemd/system/node_exporter.service > /dev/null <<EOF
[Unit]
Description=Node Exporter
Wants=network-online.target
After=network-online.target

[Service]
User=node_exporter
Group=node_exporter
Type=simple
ExecStart=/usr/local/bin/node_exporter

[Install]
WantedBy=multi-user.target
EOF

    sudo useradd --no-create-home --shell /bin/false node_exporter
    sudo systemctl daemon-reload
    sudo systemctl enable node_exporter
    echo "✅ Node Exporter service created"
fi

# Install development tools
echo "💻 Installing development tools..."

# Install build essentials
if ! dpkg -l | grep -q build-essential; then
    echo "📦 Installing build essentials..."
    sudo apt-get update && sudo apt-get install -y build-essential
    echo "✅ Build essentials installed successfully"
else
    echo "✅ Build essentials already installed"
fi

# Install additional useful packages
PACKAGES=(
    "htop"
    "tree"
    "vim"
    "nano"
    "unzip"
    "zip"
    "rsync"
    "screen"
    "tmux"
    "ncdu"
    "iotop"
    "nethogs"
)

echo "📦 Installing additional utility packages..."
for package in "${PACKAGES[@]}"; do
    if ! dpkg -l | grep -q "^ii  $package "; then
        echo "Installing $package..."
        sudo apt-get install -y "$package"
    else
        echo "✅ $package already installed"
    fi
done

# Create useful aliases
echo "🔗 Creating useful aliases..."
cat >> ~/.bashrc << 'EOF'

# AI Agent DevOps Aliases
alias ll='ls -alF'
alias la='ls -A'
alias l='ls -CF'
alias ..='cd ..'
alias ...='cd ../..'
alias grep='grep --color=auto'
alias fgrep='fgrep --color=auto'
alias egrep='egrep --color=auto'

# Docker aliases
alias dps='docker ps'
alias dpsa='docker ps -a'
alias di='docker images'
alias dex='docker exec -it'
alias dlog='docker logs'
alias dlogf='docker logs -f'
alias drm='docker rm'
alias drmi='docker rmi'
alias dprune='docker system prune -f'

# Docker Compose aliases
alias dc='docker-compose'
alias dcup='docker-compose up -d'
alias dcdown='docker-compose down'
alias dcps='docker-compose ps'
alias dclogs='docker-compose logs'
alias dclogsf='docker-compose logs -f'

# Kubernetes aliases
alias k='kubectl'
alias kgp='kubectl get pods'
alias kgs='kubectl get services'
alias kgd='kubectl get deployments'
alias kdesc='kubectl describe'
alias klog='kubectl logs'
alias klogf='kubectl logs -f'

# Git aliases
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git pull'
alias gd='git diff'
alias gb='git branch'
alias gco='git checkout'

# System monitoring aliases
alias ports='netstat -tulanp'
alias meminfo='free -m -l -t'
alias psmem='ps auxf | sort -nr -k 4'
alias pscpu='ps auxf | sort -nr -k 3'
alias cpuinfo='lscpu'
alias diskusage='df -H'
alias foldersize='du -sh'

EOF

echo "🎉 DevOps tools initialization completed!"
echo ""
echo "📋 Installed tools summary:"
echo "  🐳 Container: docker, docker-compose"
echo "  ☸️  Kubernetes: kubectl, helm"
echo "  🏗️  IaC: terraform, ansible"
echo "  📊 Monitoring: node_exporter"
echo "  🔧 Utilities: jq, yq, git, curl, wget"
echo "  💻 Development: build-essential, node.js, python3"
echo "  📦 System: htop, tree, vim, tmux, and more"
echo ""
echo "🔄 Please run 'source ~/.bashrc' to load new aliases"
echo "🚀 Your AI Agent DevOps environment is ready!"