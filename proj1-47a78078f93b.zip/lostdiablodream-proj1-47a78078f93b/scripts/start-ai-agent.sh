#!/bin/bash

# AI Agent System Startup Script
# This script starts all components of the AI Agent system

set -e

echo "🤖 Starting AI Agent System..."

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker first."
    exit 1
fi

# Navigate to project directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

echo "📁 Working directory: $PROJECT_DIR"

# Create necessary directories
echo "📂 Creating necessary directories..."
mkdir -p artifacts logs data/postgres data/redis data/ollama

# Pull required Docker images
echo "🐳 Pulling required Docker images..."
docker pull n8nio/n8n:latest
docker pull postgres:15-alpine
docker pull redis:7-alpine
docker pull ollama/ollama:latest

# Start the system using docker-compose
echo "🚀 Starting AI Agent system components..."
cd docker
docker-compose up -d

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 10

# Check service health
echo "🔍 Checking service health..."

# Check PostgreSQL
echo "  📊 Checking PostgreSQL..."
if docker-compose exec -T postgres pg_isready -U n8n > /dev/null 2>&1; then
    echo "  ✅ PostgreSQL is ready"
else
    echo "  ⚠️  PostgreSQL is not ready yet"
fi

# Check Redis
echo "  🔴 Checking Redis..."
if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
    echo "  ✅ Redis is ready"
else
    echo "  ⚠️  Redis is not ready yet"
fi

# Check n8n
echo "  🔄 Checking n8n..."
sleep 5
if curl -s http://localhost:12000 > /dev/null 2>&1; then
    echo "  ✅ n8n is ready"
else
    echo "  ⚠️  n8n is not ready yet (this is normal, it may take a few more seconds)"
fi

# Check Ollama
echo "  🦙 Checking Ollama..."
if curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "  ✅ Ollama is ready"
else
    echo "  ⚠️  Ollama is not ready yet"
fi

# Download Llama model if not exists
echo "🦙 Setting up Llama model..."
docker-compose exec -d ollama ollama pull llama3.1

# Import n8n workflow
echo "📋 Importing n8n workflow..."
sleep 10

# Wait for n8n to be fully ready
echo "⏳ Waiting for n8n to be fully ready..."
for i in {1..30}; do
    if curl -s -u admin:admin123 http://localhost:12000/rest/workflows > /dev/null 2>&1; then
        echo "  ✅ n8n API is ready"
        break
    fi
    echo "  ⏳ Waiting for n8n API... ($i/30)"
    sleep 2
done

# Import workflow using n8n CLI (if available) or API
if [ -f "../workflows/ai-agent-workflow.json" ]; then
    echo "📥 Importing AI Agent workflow..."
    
    # Try to import via API
    WORKFLOW_DATA=$(cat ../workflows/ai-agent-workflow.json)
    
    curl -X POST \
        -H "Content-Type: application/json" \
        -u admin:admin123 \
        -d "$WORKFLOW_DATA" \
        http://localhost:12000/rest/workflows \
        > /dev/null 2>&1 && echo "  ✅ Workflow imported successfully" || echo "  ⚠️  Workflow import failed (you can import manually)"
fi

# Show system status
echo ""
echo "🎉 AI Agent System is starting up!"
echo ""
echo "📋 Service URLs:"
echo "  🔄 n8n Workflow Engine: http://localhost:12000"
echo "      Username: admin"
echo "      Password: admin123"
echo ""
echo "  🦙 Ollama LLM API: http://localhost:11434"
echo "  📊 Context Manager: http://localhost:12001"
echo ""
echo "📊 System Status:"
docker-compose ps

echo ""
echo "🔧 Useful Commands:"
echo "  📊 View logs: docker-compose logs -f [service_name]"
echo "  🔄 Restart service: docker-compose restart [service_name]"
echo "  🛑 Stop system: docker-compose down"
echo "  📋 View status: docker-compose ps"
echo ""
echo "🚀 To test the AI Agent, send a POST request to:"
echo "   http://localhost:12000/webhook/ai-agent-create-product"
echo "   with JSON body: {\"prompt\": \"Create a simple web application\"}"
echo ""
echo "📖 Check the logs for any issues:"
echo "   docker-compose logs -f"

cd "$PROJECT_DIR"